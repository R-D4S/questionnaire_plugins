<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    
    $post=file_get_contents( "php://input" );
    $post=json_decode($post);
    $activity=$post[0];
    unset($post[0]);
    $course=$post[1];
    unset($post[1]);
    $user=$post[2];
    unset($post[2]);
    $topics=[];
    foreach($post as $value){
        $topics[]=$value;
    }
    $DB->delete_records('conf_chosen_topics', ['activityid'=>$activity, 'courseid'=>$course, 'reviewer'=>$user]);
    foreach ($topics as $topic){
        $DB->insert_record('conf_chosen_topics', ['activityid'=>$activity, 'courseid'=>$course, 'reviewer'=>$user, 'topic'=>$topic]);
    }
        
    
    
//    function check_field($quiz, $course){
//        global $DB;
//        if (!($DB->get_record('conftopic_fields', ['courseid'=>$course, 'activityid'=>$quiz])==false))
//                $DB->delete_records('conftopic_fields', ['courseid'=>$course, 'activityid'=>$quiz]);
//        
//    }

    
?>