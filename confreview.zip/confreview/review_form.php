<?php


    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    //вывод оценки определенного рецензента
    
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $reviewer=$_GET['reviewer'];
    $student=$_GET['student'];
    $attempt=$_GET['attempt'];
  
 




 
