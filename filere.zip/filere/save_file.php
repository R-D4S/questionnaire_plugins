<?php

require_once'../../../config.php';
global $DB;

$quizid=$_POST['quizid'];
$courseid=$_POST['courseid'];
$cmid=$_POST['cmid'];
$questionname=$_POST['question_name'];
$attemptid=$_POST['attemptid'];
$userid=$_POST['userid'];
$oldname=$_FILES['uploaded_file']['name'];

$newname = $quizid.$courseid.$cmid.$attemptid.$userid.'-'.$oldname; 

$target = 'fileredata/'.$newname;
echo move_uploaded_file( $_FILES['uploaded_file']['tmp_name'], $target); 

$DB->delete_records('conf_files', ['quizid'=>$quizid, 'courseid'=>$courseid, 'cmid'=>$cmid, 'attemptid'=>$attemptid, 'userid'=>$userid]);
$DB->insert_record('conf_files', ['quizid'=>$quizid, 'courseid'=>$courseid, 'cmid'=>$cmid, 'attemptid'=>$attemptid, 'userid'=>$userid,
    'questionname'=>$questionname, 'filename'=>$newname]);

//получаем всех студентов с заявкой 
$submissions=$DB->get_records('conf_submission', ['quizid'=>$quizid, 'courseid'=>$courseid]);
$students=[];
foreach ($submissions as $s){
    if (!in_array($s->userid, $students)){
        $students[]=['id'=>$s->userid, 'attempt'=>$s->attemptid];
    }
}

foreach($students as $s){
    if ($DB->get_records('conf_files', ['quizid'=>$quizid, 'courseid'=>$courseid, 'cmid'=>$cmid, 'attemptid'=>$s['attempt'], 'userid'=>$s['id'],
    'questionname'=>$questionname])==false){
        $DB->insert_record('conf_files', ['quizid'=>$quizid, 'courseid'=>$courseid, 'cmid'=>$cmid, 'attemptid'=>$s['attempt'], 'userid'=>$s['id'],
    'questionname'=>$questionname, 'filename'=>'']);
    }
}

