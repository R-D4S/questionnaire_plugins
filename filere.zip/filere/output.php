<?php

function filere_hide(){
        
        $res="<script>";
        $res.='document.addEventListener("DOMContentLoaded", function(e) {';
      
    
        $res.="var elements=document.getElementsByClassName('info');";
        $res.="for (var i=0; i<elements.length; i++){";
        
        $res.="elements[i].style.display='none'";
        $res.="}";
        $res.="var elements=document.getElementsByClassName('mod_quiz-next-nav btn btn-primary');";
        $res.="for (var i=0; i<elements.length; i++){";
        $res.="if(i==0)";
        $res.="elements[i].style.display='none'";
        $res.="}";
        
        $res.="document.getElementById('mod_quiz_navblock').style.display='none';";
        
        
        $res.='var el=document.querySelectorAll("'."[role='main']".':last-of-type")[0];';//кавычки
        //$res.="el.innerHTML.replace(/<form.*>/gm, '<div>');";        
        //$res.="el.innerHTML.replace(/<\/form>/gm, '</div>');"; 
        //$res.="console.log(el)";
        $res.=' });';
        
        $res.="</script>";
        
        echo $res;
    }
    
    function input_field($question_name, $courseid){
        global $DB;
        global $USER;
        global $COURSE;
        global $PAGE;
        $cm = $PAGE->cm;
        $filere_field=array_pop($DB->get_records('filere_fields', ['courseid'=>$COURSE->id, 'form'=>$cm->id]));
        $topic_field=$filere_field->fieldid;
        $activity=$filere_field->activityid;
        $users_topics=$DB->get_records('conf_submission', ['courseid'=>$courseid, 'quizid'=>$activity, 'userid'=>$USER->id, 'quiestionid'=>$topic_field]);
        echo '<script type="text/javascript" src="../../question/type/filere/controls.js"></script>';
        echo '<script>output('.json_encode($users_topics).',"'.$question_name.'",'.$cm->id.')</script>';
    }