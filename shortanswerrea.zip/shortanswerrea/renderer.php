<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Short answer question renderer class.
 *
 * @package    qtype
 * @subpackage shortanswerrea
 * @copyright  2009 The Open University
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


defined('MOODLE_INTERNAL') || die();


/**
 * Generates the output for short answer questions.
 *
 * @copyright  2009 The Open University
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class qtype_shortanswerrea_renderer extends qtype_renderer {
    
    public function formulation_and_controls(question_attempt $qa,
            question_display_options $options) {
        $question = $qa->get_question();
        $rid=$question->id;
        $profile_data=$question->profiledata;
        $allow_change=$question->usecase;
        global $USER;
        
        foreach($qa->get_question()->get_answers() as $value){
                        $mask=$value->answer;
                    }
        
        if($profile_data=="0"){
            $currentanswer = $qa->get_last_qt_var('answer');
        }
        else{
            switch ($profile_data){
                case "1":
                    $currentanswer=$USER->lastname;
                    break;
                case "2":
                    $currentanswer=$USER->firstname;
                    break;
                case "3":
                    $currentanswer=$USER->middlename;
                    break;
                case "4":
                    $currentanswer=$USER->email;
                    break;
                case "5":
                    $currentanswer=$USER->city;
                    break;
                case "6":
                    $currentanswer=$USER->country;
                    break;
                case "7":
                    $currentanswer=$USER->idnumber;
                    break;
                case "8":
                    $currentanswer=$USER->institution;
                    break;
                case "9":
                    $currentanswer=$USER->department;
                    break;
                case "10":
                    $currentanswer=$USER->phone;
                    break;
                case "11":
                    $currentanswer=$USER->phone2;
                    break;
                case "12":
                    $currentanswer=$USER->address;
                    break;
            }
            if($qa->get_last_qt_var('answer')!=$currentanswer and $qa->get_last_qt_var('answer')!=''){
                $currentanswer=$qa->get_last_qt_var('answer');
            }
        }

        $inputname = $qa->get_qt_field_name('answer');
        
        $inputattributes = array(
            'type' => 'text',
            'name' => $inputname,
            'value' => $currentanswer,
            'id' => $inputname,
            'size' => 80,
            'class' => 'form-control d-inline',
            'title'=>$question->tip
        );

        if ($options->readonly or $allow_change=="1") {
            $inputattributes['readonly'] = 'readonly';
        }

        $feedbackimg = '';
        
        if ($options->correctness) {
            $answer = $question->get_matching_answer(array('answer' => $currentanswer));
            if ($answer) {
                $fraction = $answer->fraction;
            } else {
                $fraction = 0;
            }
            $inputattributes['class'] .= ' ' . $this->feedback_class($fraction);
            $feedbackimg = $this->feedback_image($fraction);
        }

        $questiontext = $question->format_questiontext($qa);
        $placeholder = false;
        if (preg_match('/_____+/', $questiontext, $matches)) {
            $placeholder = $matches[0];
            $inputattributes['size'] = round(strlen($placeholder) * 1.1);
        }
        if (!empty($_GET['wqid'])&&$_GET['wqid']==$rid){
            $input = '<a name="'.$rid.'"></a>'.html_writer::empty_tag('input', $inputattributes) . $feedbackimg.'<br>'.get_string('wrong','qtype_shortanswerrea').$this->check_format($qa);
        }
        else{
            if($allow_change=="0" and $mask!=".*"){
                $input = html_writer::empty_tag('input', $inputattributes) . $feedbackimg.'<br>'.get_string('warning','qtype_shortanswerrea').$this->check_format($qa);
            }
            else
            {
                $input = html_writer::empty_tag('input', $inputattributes) . $feedbackimg;
            }
        }

        if ($placeholder) {
            $inputinplace = html_writer::tag('label', get_string('answer'),
                    array('for' => $inputattributes['id'], 'class' => 'accesshide'));
            $inputinplace .= $input;
            $questiontext = substr_replace($questiontext, $inputinplace,
                    strpos($questiontext, $placeholder), strlen($placeholder));
        }

        $result = html_writer::tag('div', $questiontext, array('class' => 'qtext'));

        if (!$placeholder) {
            $result .= html_writer::start_tag('div', array('class' => 'ablock form-inline'));
            $result .= html_writer::tag('label', get_string('answer', 'qtype_shortanswerrea',
                    html_writer::tag('span', $input, array('class' => 'answer'))),
                    array('for' => $inputattributes['id']));
            $result .= html_writer::end_tag('div');
        }

        if ($qa->get_state() == question_state::$invalid) {
            $result .= html_writer::nonempty_tag('div',
                    $question->get_validation_error(array('answer' => $currentanswer)),
                    array('class' => 'validationerror'));
        }
        
        return $result;
    }

    public function specific_feedback(question_attempt $qa) {
        $question = $qa->get_question();

        $answer = $question->get_matching_answer(array('answer' => $qa->get_last_qt_var('answer')));
        if (!$answer || !$answer->feedback) {
            return '';
        }

        return $question->format_text($answer->feedback, $answer->feedbackformat,
                $qa, 'question', 'answerfeedback', $answer->id);
    }

    public function correct_response(question_attempt $qa) {
        global $DB;
        global $USER;
        global $COURSE;
        global $PAGE;
        $cm = $PAGE->cm;
        $quiz = $DB->get_record('quiz', array('id' => $cm->instance));
        
        $quizid=$quiz->id;
        $attemptid=$_GET['attempt'];
        $courseid=$COURSE->id;
        $newrecord=new stdClass();     
        
        $newrecord->userid=$USER->id;
        $newrecord->courseid=$COURSE->id;
        $newrecord->quizid=$quiz->id;
        $newrecord->attemptid=$_GET['attempt'];        
        $newrecord->quiestionid=$qa->get_question()->id;
        $newrecord->questiontext=$qa->get_question()->name;
        $newrecord->answer=$qa->get_last_qt_data()['answer'];
        if ($DB->get_record('conf_submission', (array)$newrecord)==false)
            $DB->insert_record("conf_submission", $newrecord);
        
        //в файлах для каждого пользователя с сабмишином для каждого файла если не существует создать
        $submissions=$DB->get_records('conf_submission', ['courseid'=>$courseid, 'quizid'=>$quizid ]);
        $authors=[];
        foreach($submissions as $sub){
            if(!in_array(['user'=>$sub->userid, 'attempt'=>$sub->attemptid], $authors)){
                $authors[]=['user'=>$sub->userid, 'attempt'=>$sub->attemptid];
            }
        }
        
        $file_submissions=$DB->get_records('conf_files', ['courseid'=>$courseid, 'quizid'=>$quizid ]);
        $files=[];
        foreach($file_submissions as $f){
            if(!in_array(['question'=>$f->questionname, 'cmid'=>$f->cmid])){
                $files[]=['question'=>$f->questionname, 'cmid'=>$f->cmid];
            }
        }
        
        foreach($authors as $author){
            foreach($files as $f){
                if($DB->get_records('conf_files', ['courseid'=>$courseid, 'quizid'=>$quizid, 'userid'=>$author['user'], 
                    'attemptid'=>$author['attempt'], 'questionname'=>$f ])==false){
                    $DB->insert_record('conf_files', ['courseid'=>$courseid, 'quizid'=>$quizid, 'userid'=>$author['user'], 
                    'attemptid'=>$author['attempt'], 'questionname'=>$f['question'], 'filename'=>'', 'cmid'=>$f['cmid'] ]);
                }
            }
        }
        
        return '';
    }
    
    
    public function check_format($qa){
        $slot=$qa->get_slot();
        foreach($qa->get_question()->get_answers() as $value){
                        $mask=$value->answer;
                    }
        $mask='/'.$mask.'/';
        $qa_id=$qa->get_usage_id();
        $field_id="q".$qa_id.":".$slot."_answer";
        $res="<script>";
        $res.="var mask".$slot."=".$mask.";";
        $res.="var f".$slot."=document.getElementById('".$field_id."');";
        
        $res.="f".$slot.".onkeyup=function(){";
        $res.="var found=f".$slot.".value.match(mask".$slot.");";
        $res.="if(found===null){";
        $res.="f".$slot.".style.color='red';";
        $res.="}";
        $res.="else{";
        $res.="f".$slot.".style.color='black';";
        $res.="}";
        $res.="};";
        $res.="</script>";
        //var_dump($qa);
        return $res;
    }
    
    
}
