﻿<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'qtype_confreview', language 'ru', branch 'MOODLE_38_STABLE'
 *
 * @package   qtype_confreview
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addmoreanswerblanks'] = 'Добавить {no} варианта(ов) ответа(ов)';
$string['answer'] = 'Ответ: {$a}';
$string['answermustbegiven'] = 'Вы должны ввести для каждого варианта ответа оценку или отзыв.';
$string['answerno'] = 'Вариант ответа {$a}';
$string['caseno'] = 'Нет, регистр не имеет значения';
$string['casesensitive'] = 'Чувствительность к регистру';
$string['caseyes'] = 'Да, регистр учитывается';
$string['correctansweris'] = 'Правильный ответ: {$a}';
$string['correctanswers'] = 'Правильные ответы';
$string['filloutoneanswer'] = 'Вам необходимо указать хотя бы один возможный ответ. Пустые ответы не будут использоваться. Символ «*» можно использовать в качестве шаблона, соответствующего любым символам. Первый подходящий ответ будет использоваться для определения оценки и отзыва.';
$string['notenoughanswers'] = 'Этот тип вопроса требует не менее {$a} ответов.';
$string['pleaseenterananswer'] = 'Пожалуйста, введите ответ.';
$string['pluginname'] = 'Форма рецензирования и просмотра работ';
$string['pluginnameadding'] = 'Добавление формы рецензирования и просмотра работ';
$string['pluginnameediting'] = 'Редактирование формы рецензирования и просмотра работ.';
$string['pluginname_help'] = 'В качестве ответа на вопрос (который может включать изображение) студент впечатывает одно слово или короткую фразу. Можно указать несколько возможных правильных вариантов ответа, причем каждый с разной оценкой. Если выбран параметр «Учитывать регистр», то студент получит разные оценки за ответы «Слово» и «слово».';
$string['pluginnamesummary'] = 'Позволяет вводить в качестве ответа одно или несколько слов. Ответы оцениваются путем сравнения с разными образцами ответов, в которых могут использоваться подстановочные знаки.';
$string['privacy:metadata'] = 'Плагин «Тип вопроса Короткий ответ» не хранит никаких персональных данных';
$string['wrong_grade']='Некорректное значение';
$string['choose_quiz']='Выберите форму подачи заявки';
$string['choose_fields_auth']='Какие поля могут видеть авторы';
$string['choose_fields_rev']='Какие поля могут видеть рецензенты';
$string['choose_fields_ed']='Какие поля могут видеть редакторы';
$string['choose_fields_sup']='Какие поля может видеть председатель';
$string['ed_rev_name']='Имена рецензентов';
$string['sup_rev_name']='Имена рецензентов';
$string['sup_ed_name']='Имена редакторов';
$string['auth_rev_name']='Имена рецензентов';
$string['auth_rev_grade']='Оценки';
$string['auth_rev_conf']="Квалификация рецензентов";
$string['auth_rev_review']='Рецензии';
$string['auth_ed_name']='Имена редакторов';
$string['auth_ed_dis']="Решения редакторов";
$string['auth_sup_name']='Имя председателя';
$string['auth_sup_dis']='Решение председателя';
$string['grades_range']='Диапазон оценок';
$string['1to5']='от 1 до 5';
$string['1to10']='от 1 до 10';
$string['1to100']='от 1 до 100';
$string['-3to3']='от -3 до 3';
$string['passing_grade']='Проходная оценка';
$string['passing_avg']='Проходное среднее всех оценок';
$string['ed_rev']='Рецензент';
$string['hidden']='Скрыто';
$string['close_rev_div']='Закрыть';
$string['show_review']='Рецензии';
$string['review_header']='Рецензия';
$string['reviews_header']='Рецензии';
$string['no_review']='Нет рецензии';
$string['reviewer']='Рецензент';
$string['review']='Рецензия';
$string['reviewer_confidence']="Квалификация <br>рецензента";
$string['comment']='Комментарий<br> для редакторов';
$string['accept']='Принять заявку';
$string['decline']='Отклонить заявку';
$string['correction']='Требуются исправления';
$string['final_decision']='Окончательное решение';
$string['r_and_d']="Рецензии и<br>решения редакторов";
$string['r_and_d_btn']="Показать";
$string['dis_header']="Решения редакторов";
$string['editor']='Редактор';
$string['ed_dis']='Решение';
$string['author_field']='Просмотр заявок для авторов';
$string['3grade']='3: безусловно принять';
$string['2grade']='2: принять';
$string['1grade']='1: принять с исправлениями';
$string['0grade']='0: пограничная работа';
$string['-1grade']='-1: отклонить с замечаниями';
$string['-2grade']='-2: отклонить';
$string['-3grade']='-3: категорически отклонить';
$string['5conf']='5: эксперт';
$string['4conf']='4: высокая';
$string['3conf']='3: средняя';
$string['2conf']='2: низкая';
$string['1conf']='1: отсутствует';
$string['comment_for_ed']='Комментарий <br>для редакторов';
$string['rev_confidence']="Квалификация <br>рецензента";
$string['reviewers_field']='Просмотр заявок для рецензентов';
$string['view_review']='Показать';
$string['close_review']='Закрыть рецензию';
$string['save_review']='Сохранить';
$string['reviews_button']='Показать';
$string['close_rev_div']='Закрыть';
$string['editors_field']='Просмотр заявок для редакторов';
$string['reviews']='Рецензии';
$string['avg_grade']='Средняя оценка';
$string['min_grade']='Самая низкая оценка';
$string['missing_reviews']='Не хватает оценок';
$string['decision']='Решение';
$string['chairmen_field']='Просмотр заявок для председателя';
$string['grade']="Оценка";