<?php
    //редактирование таблицы со списком рецензентов
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    if (empty(has_capability('moodle/course:update', $context))){
        echo "Forbidden";
    }
    else{
        $course=$_GET['courseid'];
        $activity=$_GET['activityid'];
        $editor=$_GET['editor'];
        if(check_editors($course, $activity, $editor)){
            delete_editor($course, $activity, $editor);
        }
        else{
            add_to_editors($course, $activity, $editor);
        }
    }
    
    function add_to_editors($course, $activity, $editor){
        global $DB;
        $newrecord=new stdClass();
        $newrecord->courseid=$course;
        $newrecord->activityid=$activity;
        $newrecord->editor=$editor;
        
        
        $DB->insert_record("confdist_editors_list", $newrecord);
    }
    
    function check_editors($course, $activity, $editor){
        global $DB;
        if ($DB->get_record('confdist_editors_list', ['courseid'=>$course, 'activityid'=>$activity, 'editor'=>$editor])==false)
                return false;
        else
            return true;        
    }
    
    function delete_editor($course, $activity, $editor){
        global $DB;
        $DB->delete_records('confdist_editors_list', ['courseid'=>$course, 'activityid'=>$activity, 'editor'=>$editor]);
        $DB->delete_records('confdist_editors_dist', ['courseid'=>$course, 'activityid'=>$activity, 'editor'=>$editor]);
    }
?>