window.onload=function(){
    forbidminmax();
    document.getElementById('id_single').onchange=forbidminmax;
}

function forbidminmax(){
    if(document.getElementById('id_single').value==1){
        document.getElementById('id_minansnmb').disabled=true;
        document.getElementById('id_maxansnmb').disabled=true;
    }
    else{
        document.getElementById('id_minansnmb').disabled=false;
        document.getElementById('id_maxansnmb').disabled=false;
    }
}