<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
   
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $form=$_GET['form'];
    $fields = file_get_contents( "php://input" );
    $fields = json_decode( $fields);
    $sup_rev_name=$_GET['sup_rev_name'];
    if($sup_rev_name=='true'){
        $sup_rev_name='1';
    }
    else{
        $sup_rev_name='0';
    }
    $sup_ed_name=$_GET['sup_ed_name'];
    if($sup_ed_name=='true'){
        $sup_ed_name='1';
    }
    else{
        $sup_ed_name='0';
    }
    
    if($DB->get_records('confreview_view_options', ['courseid'=>$course, 'activityid'=>$quiz, 'form'=>$form])==false){
        $DB->insert_record('confreview_view_options', ['sup_rev_name'=>$sup_rev_name, 'sup_ed_name'=>$sup_ed_name]);
    }
    else{
        $id=$DB->get_record('confreview_view_options', ['courseid'=>$course, 'activityid'=>$quiz, 'form'=>$form])->id;
        $DB->update_record('confreview_view_options', (object)['id'=>$id, 'sup_rev_name'=>$sup_rev_name, 'sup_ed_name'=>$sup_ed_name]);
    }
    
    //check and update
    check_field($quiz, $course);
    foreach($fields as $field){
        $DB->insert_record('confreview_sup_fields', ['fieldid'=>$field, 'courseid'=>$course, 'activityid'=>$quiz, 'form'=>$form]);
    }
    
    
    function check_field($quiz, $course){
        global $DB;
        if (!($DB->get_record('confreview_sup_fields', ['courseid'=>$course, 'activityid'=>$quiz])==false))
                $DB->delete_records('confreview_sup_fields', ['courseid'=>$course, 'activityid'=>$quiz]);
        
    }
?>