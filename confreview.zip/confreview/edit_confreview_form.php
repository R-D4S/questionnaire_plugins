<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Defines the editing form for the confreview question type.
 *
 * @package    qtype
 * @subpackage confreview
 * @copyright  2007 Jamie Pratt
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


defined('MOODLE_INTERNAL') || die();


/**
 * Short answer question editing form definition.
 *
 * @copyright  2007 Jamie Pratt
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class qtype_confreview_edit_form extends question_edit_form {

    protected function definition_inner($mform) {
        global $COURSE;
        $words=['choose_quiz'=>get_string('choose_quiz', 'qtype_confreview'),
            'choose_fields_rev'=>get_string('choose_fields_rev', 'qtype_confreview'),
            'choose_fields_ed'=>get_string('choose_fields_ed', 'qtype_confreview'),
            'choose_fields_auth'=>get_string('choose_fields_auth', 'qtype_confreview'),
            'choose_fields_sup'=>get_string('choose_fields_sup', 'qtype_confreview'),
            'ed_rev_name'=>get_string('ed_rev_name', 'qtype_confreview'), 
            'sup_rev_name'=>get_string('sup_rev_name', 'qtype_confreview'),
            'sup_ed_name'=>get_string('sup_ed_name', 'qtype_confreview'),
            'auth_rev_name'=>get_string('auth_rev_name', 'qtype_confreview'),
            'auth_rev_grade'=>get_string('auth_rev_grade', 'qtype_confreview'),
            'auth_rev_conf'=>get_string('auth_rev_conf', 'qtype_confreview'),
            'auth_rev_review'=>get_string('auth_rev_review', 'qtype_confreview'),
            'auth_ed_name'=>get_string('auth_ed_name', 'qtype_confreview'),
            'auth_ed_dis'=>get_string('auth_ed_dis', 'qtype_confreview'),
            'auth_sup_name'=>get_string('auth_sup_name', 'qtype_confreview'), 
            'auth_sup_dis'=>get_string('auth_sup_dis', 'qtype_confreview'),
            'grades_range'=>get_string('grades_range', 'qtype_confreview'),
            '1to5'=>get_string('1to5', 'qtype_confreview'),
            '1to10'=>get_string('1to10', 'qtype_confreview'),
            '1to100'=>get_string('1to100', 'qtype_confreview'),
            '-3to3'=>get_string('-3to3', 'qtype_confreview'),
            'passing_grade'=>get_string('passing_grade', 'qtype_confreview'),
            'passing_avg'=>get_string('passing_avg', 'qtype_confreview'),];
        echo '<script type="text/javascript" src="../../question/type/confreview/hide.js"></script>';
        echo '<script type="text/javascript" src="../../question/type/confreview/controls.js"></script>'; 
        echo '<script>selectQuiz('.$COURSE->id.','.$_GET['cmid'].",'".JSON_encode($words)."'".');</script>';    
        
        $mform->addElement('html', '<div id="select_quiz"></div>');
        $mform->addElement('html', '<div id="select_field"></div>');
        $mform->addElement('html', '<div id="select_grading"></div>');
        $mform->addElement('html', '<div id="select_lowestgrade"></div>');
        $mform->addElement('html', '<div id="select_lowestavg"></div>');
        
        $menu = array(
            get_string('caseno', 'qtype_confreview'),
            get_string('caseyes', 'qtype_confreview')
        );
        $mform->addElement('select', 'usecase',
                get_string('casesensitive', 'qtype_confreview'), $menu);

        $mform->addElement('static', 'answersinstruct',
                get_string('correctanswers', 'qtype_confreview'),
                get_string('filloutoneanswer', 'qtype_confreview'));
        $mform->closeHeaderBefore('answersinstruct');

        $this->add_per_answer_fields($mform, get_string('answerno', 'qtype_confreview', '{no}'),
                question_bank::fraction_options());

        $this->add_interactive_settings();
    }

    protected function get_more_choices_string() {
        return get_string('addmoreanswerblanks', 'qtype_confreview');
    }

    protected function data_preprocessing($question) {
        $question = parent::data_preprocessing($question);
        $question = $this->data_preprocessing_answers($question);
        $question = $this->data_preprocessing_hints($question);

        return $question;
    }

    public function validation($data, $files) {
        $errors = parent::validation($data, $files);
        $answers = $data['answer'];
        $answercount = 0;
        $maxgrade = false;
        foreach ($answers as $key => $answer) {
            $trimmedanswer = trim($answer);
            if ($trimmedanswer !== '') {
                $answercount++;
                if ($data['fraction'][$key] == 1) {
                    $maxgrade = true;
                }
            } else if ($data['fraction'][$key] != 0 ||
                    !html_is_blank($data['feedback'][$key]['text'])) {
                $errors["answeroptions[{$key}]"] = get_string('answermustbegiven', 'qtype_confreview');
                $answercount++;
            }
        }
        if ($answercount==0) {
            $errors['answeroptions[0]'] = get_string('notenoughanswers', 'qtype_confreview', 1);
        }
        if ($maxgrade == false) {
            $errors['answeroptions[0]'] = get_string('fractionsnomax', 'question');
        }
        return $errors;
    }

    public function qtype() {
        return 'confreview';
    }
}
