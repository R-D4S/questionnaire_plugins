<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Short-answer question type upgrade code.
 *
 * @package    qtype
 * @subpackage confreview
 * @copyright  2011 The Open University
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade code for the essay question type.
 * @param int $oldversion the version we are upgrading from.
 */
function xmldb_qtype_confreview_upgrade($oldversion) {
    global $CFG;
      global $DB;
    $dbman = $DB->get_manager();

    // Automatically generated Moodle v3.3.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.4.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.5.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.6.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.7.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.8.0 release upgrade line.
    // Put any upgrade step following this.
    if ($oldversion < 2019111801) {

        // Define table confreview_fields to be created.
        $table = new xmldb_table('confreview_fields');

        // Adding fields to table confreview_fields.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('fieldid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('form', XMLDB_TYPE_INTEGER, '10', null, null, null, null);

        // Adding keys to table confreview_fields.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confreview_fields.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Confreview savepoint reached.
        upgrade_plugin_savepoint(true, 2019111801, 'qtype', 'confreview');
    }
        if ($oldversion < 2019111802) {

        // Define table confreview_grading to be created.
        $table = new xmldb_table('confreview_grading');

        // Adding fields to table confreview_grading.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('form', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('grading', XMLDB_TYPE_CHAR, '10', null, null, null, null);
        $table->add_field('lowestgrade', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('lowestavg', XMLDB_TYPE_INTEGER, '10', null, null, null, null);

        // Adding keys to table confreview_grading.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confreview_grading.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Confreview savepoint reached.
        upgrade_plugin_savepoint(true, 2019111802, 'qtype', 'confreview');
    }
    
        if ($oldversion < 2019111803) {

        // Define table confreview_grades to be created.
        $table = new xmldb_table('confreview_grades');

        // Adding fields to table confreview_grades.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('student', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('attempt', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('reviewer', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('grade', XMLDB_TYPE_INTEGER, '4', null, null, null, null);

        // Adding keys to table confreview_grades.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confreview_grades.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Confreview savepoint reached.
        upgrade_plugin_savepoint(true, 2019111803, 'qtype', 'confreview');
    }
        if ($oldversion < 2019111805) {

        // Define table confreview_comments to be created.
        $table = new xmldb_table('confreview_comments');

        // Adding fields to table confreview_comments.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('student', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('attempt', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('reviewer', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('comment', XMLDB_TYPE_CHAR, '1000', null, null, null, null);

        // Adding keys to table confreview_comments.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confreview_comments.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

       

        // Define table confreview_review to be created.
        $table = new xmldb_table('confreview_review');

        // Adding fields to table confreview_review.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('student', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('attempt', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('reviewer', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('review', XMLDB_TYPE_TEXT, null, null, null, null, null);

        // Adding keys to table confreview_review.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confreview_review.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Confreview savepoint reached.
        

        // Define table confreview_ed_fields to be created.
        $table = new xmldb_table('confreview_ed_fields');

        // Adding fields to table confreview_ed_fields.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('fieldid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('form', XMLDB_TYPE_INTEGER, '10', null, null, null, null);

        // Adding keys to table confreview_ed_fields.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confreview_ed_fields.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

      

        // Define table confreview_au_fields to be created.
        $table = new xmldb_table('confreview_au_fields');

        // Adding fields to table confreview_au_fields.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('fieldid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('form', XMLDB_TYPE_INTEGER, '10', null, null, null, null);

        // Adding keys to table confreview_au_fields.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confreview_au_fields.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Confreview savepoint reached.


        // Define table confreview_sup_fields to be created.
        $table = new xmldb_table('confreview_sup_fields');

        // Adding fields to table confreview_sup_fields.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('fieldid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('form', XMLDB_TYPE_INTEGER, '10', null, null, null, null);

        // Adding keys to table confreview_sup_fields.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confreview_sup_fields.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Confreview savepoint reached.
    

        // Define table confreview_ed_dis to be created.
        $table = new xmldb_table('confreview_ed_dis');

        // Adding fields to table confreview_ed_dis.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('student', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('attempt', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('editor', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('decision', XMLDB_TYPE_INTEGER, '2', null, null, null, null);

        // Adding keys to table confreview_ed_dis.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confreview_ed_dis.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

   

        // Define table confreview_sup_dis to be created.
        $table = new xmldb_table('confreview_sup_dis');

        // Adding fields to table confreview_sup_dis.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('student', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('attempt', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('superviser', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('decision', XMLDB_TYPE_INTEGER, '10', null, null, null, null);

        // Adding keys to table confreview_sup_dis.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confreview_sup_dis.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Confreview savepoint reached.
        upgrade_plugin_savepoint(true, 2019111805, 'qtype', 'confreview');
    }
        if ($oldversion < 2019111806) {

        // Define table confreview_confidence to be created.
        $table = new xmldb_table('confreview_confidence');

        // Adding fields to table confreview_confidence.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('student', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('attempt', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('reviewer', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('confidence', XMLDB_TYPE_INTEGER, '1', null, null, null, null);

        // Adding keys to table confreview_confidence.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confreview_confidence.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Confreview savepoint reached.
        upgrade_plugin_savepoint(true, 2019111806, 'qtype', 'confreview');
    }

     if ($oldversion < 2019111809) {

        // Define table confreview_view_options to be created.
        $table = new xmldb_table('confreview_view_options');

        // Adding fields to table confreview_view_options.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('form', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('ed_rev_name', XMLDB_TYPE_CHAR, '1', null, null, null, null);
        $table->add_field('sup_ed_name', XMLDB_TYPE_CHAR, '1', null, null, null, null);
        $table->add_field('sup_rev_name', XMLDB_TYPE_CHAR, '1', null, null, null, null);
        $table->add_field('auth_rev_name', XMLDB_TYPE_CHAR, '1', null, null, null, null);
        $table->add_field('auth_rev_grade', XMLDB_TYPE_CHAR, '1', null, null, null, null);
        $table->add_field('auth_rev_conf', XMLDB_TYPE_CHAR, '1', null, null, null, null);
        $table->add_field('auth_rev_review', XMLDB_TYPE_INTEGER, '1', null, null, null, null);
        $table->add_field('auth_ed_name', XMLDB_TYPE_CHAR, '1', null, null, null, null);
        $table->add_field('auth_ed_dis', XMLDB_TYPE_CHAR, '1', null, null, null, null);
        $table->add_field('auth_sup_name', XMLDB_TYPE_CHAR, '1', null, null, null, null);
        $table->add_field('auth_sup_dis', XMLDB_TYPE_CHAR, '1', null, null, null, null);

        // Adding keys to table confreview_view_options.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confreview_view_options.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Confreview savepoint reached.
        upgrade_plugin_savepoint(true, 2019111809, 'qtype', 'confreview');
    }

    return true;
}
