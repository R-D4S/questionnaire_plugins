<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $submissions=$DB->get_records('conf_submission', ['courseid'=>$course, 'quizid'=>$quiz]);
    $fields=[];
    foreach($submissions as $submission){
        $field=['id'=>$submission->quiestionid, 'text'=>$submission->questiontext];
        if(!in_array($field, $fields)){
            $fields[]=$field;
        }
    }
    echo JSON_encode($fields);
        
    