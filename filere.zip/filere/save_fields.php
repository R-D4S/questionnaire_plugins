<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $field=$_GET['field'];
    $form=$_GET['form'];
    //check and update
    $DB->delete_records('filere_fields', ['courseid'=>$course, 'activityid'=>$quiz, 'form'=>$form]);
    $DB->insert_record('filere_fields', ['fieldid'=>$field, 'courseid'=>$course, 'activityid'=>$quiz, 'form'=>$form]);



    
?>