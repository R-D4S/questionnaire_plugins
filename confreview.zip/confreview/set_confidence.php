<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $reviewer=$_GET['reviewer'];
    $student=$_GET['student'];
    $attempt=$_GET['attempt'];
    $confidence=$_GET['confidence'];
    $DB->delete_records('confreview_confidence', ['courseid'=>$course, 'activityid'=>$quiz, 'student'=>$student, 'attempt'=>$attempt, 'reviewer'=>$reviewer]);
    if($confidence!=='n'){
        $DB->insert_record('confreview_confidence', ['courseid'=>$course, 'activityid'=>$quiz, 'student'=>$student, 'attempt'=>$attempt, 'reviewer'=>$reviewer, 'confidence'=>$confidence]);
    }

