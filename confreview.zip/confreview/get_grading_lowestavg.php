<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $grading=$DB->get_record('confreview_grading', ['courseid'=>$course, 'activityid'=>$quiz]);

    echo JSON_encode($grading->lowestavg);
        
    