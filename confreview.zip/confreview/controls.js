var selection_quiz='';
var words=[];
function selectQuiz(course, squiz, w){
    selection_quiz=squiz;
    words=JSON.parse(w);
    window.addEventListener('DOMContentLoaded', (event) => {
        var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confreview/get_quizes.php?course='+course;
        xmlHttp.open( 'GET', url); 
        var quizes;
        var res;
        xmlHttp.onload=function() {
            quizes=JSON.parse(xmlHttp.responseText);
            res=words['choose_quiz']+'<br> ';
            res+='<select id="quiz_selector_element" onchange="get_fields('+course+','+squiz+')">';
            res+='<option value="-1"></option>';
            for(var i=0; i<quizes.length; i++){
                res+='<option value="'+quizes[i]['id']+'">'+quizes[i]['name']+'</option>';
            }
            res+='</select>';
            document.getElementById("select_quiz").innerHTML=res;
        };
        xmlHttp.send(null);
    });
    
    
}

function get_fields(course, form){
    var quiz=document.getElementById('quiz_selector_element').value;
    grading(course, quiz, form);
    var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confreview/get_fields.php?quiz='+quiz+'&course='+course;
        xmlHttp.open( 'GET', url);         
        var res;
        xmlHttp.onload=function() {
            fields=JSON.parse(xmlHttp.responseText);
            res="<br>"+words['choose_fields_auth']+"<br>";
            
            for(var i=0; i<fields.length; i++){
                res+='<input type="checkbox" class="checkboxfieldauth" value="'+fields[i]['id']+'" onchange="save_fields_auth('+course+','+quiz+')"> '+fields[i]['text']+"<br>";
            }
            res+='<input type="checkbox" id="auth_rev_name" onchange="save_fields_auth('+course+','+quiz+')"> <b>'+words['auth_rev_name']+"</b><br>";
            res+='<input type="checkbox" id="auth_rev_grade" onchange="save_fields_auth('+course+','+quiz+')"> <b>'+words['auth_rev_grade']+"</b><br>";
            res+='<input type="checkbox" id="auth_rev_conf" onchange="save_fields_auth('+course+','+quiz+')"> <b>'+words['auth_rev_conf']+"</b><br>";
            res+='<input type="checkbox" id="auth_rev_review" onchange="save_fields_auth('+course+','+quiz+')"> <b>'+words['auth_rev_review']+"</b><br>";
            res+='<input type="checkbox" id="auth_ed_name" onchange="save_fields_auth('+course+','+quiz+')"> <b>'+words['auth_ed_name']+"</b><br>";
            res+='<input type="checkbox" id="auth_ed_dis" onchange="save_fields_auth('+course+','+quiz+')"> <b>'+words['auth_ed_dis']+"</b><br>";
            res+='<input type="hidden" id="auth_sup_name" checked >';
            res+='<input type="checkbox" id="auth_sup_dis" onchange="save_fields_auth('+course+','+quiz+')"> <b>'+words['auth_sup_dis']+"</b><br>";
            document.getElementById("select_field").innerHTML=res;
            get_fields_for_reviewer(course, form);
            get_fields_for_editor(course, form);
            get_fields_for_superviser(course, form);
        };
        xmlHttp.send(null);
}

function get_fields_for_reviewer(course, form){
    var quiz=document.getElementById('quiz_selector_element').value;
    grading(course, quiz, form);
    var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confreview/get_fields.php?quiz='+quiz+'&course='+course;
        xmlHttp.open( 'GET', url);         
        var res;
        xmlHttp.onload=function() {
            fields=JSON.parse(xmlHttp.responseText);
            res=res="<br>"+words['choose_fields_rev']+"<br>";
            
            for(var i=0; i<fields.length; i++){
                res+='<input type="checkbox" class="checkboxfield" value="'+fields[i]['id']+'" onchange="save_fields('+course+','+quiz+')"> '+fields[i]['text']+"<br>";
            }
            document.getElementById("select_field").innerHTML+=res;
        };
        xmlHttp.send(null);
}

function get_fields_for_editor(course, form){
    var quiz=document.getElementById('quiz_selector_element').value;
    grading(course, quiz, form);
    var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confreview/get_fields.php?quiz='+quiz+'&course='+course;
        xmlHttp.open( 'GET', url);         
        var res;
        xmlHttp.onload=function() {
            fields=JSON.parse(xmlHttp.responseText);
            res=res="<br>"+words['choose_fields_ed']+"<br>";;
            
            for(var i=0; i<fields.length; i++){
                res+='<input type="checkbox" class="checkboxfielded" value="'+fields[i]['id']+'" onchange="save_fields_ed('+course+','+quiz+')"> '+fields[i]['text']+"<br>";
            }
            res+='<input type="checkbox" id="ed_rev_name" onchange="save_fields_ed('+course+','+quiz+')"> <b>'+words['ed_rev_name']+"</b><br>";
            
            document.getElementById("select_field").innerHTML+=res;
        };
        xmlHttp.send(null);
}

function get_fields_for_superviser(course, form){
    var quiz=document.getElementById('quiz_selector_element').value;
    grading(course, quiz, form);
    var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confreview/get_fields.php?quiz='+quiz+'&course='+course;
        xmlHttp.open( 'GET', url);         
        var res;
        xmlHttp.onload=function() {
            fields=JSON.parse(xmlHttp.responseText);
            res=res="<br>"+words['choose_fields_sup']+"<br>";;
            
            for(var i=0; i<fields.length; i++){
                res+='<input type="checkbox" class="checkboxfieldsup" value="'+fields[i]['id']+'" onchange="save_fields_sup('+course+','+quiz+')"> '+fields[i]['text']+"<br>";
            }
             res+='<input type="checkbox" id="sup_rev_name" onchange="save_fields_sup('+course+','+quiz+')"> <b>'+words['sup_rev_name']+"</b><br>";
            res+='<input type="checkbox" id="sup_ed_name" onchange="save_fields_sup('+course+','+quiz+')"> <b>'+words['sup_ed_name']+"</b><br>";
           
            document.getElementById("select_field").innerHTML+=res;
        };
        xmlHttp.send(null);
}



function grading(course, quiz, form){
    
    var res='<br>'+words['grades_range']+':<br>';
    res+='<select id="grading_select" onchange="savegrading('+course+','+quiz+','+form+')">';    
    res+='<option value="1-5">'+words['1to5']+'</option>';
    res+='<option value="1-10">'+words['1to10']+'</option>';
    res+='<option value="1-100">'+words['1to100']+'</option>';
    res+='<option value="-3-3">'+words['-3to3']+'</option>';
    res+='</select>';
    document.getElementById('select_grading').innerHTML=res;
    lowest(course, quiz, form);
    lowestavg(course, quiz, form);
}

function lowest(course, quiz, form){
    var res='<br>'+words['passing_grade']+': <br>';
   
    res+='<input type="number" id="lowest" onchange="savegrading('+course+','+quiz+','+form+')">';
    document.getElementById("select_lowestgrade").innerHTML=res;
}

function lowestavg(course, quiz, form){
    var res='<br>'+words['passing_avg']+': <br>';
   
    res+='<input type="number" id="lowestavg"  onchange="savegrading('+course+','+quiz+','+form+')">';
    document.getElementById("select_lowestavg").innerHTML=res;
}

function savegrading(course, quiz, form){
    var grading=document.getElementById("grading_select").value;
    var lowest=document.getElementById("lowest").value;
    var lowestavg=document.getElementById("lowestavg").value;
    //console.log(document.getElementById("quiz_selector_element").value);
    var xmlHttp = new XMLHttpRequest();
    var url='/question/type/confreview/save_grading.php?quiz='+quiz+'&course='+course+"&grading="+grading+"&lowest="+lowest+"&lowestavg="+lowestavg+'&form='+form;
    xmlHttp.open( 'GET', url);  
    xmlHttp.onload=function() {
        //console.log(xmlHttp.response);

    };
    xmlHttp.send(null);
    
}


function save_fields(course, quiz){
    var chosen_fields=[];
    var fields=document.getElementsByClassName('checkboxfield');
    for (var i=0; i<fields.length; i++){
        if (fields[i].checked==true){
            chosen_fields.push(fields[i].value);
        }
    }
    var post=JSON.stringify(chosen_fields);
    var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confreview/save_fields.php?quiz='+quiz+'&course='+course+'&form='+selection_quiz;
        xmlHttp.open( 'POST', url);     
        xmlHttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xmlHttp.onload=function() {
           //console.log(xmlHttp.responseText);
            
        };
        xmlHttp.send(post);
}

function save_fields_auth(course, quiz){
    var chosen_fields=[];
    var fields=document.getElementsByClassName('checkboxfieldauth');
    for (var i=0; i<fields.length; i++){
        if (fields[i].checked==true){
            chosen_fields.push(fields[i].value);
        }
    }
    var formData=new FormData();
    formData.append('chosen_fields', JSON.stringify(chosen_fields));
    //console.log(formData);
    formData.append('auth_rev_name', document.getElementById('auth_rev_name').checked);
    formData.append('auth_rev_grade', document.getElementById('auth_rev_grade').checked);
    formData.append('auth_rev_conf', document.getElementById('auth_rev_conf').checked);
    formData.append('auth_rev_review', document.getElementById('auth_rev_review').checked);
    formData.append('auth_ed_name', document.getElementById('auth_ed_name').checked);
    formData.append('auth_ed_dis', document.getElementById('auth_ed_dis').checked);
    formData.append('auth_sup_name', document.getElementById('auth_sup_name').checked);
    formData.append('auth_sup_dis', document.getElementById('auth_sup_dis').checked);
    var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confreview/save_fields_auth.php?quiz='+quiz+'&course='+course+'&form='+selection_quiz;
        xmlHttp.open( 'POST', url);     
        //xmlHttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xmlHttp.onload=function() {
           //console.log(xmlHttp.responseText);
            
        };
        xmlHttp.send(formData);
}

function save_fields_ed(course, quiz){
    var chosen_fields=[];
    var fields=document.getElementsByClassName('checkboxfielded');
    for (var i=0; i<fields.length; i++){
        if (fields[i].checked==true){
            chosen_fields.push(fields[i].value);
        }
    }
    var post=JSON.stringify(chosen_fields);
    var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confreview/save_fields_ed.php?quiz='+quiz+'&course='+course+'&form='+selection_quiz+'&ed_rev_name='+document.getElementById('ed_rev_name').checked;
        xmlHttp.open( 'POST', url);     
        xmlHttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xmlHttp.onload=function() {
           //console.log(xmlHttp.responseText);
            
        };
        xmlHttp.send(post);
}

function save_fields_sup(course, quiz){
    var chosen_fields=[];
    var fields=document.getElementsByClassName('checkboxfieldsup');
    for (var i=0; i<fields.length; i++){
        if (fields[i].checked==true){
            chosen_fields.push(fields[i].value);
        }
    }
    var post=JSON.stringify(chosen_fields);
    var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confreview/save_fields_sup.php?quiz='+quiz+'&course='+course+'&form='+selection_quiz+
                '&sup_ed_name='+document.getElementById('sup_ed_name').checked+
                '&sup_rev_name='+document.getElementById('sup_rev_name').checked;
        xmlHttp.open( 'POST', url);     
        xmlHttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xmlHttp.onload=function() {
           //console.log(xmlHttp.responseText);
            
        };
        xmlHttp.send(post);
}

//function fill(course, form){
//    var xmlHttp = new XMLHttpRequest();
//    var url='/question/type/confreview/get_options.php?course='+course+'&form='+form;
//    xmlHttp.open( 'GET', url);    
//    xmlHttp.onload=function() {
//        window.addEventListener('load', (event) => {
//        
//            var options=JSON.parse(xmlHttp.responseText);
//            
//            //console.log(document.getElementById('quiz_selector_element'));
//            document.getElementById('quiz_selector_element').value=options['sub_form'];
//            if(document.getElementById('quiz_selector_element').value!='-1'){
//                get_fields(course, options['sub_form']);
//            }
//            var revfields=document.getElementsByClassName('checkboxfield');
//            console.log(revfields);
//            for(var i=0; i<revfields.length; i++){
//                console.log(i);
//                if (options['rev_fields'].includes(revfields[i].value)){
//                    console.log('hey');
//                    revfields[i].checked=true;
//                }
//            }
//            for(var key in options['rev_fields']){
//               // console.log(options['rev_fields'][key]);
//            }
//        });  
//    };
//    xmlHttp.send(null);
//    
//}



