<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $student=$_GET['student'];
    $attempt=$_GET['attempt'];
    $sql='select row_number() over ( order by lastname), lastname, firstname, grade, confidence, comment, review
 from mdl_confdist_distribution cd left outer join mdl_confreview_grades cg 
on (cg.activityid=cd.activityid and cg.student=cd.student and cg.attempt=cd.attempt 
and cg.courseid=cd.courseid and cd.reviewer=cg.reviewer) join mdl_user u on (cd.reviewer=u.id) left outer join mdl_confreview_confidence cc on 
(cc.activityid=cd.activityid and cc.student=cd.student and cc.attempt=cd.attempt 
and cc.courseid=cd.courseid and cd.reviewer=cc.reviewer)
left outer join mdl_confreview_comments cco on 
(cco.activityid=cd.activityid and cco.student=cd.student and cco.attempt=cd.attempt 
and cco.courseid=cd.courseid and cd.reviewer=cco.reviewer)
left outer join mdl_confreview_review cr on 
(cr.activityid=cd.activityid and cr.student=cd.student and cr.attempt=cd.attempt 
and cr.courseid=cd.courseid and cd.reviewer=cr.reviewer) where cd.activityid=? and cd.courseid=?
and cd.student=? and cd.attempt=?';
    $grades=$DB->get_records_sql($sql, [$quiz, $course, $student, $attempt]);
    foreach($grades as $grade){
        unset($grade->id);
    }
    echo JSON_encode($grades);
        
    