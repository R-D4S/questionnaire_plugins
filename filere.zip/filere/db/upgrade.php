<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * filere question type upgrade code.
 *
 * @package    qtype
 * @subpackage filere
 * @copyright  2011 The Open University
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade code for the filere question type.
 * @param int $oldversion the version we are upgrading from.
 */
function xmldb_qtype_filere_upgrade($oldversion) {
    global $CFG, $DB;

    $dbman = $DB->get_manager();

    // Automatically generated Moodle v3.3.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.4.0 release upgrade line.
    // Put any upgrade step following this.

    if ($oldversion < 2018021800) {

        // Add "filetypeslist" column to the question type options to save the allowed file types.
        $table = new xmldb_table('qtype_filere_options');
        $field = new xmldb_field('filetypeslist', XMLDB_TYPE_TEXT, null, null, null, null, null, 'responsetemplateformat');

        // Conditionally launch add field filetypeslist.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // filere savepoint reached.
        upgrade_plugin_savepoint(true, 2018021800, 'qtype', 'filere');
    }

    // Automatically generated Moodle v3.5.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.6.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.7.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.8.0 release upgrade line.
    // Put any upgrade step following this.
    if ($oldversion < 2019111801) {

        // Define field mandatory to be added to qtype_filere_options.
        $table = new xmldb_table('qtype_filere_options');
        $field = new xmldb_field('mandatory', XMLDB_TYPE_CHAR, '1', null, null, null, null, 'filetypeslist');

        // Conditionally launch add field mandatory.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Filere savepoint reached.
        upgrade_plugin_savepoint(true, 2019111801, 'qtype', 'filere');
    }
    
        if ($oldversion < 2019111802) {

        // Define table filere_fields to be created.
        $table = new xmldb_table('filere_fields');

        // Adding fields to table filere_fields.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('fieldid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('form', XMLDB_TYPE_INTEGER, '10', null, null, null, null);

        // Adding keys to table filere_fields.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for filere_fields.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Filere savepoint reached.
        upgrade_plugin_savepoint(true, 2019111802, 'qtype', 'filere');
    }
    
        if ($oldversion < 2019111803) {

        // Define table conf_files to be created.
        $table = new xmldb_table('conf_files');

        // Adding fields to table conf_files.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('attemptid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('quizid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('cmid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('questionname', XMLDB_TYPE_CHAR, '255', null, null, null, null);
        $table->add_field('filename', XMLDB_TYPE_CHAR, '255', null, null, null, null);

        // Adding keys to table conf_files.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for conf_files.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Filere savepoint reached.
        upgrade_plugin_savepoint(true, 2019111803, 'qtype', 'filere');
    }


    return true;
}
