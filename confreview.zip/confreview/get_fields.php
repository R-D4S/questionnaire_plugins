<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    //какие поля выводить
    //настраивает пользователь с правами редактирования на курсе
    if (empty(has_capability('moodle/course:update', $context))){
        echo "Forbidden";
    }
    else{

        $quiz=$_GET['quiz'];
        $course=$_GET['course'];
        $submissions=$DB->get_records('conf_submission', ['courseid'=>$course, 'quizid'=>$quiz]);
        $fields=[];
        foreach($submissions as $submission){
            $field=['id'=>$submission->quiestionid, 'text'=>$submission->questiontext];
            if(!in_array($field, $fields)){
                $fields[]=$field;
            }
        }
        $files=$DB->get_records('conf_files', ['courseid'=>$course, 'quizid'=>$quiz]);
        foreach($files as $file){
            $field=['id'=>'-'.$file->cmid, 'text'=>$file->questionname];
            if(!in_array($field, $fields)){
                $fields[]=$field;
            }
        }
        echo JSON_encode($fields);
        
    }