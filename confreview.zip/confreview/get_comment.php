<?php
    require_once'../../../config.php';
    global $DB;
    
    
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $reviewer=$_GET['reviewer'];
    $student=$_GET['student'];
    $attempt=$_GET['attempt'];
    $comment=$DB->get_record('confreview_comments', ['courseid'=>$course, 'activityid'=>$quiz, 'student'=>$student, 'attempt'=>$attempt, 'reviewer'=>$reviewer]);
    if(!empty($comment)){
        echo $comment->comment;
        
    }
    else{
        echo '';
    }
        
    