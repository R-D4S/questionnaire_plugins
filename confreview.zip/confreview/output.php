<?php

function confreview_hide(){
        
        $res="<script>";
        $res.='document.addEventListener("DOMContentLoaded", function(e) {';
      
    
        $res.="var elements=document.getElementsByClassName('info');";
        $res.="for (var i=0; i<elements.length; i++){";
        
        $res.="elements[i].style.display='none'";
        $res.="}";
        $res.="var elements=document.getElementsByClassName('mod_quiz-next-nav btn btn-primary');";
        $res.="for (var i=0; i<elements.length; i++){";
        $res.="if(i==0)";
        $res.="elements[i].style.display='none'";
        $res.="}";
        
        $res.="document.getElementById('mod_quiz_navblock').style.display='none';";
        
        
        $res.='var el=document.querySelectorAll("'."[role='main']".':last-of-type")[0];';//кавычки
        //$res.="el.innerHTML.replace(/<form.*>/gm, '<div>');";        
        //$res.="el.innerHTML.replace(/<\/form>/gm, '</div>');"; 
        //$res.="console.log(el)";
        $res.=' });';
        
        $res.="</script>";
        
        echo $res;
    }
    
    function confreview_output_table(){
        global $DB;
        global $USER;
        $userid=$USER->id;
        $formid=$_GET['cmid'];
        $fields=$DB->get_records('confreview_fields', ['form'=>$formid]);
        $activity='';
        $course='';
        $chosen_fields=[];
        $res='';
        foreach($fields as $value){
            $course=$value->courseid;
            $activity=$value->activityid;
            //$chosen_fields[]=$value->field;
        }
        if(count($DB->get_records('conf_submission', ['userid'=>$userid]))!=0){
            $res.=table_for_author().'<br>';
        }
        if(count($DB->get_records('confdist_reviewers_list', ['reviewer'=>$userid, 'courseid'=>$course, 'activityid'=>$activity]))==0){
            
        }
        else{
            $res.=table_for_reviewer().'<br>';
            
        }
        if(count($DB->get_records('confdist_editors_list', ['editor'=>$userid, 'courseid'=>$course, 'activityid'=>$activity]))==0){
            
        }
        else{
            $res.=table_for_editor().'<br>';
            
        }
         if(count($DB->get_records('confdist_chairmen_list', ['chairman'=>$userid, 'courseid'=>$course, 'activityid'=>$activity]))==0){
            
        }
        else{
            $res.=table_for_chairman().'<br>';
            
        }
        return $res;
    }
    
    function table_for_reviewer(){
        echo '<script type="text/javascript" src="../../question/type/confreview/grading.js"></script>';
        global $DB;
        global $USER;
        $userid=$USER->id;
        $formid=$_GET['cmid'];
        $fields=$DB->get_records('confreview_fields', ['form'=>$formid]);
        $activity='';
        $course='';
        $chosen_fields=[];
        $grades=['3'=>get_string('3grade', 'qtype_confreview'), '2'=>get_string('2grade', 'qtype_confreview'),
            '1'=>get_string('1grade', 'qtype_confreview'),
            '0'=>get_string('0grade', 'qtype_confreview'),'-1'=>get_string('-1grade', 'qtype_confreview'),
            '-2'=>get_string('-2grade', 'qtype_confreview'),'-3'=>get_string('-3grade', 'qtype_confreview')];
        $confidence=['5'=>get_string('5conf', 'qtype_confreview'), '4'=>get_string('4conf', 'qtype_confreview'),
            '3'=>get_string('3conf', 'qtype_confreview'),
            '2'=>get_string('2conf', 'qtype_confreview'),'1'=>get_string('1conf', 'qtype_confreview')];
        $confidence=JSON_encode($confidence);
        $grades=JSON_encode($grades);
        foreach($fields as $value){
            $course=$value->courseid;
            $activity=$value->activityid;
            $chosen_fields[]=$value->fieldid;
        }
        $sql="select distinct cs.attemptid, cs.userid from mdl_conf_submission cs join mdl_confdist_distribution cd on (cs.courseid=cd.courseid
and cs.quizid=cd.activityid and cs.userid=cd.student and cs.attemptid=cd.attempt) where cd.reviewer=? and cs.courseid=? and cs.quizid=?";
        $submissions=$DB->get_records_sql($sql, [$userid, $course, $activity]);
        //var_dump($submissions);
        $sql="select cs.id, userid, attemptid, quiestionid, questiontext, answer from mdl_conf_submission cs join mdl_confdist_distribution cd on (cs.courseid=cd.courseid
and cs.quizid=cd.activityid and cs.userid=cd.student and cs.attemptid=cd.attempt) where cd.reviewer=? and cs.courseid=? and cs.quizid=?";
        $answers=$DB->get_records_sql($sql, [$userid, $course, $activity]);
        $sql="select cs.id, userid, attemptid, concat('-', cmid) as quiestionid, questionname as questiontext, filename as answer from mdl_conf_files cs join mdl_confdist_distribution cd on (cs.courseid=cd.courseid
and cs.quizid=cd.activityid and cs.userid=cd.student and cs.attemptid=cd.attempt) where cd.reviewer=? and cs.courseid=? and cs.quizid=?";
        $answers2=$DB->get_records_sql($sql, [$userid, $course, $activity]);
        foreach($answers2 as $key=>$value){
            if($answers2[$key]->answer!==''){
                $answers2[$key]->answer='<a href="../../question/type/confdist/save_file.php?file='.$answers2[$key]->answer.'">'.$answers2[$key]->answer.'</a>';
            }
        }
        $answers=array_merge($answers, $answers2);
        //var_dump($answers);
        $headers=[];
        foreach($answers as $ans){
            if(!in_array($ans->questiontext, $headers) && in_array($ans->quiestionid, $chosen_fields)){
                $headers[]=$ans->questiontext;
            }
        }
        $headers_string='<thead>';
        foreach($headers as $header){
            $headers_string.='<th style="cursor:pointer">'.$header.'</th>';
        }
        
        $headers_string.="<th>".get_string('show_review', 'qtype_confreview')."</th><th>".get_string('comment_for_ed', 'qtype_confreview')
                ."</th><th>".get_string('rev_confidence', 'qtype_confreview')."</th><th>".get_string('grade', 'qtype_confreview')."</th></thead>";
        $res='<script type="text/javascript" src="../../question/type/confreview/sorttable.js"></script>';
        
        
        $res.='<h3 onclick="display_reviewers();" style="cursor:pointer" id="rev_header"><font id="rev_tri">&#9662;</font>'.get_string('reviewers_field', 'qtype_confreview').'</h3>';
        $res.="<table class='flexible  generalbox' id='rev_tab' style='font-size:small'>".$headers_string;
        foreach($submissions as $sub){
            $res.="<tr>";
            foreach($chosen_fields as $field){
                foreach($answers as $answer){
//                    echo ($sub->attemptid==$ans->attemptid);
                    
                    if (($sub->attemptid===$answer->attemptid) && ($sub->userid===$answer->userid) && ($answer->quiestionid===$field) ){
                        $res.="<td >".$answer->answer."</td>";
                    }
                    
                }
            }
            $res.="<td id='review_r".$userid."s".$sub->userid."c".$course."ac".$activity."at".$sub->attemptid."'></td>";
                    $res.="<script>review(".$userid.",".$sub->userid.",".$course.",".$activity.",".$sub->attemptid
                            .",'".get_string('view_review', 'qtype_confreview')
                            ."','".get_string('close_review', 'qtype_confreview')."','"
                            .get_string('review_header', 'qtype_confreview')
                            ."','".get_string('save_review', 'qtype_confreview')."');</script>";
            $res.="<td id='comment_r".$userid."s".$sub->userid."c".$course."ac".$activity."at".$sub->attemptid."'></td>";
                    $res.="<script>comment(".$userid.",".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.");</script>";
            $res.="<td id='conf_r".$userid."s".$sub->userid."c".$course."ac".$activity."at".$sub->attemptid."'></td>";
                    $res.="<script>confidence(".$userid.",".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.
                            ",'".$confidence."');</script>";
            $res.="<td id='grade_r".$userid."s".$sub->userid."c".$course."ac".$activity."at".$sub->attemptid."'></td>";
                    $res.="<script>grade(".$userid.",".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.
                            ",'".$grades."','".get_string('wrong_grade', 'qtype_confreview')."');</script>";
            $res.="</tr>";
        }
        $res.="</table>";
        $res.="<div id='review_div'></div>";
        //var_dump($res);
        return $res;
    }
    
    function table_for_editor(){
        echo '<script type="text/javascript" src="../../question/type/confreview/editing.js"></script>';
        $words=['ed_rev'=>get_string('ed_rev', 'qtype_confreview'),
            'reviews_button'=>get_string('reviews_button', 'qtype_confreview'),
            'close_rev_div'=>get_string('close_rev_div', 'qtype_confreview'),
            'show_review'=>get_string('show_review', 'qtype_confreview'),
            'review_header'=>get_string('review_header', 'qtype_confreview'),
            'reviews_header'=>get_string('reviews_header', 'qtype_confreview'),
            'no_review'=>get_string('no_review', 'qtype_confreview'),
            'reviewer'=>get_string('reviewer', 'qtype_confreview'),
            'review'=>get_string('review', 'qtype_confreview'),
            'reviewer_confidence'=>get_string('reviewer_confidence', 'qtype_confreview'),
            'grade'=>get_string('grade', 'qtype_confreview'),
            'comment'=>get_string('comment', 'qtype_confreview'),
            'accept'=>get_string('accept', 'qtype_confreview'),
            'decline'=>get_string('decline', 'qtype_confreview'),
            'correction'=>get_string('correction', 'qtype_confreview')];
        $words=JSON_encode($words);
        global $DB;
        global $USER;
        $userid=$USER->id;
        $formid=$_GET['cmid'];
        $fields=$DB->get_records('confreview_ed_fields', ['form'=>$formid]);
        $activity='';
        $course='';
        $chosen_fields=[];
        $field_names=[];
        foreach($fields as $value){
            $course=$value->courseid;
            $activity=$value->activityid;
            $chosen_fields[]=$value->fieldid;
        }
        $sql="select distinct cs.attemptid, cs.userid from mdl_conf_submission cs join mdl_confdist_editors_dist cd on (cs.courseid=cd.courseid
and cs.quizid=cd.activityid and cs.userid=cd.student and cs.attemptid=cd.attempt) where cd.editor=? and cs.courseid=? and cs.quizid=?";
        $submissions=$DB->get_records_sql($sql, [$userid, $course, $activity]);
        $sql="select cs.id, userid, attemptid, quiestionid, questiontext, answer from mdl_conf_submission cs join mdl_confdist_editors_dist cd on (cs.courseid=cd.courseid
and cs.quizid=cd.activityid and cs.userid=cd.student and cs.attemptid=cd.attempt) where cd.editor=? and cs.courseid=? and cs.quizid=?";
        $answers=$DB->get_records_sql($sql, [$userid, $course, $activity]);
        $sql="select cs.id, userid, attemptid, concat('-', cmid) as quiestionid, questionname as questiontext, 
            filename as answer from mdl_conf_files cs join mdl_confdist_editors_dist cd on (cs.courseid=cd.courseid
and cs.quizid=cd.activityid and cs.userid=cd.student and cs.attemptid=cd.attempt) where cd.editor=? and cs.courseid=? and cs.quizid=?";
        $answers2=$DB->get_records_sql($sql, [$userid, $course, $activity]);
        foreach($answers2 as $key=>$value){
            if($answers2[$key]->answer!==''){
                $answers2[$key]->answer='<a href="../../question/type/confdist/save_file.php?file='.$answers2[$key]->answer.'">'.$answers2[$key]->answer.'</a>';
            }
        }
        $answers=array_merge($answers, $answers2);
        $res='<div id="rev_wind" style="position:fixed; top:20%; left:30%; background-color:#EDFEFE  ; z-index:1000;visibility: hidden;'
                . 'overflow-y:auto; overflow-x:auto;max-height:70%;  box-sizing: border-box;
    padding: 5px;"></div>';
        $res.='<div id="rev_wind2" style="position:fixed; top:20%; left:30%; background-color:#EDFEEE ; width:50%; '
                . 'overflow-y:auto;  z-index:1001;visibility: hidden; max-height:70%; max-width:50%;box-sizing: border-box;
    padding: 5px;"></div>';
        $options=$DB->get_record('confreview_view_options', ['courseid'=>$course, 'form'=>$formid]);
        $options=JSON_encode($options);
        $res.="<script>set_options_editor('".$options."','".$words."')</script>";
         $res.='<h3 onclick="display_editors();" style="cursor:pointer" id="ed_header"><font id="ed_tri">&#9662;</font>'.get_string('editors_field', 'qtype_confreview').'</h3>';
        $res.="<table class='flexible  generalbox' style='font-size:small' id='ed_tab'>";
        $headers='<thead>';
        foreach($answers as $answer){
            if(!in_array($answer->questiontext, $field_names)&&(in_array($answer->quiestionid, $chosen_fields))){
                $field_names[]=$answer->questiontext;
            }
        }
        foreach($field_names as $header){
            $headers.='<th style="cursor:pointer">'.$header.'</th>';
        }
            $headers.='<th>'.get_string('reviews', 'qtype_confreview').'</th>';
            $headers.='<th><p style="writing-mode: vertical-rl">'.get_string('avg_grade', 'qtype_confreview').'</p></th>';
            $headers.='<th><p style="writing-mode: vertical-rl">'.get_string('min_grade', 'qtype_confreview').'</p></th>';;
            $headers.='<th><p style="writing-mode: vertical-rl">'.get_string('missing_reviews', 'qtype_confreview').'</p></th>';
            $headers.='<th>'.get_string('decision', 'qtype_confreview').'</th>';
        $headers.='</thead>';
        $res.=$headers;
        foreach($submissions as $sub){
            $res.="<tr>";
            foreach($chosen_fields as $field){
                foreach($answers as $answer){
//                   echo ($sub->attemptid==$ans->attemptid);
                    
                    
                    if (($sub->attemptid===$answer->attemptid) && ($sub->userid===$answer->userid) && ($answer->quiestionid===$field) ){
                        $res.="<td  class='att".$answer->attemptid."'>".$answer->answer."</td>";
                    }
                    
                }
            }
            
            $res.="<td  id='grades_s".$sub->userid."c".$course."ac".$activity."at".$sub->attemptid."'></td>";
            //$res.="<script>grades_for_editor(".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.','.$formid.");</script>";
            $res.="<td  id='grades_avg_s".$sub->userid."c".$course."ac".$activity."at".$sub->attemptid."' class='at".$answer->attemptid."'></td>";
            $res.="<script>grades_avg_for_editor(".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.");</script>";
            $res.="<td  id='grades_lowest_s".$sub->userid."c".$course."ac".$activity."at".$sub->attemptid."' class='at".$answer->attemptid."'></td>";
            $res.="<script>grades_lowest_for_editor(".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.");</script>";
            $res.="<td  id='grades_null_s".$sub->userid."c".$course."ac".$activity."at".$sub->attemptid."' class='att".$answer->attemptid."'></td>";
            $res.="<script>grades_null_for_editor(".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.");</script>";
            $res.="<td  id='approved_s".$sub->userid."c".$course."ac".$activity."at".$sub->attemptid."' class='at".$answer->attemptid."'></td>";
            $res.="<script>approved(".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.','.$userid.");</script>";
            $res.="</tr>";
            $res.="<script>grades_button(".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.','.$formid.");</script>";
        }
        $res.="</table>";
        return $res;
    }
    
    function table_for_chairman(){
        echo '<script type="text/javascript" src="../../question/type/confreview/chairman.js"></script>';
        $words=['ed_rev'=>get_string('ed_rev', 'qtype_confreview'),
            'reviews_button'=>get_string('reviews_button', 'qtype_confreview'),
            'close_rev_div'=>get_string('close_rev_div', 'qtype_confreview'),
            'show_review'=>get_string('show_review', 'qtype_confreview'),
            'review_header'=>get_string('review_header', 'qtype_confreview'),
            'reviews_header'=>get_string('reviews_header', 'qtype_confreview'),
            'no_review'=>get_string('no_review', 'qtype_confreview'),
            'reviewer'=>get_string('reviewer', 'qtype_confreview'),
            'review'=>get_string('review', 'qtype_confreview'),
            'reviewer_confidence'=>get_string('reviewer_confidence', 'qtype_confreview'),
            'grade'=>get_string('grade', 'qtype_confreview'),
            'comment'=>get_string('comment', 'qtype_confreview'),
            'accept'=>get_string('accept', 'qtype_confreview'),
            'decline'=>get_string('decline', 'qtype_confreview'),
            'correction'=>get_string('correction', 'qtype_confreview'),
            'final_decision'=>get_string('final_decision', 'qtype_confreview'),
            'r_and_d'=>get_string('r_and_d', 'qtype_confreview'),
            'r_and_d_btn'=>get_string('r_and_d_btn', 'qtype_confreview'),
            'dis_header'=>get_string('dis_header', 'qtype_confreview'),
            'editor'=>get_string('editor', 'qtype_confreview'),
            'ed_dis'=>get_string('ed_dis', 'qtype_confreview')];
        $words=JSON_encode($words);
        global $DB;
        global $USER;
        $userid=$USER->id;
        $formid=$_GET['cmid'];
        $fields=$DB->get_records('confreview_sup_fields', ['form'=>$formid]);
        $activity='';
        $course='';
        $chosen_fields=[];
        $field_names=[];
        foreach($fields as $value){
            $course=$value->courseid;
            $activity=$value->activityid;
            $chosen_fields[]=$value->fieldid;
        }
        $sql="select distinct cs.attemptid, cs.userid from mdl_conf_submission cs  where cs.courseid=? and cs.quizid=?";
        $submissions=$DB->get_records_sql($sql, [ $course, $activity]);
        $sql="select cs.id, userid, attemptid, quiestionid, questiontext, answer from mdl_conf_submission cs where cs.courseid=? and cs.quizid=?";
        $answers=$DB->get_records_sql($sql, [ $course, $activity]);
        $sql="select cs.id, userid, attemptid, concat('-', cmid) as quiestionid, questionname as questiontext, 
            filename as answer from mdl_conf_files cs where cs.courseid=? and cs.quizid=?";
        $answers2=$DB->get_records_sql($sql, [ $course, $activity]);
        foreach($answers2 as $key=>$value){
            if($answers2[$key]->answer!==''){
                $answers2[$key]->answer='<a href="../../question/type/confdist/save_file.php?file='.$answers2[$key]->answer.'">'.$answers2[$key]->answer.'</a>';
            }
        }
        $answers=array_merge($answers, $answers2);
        $res='<div id="sup_wind" style="position:fixed; top:20%; left:30%; background-color:#EDFEFE  ; z-index:1000;visibility: hidden;'
                . 'overflow-y:auto; overflow-x:auto;max-height:70%;  box-sizing: border-box;
    padding: 5px;"></div>';
        $res.='<div id="sup_wind2" style="position:fixed; top:20%; left:30%; background-color:#EDFEEE ; width:50%; '
                . 'overflow-y:auto;  z-index:1001;visibility: hidden; max-height:70%; max-width:50%;box-sizing: border-box;
    padding: 5px;"></div>';
        $options=$DB->get_record('confreview_view_options', ['courseid'=>$course, 'form'=>$formid]);
        $options=JSON_encode($options);
        $res.="<script>set_options_chairman('".$options."','".$words."')</script>";
         $res.='<h3 onclick="display_chairmen();" style="cursor:pointer" id="sup_header"><font id="sup_tri">&#9662;</font>'.get_string('chairmen_field', 'qtype_confreview').'</h3>';
        $res.="<table class='flexible  generalbox' style='font-size:small' id='sup_tab'>";
        $headers='<thead>';
        foreach($answers as $answer){
            if(!in_array($answer->questiontext, $field_names)&&(in_array($answer->quiestionid, $chosen_fields))){
                $field_names[]=$answer->questiontext;
            }
        }
        foreach($field_names as $header){
            $headers.='<th style="cursor:pointer">'.$header.'</th>';
        }
            $headers.='<th>'.get_string('r_and_d', 'qtype_confreview').'</th>';
            $headers.='<th><p style="writing-mode: vertical-rl">'.get_string('avg_grade', 'qtype_confreview').'</p></th>';
            $headers.='<th><p style="writing-mode: vertical-rl">'.get_string('min_grade', 'qtype_confreview').'</p></th>';;
            $headers.='<th><p style="writing-mode: vertical-rl">'.get_string('missing_reviews', 'qtype_confreview').'</p></th>';
            $headers.='<th>'.get_string('final_decision', 'qtype_confreview').'</th>';
        $headers.='</thead>';
        $res.=$headers;
        foreach($submissions as $sub){
            $res.="<tr>";
            foreach($chosen_fields as $field){
                foreach($answers as $answer){
//                   echo ($sub->attemptid==$ans->attemptid);
                    
                    
                    if (($sub->attemptid===$answer->attemptid) && ($sub->userid===$answer->userid) && ($answer->quiestionid===$field) ){
                        $res.="<td  class='att".$answer->attemptid."'>".$answer->answer."</td>";
                    }
                    
                }
            }
            
            $res.="<td  id='sup_grades_s".$sub->userid."c".$course."ac".$activity."at".$sub->attemptid."'></td>";
            //$res.="<script>grades_for_editor(".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.','.$formid.");</script>";
            $res.="<td  id='sup_grades_avg_s".$sub->userid."c".$course."ac".$activity."at".$sub->attemptid."' class='at".$answer->attemptid."'></td>";
            $res.="<script>grades_avg_for_chairman(".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.");</script>";
            $res.="<td  id='sup_grades_lowest_s".$sub->userid."c".$course."ac".$activity."at".$sub->attemptid."' class='at".$answer->attemptid."'></td>";
            $res.="<script>grades_lowest_for_chairman(".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.");</script>";
            $res.="<td  id='sup_grades_null_s".$sub->userid."c".$course."ac".$activity."at".$sub->attemptid."' class='att".$answer->attemptid."'></td>";
            $res.="<script>grades_null_for_chairman(".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.");</script>";
            $res.="<td  id='sup_approved_s".$sub->userid."c".$course."ac".$activity."at".$sub->attemptid."' class='at".$answer->attemptid."'></td>";
            $res.="<script>approved_by_chairman(".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.','.$userid.");</script>";
            $res.="</tr>";
            $res.="<script>grades_button_for_chairman(".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.','.$formid.");</script>";
        }
        $res.="</table>";
        return $res;
    }
    
    function table_for_author(){
        echo '<script type="text/javascript" src="../../question/type/confreview/author.js"></script>';
        $words=['ed_rev'=>get_string('ed_rev', 'qtype_confreview'),
            'reviews_button'=>get_string('hidden', 'qtype_confreview'),
            'close_rev_div'=>get_string('close_rev_div', 'qtype_confreview'),
            'show_review'=>get_string('show_review', 'qtype_confreview'),
            'review_header'=>get_string('review_header', 'qtype_confreview'),
            'reviews_header'=>get_string('reviews_header', 'qtype_confreview'),
            'no_review'=>get_string('no_review', 'qtype_confreview'),
            'reviewer'=>get_string('reviewer', 'qtype_confreview'),
            'review'=>get_string('review', 'qtype_confreview'),
            'reviewer_confidence'=>get_string('reviewer_confidence', 'qtype_confreview'),
            'grade'=>get_string('grade', 'qtype_confreview'),
            'comment'=>get_string('comment', 'qtype_confreview'),
            'accept'=>get_string('accept', 'qtype_confreview'),
            'decline'=>get_string('decline', 'qtype_confreview'),
            'correction'=>get_string('correction', 'qtype_confreview'),
            'final_decision'=>get_string('final_decision', 'qtype_confreview'),
            'r_and_d'=>get_string('r_and_d', 'qtype_confreview'),
            'r_and_d_btn'=>get_string('r_and_d_btn', 'qtype_confreview'),
            'dis_header'=>get_string('dis_header', 'qtype_confreview'),
            'editor'=>get_string('editor', 'qtype_confreview'),
            'ed_dis'=>get_string('ed_dis', 'qtype_confreview'),
            'hidden'=>get_string('hidden', 'qtype_confreview')];
        $words=JSON_encode($words);
        global $DB;
        global $USER;
        $userid=$USER->id;
        $formid=$_GET['cmid'];
        $fields=$DB->get_records('confreview_au_fields', ['form'=>$formid]);
        $activity='';
        $course='';
        $chosen_fields=[];
        $field_names=[];
        foreach($fields as $value){
            $course=$value->courseid;
            $activity=$value->activityid;
            $chosen_fields[]=$value->fieldid;
        }
        $sql="select distinct cs.attemptid, cs.userid from mdl_conf_submission cs  where cs.courseid=? and cs.quizid=? and cs.userid=?";
        $submissions=$DB->get_records_sql($sql, [ $course, $activity, $userid]);
        $sql="select cs.id, userid, attemptid, quiestionid, questiontext, answer from mdl_conf_submission cs where cs.courseid=? and cs.quizid=? and cs.userid=?";
        $answers=$DB->get_records_sql($sql, [ $course, $activity, $userid]);
        $sql="select cs.id, userid, attemptid, concat('-', cmid) as quiestionid, questionname as questiontext, 
            filename as answer from mdl_conf_files cs where cs.courseid=? and cs.quizid=? and cs.userid=?";
        $answers2=$DB->get_records_sql($sql, [ $course, $activity, $userid]);
        foreach($answers2 as $key=>$value){
            if($answers2[$key]->answer!==''){
                $answers2[$key]->answer='<a href="../../question/type/confdist/save_file.php?file='.$answers2[$key]->answer.'">'.$answers2[$key]->answer.'</a>';
            }
        }
        $answers=array_merge($answers, $answers2);
        $res='<div id="au_wind" style="position:fixed; top:20%; left:30%; background-color:#EDFEFE  ; z-index:1000;visibility: hidden;'
                . 'overflow-y:auto; overflow-x:auto;max-height:70%;  box-sizing: border-box;
    padding: 5px;"></div>';
        $res.='<div id="au_wind2" style="position:fixed; top:20%; left:30%; background-color:#EDFEEE ; width:50%; '
                . 'overflow-y:auto;  z-index:1001;visibility: hidden; max-height:70%; max-width:50%;box-sizing: border-box;
    padding: 5px;"></div>';
        $options=$DB->get_record('confreview_view_options', ['courseid'=>$course, 'form'=>$formid]);
        $options=JSON_encode($options);
        $res.="<script>set_options_author('".$options."','".$words."')</script>";
         $res.='<h3 onclick="display_authors();" style="cursor:pointer" id="au_header"><font id="au_tri">&#9662;</font>'.get_string('author_field', 'qtype_confreview').'</h3>';
        $res.="<table class='flexible  generalbox' style='font-size:small' id='au_tab'>";
        $headers='<thead>';
        foreach($answers as $answer){
            if(!in_array($answer->questiontext, $field_names)&&(in_array($answer->quiestionid, $chosen_fields))){
                $field_names[]=$answer->questiontext;
            }
        }
        foreach($field_names as $header){
            $headers.='<th style="cursor:pointer">'.$header.'</th>';
        }
            $headers.='<th>'.get_string('r_and_d', 'qtype_confreview').'</th>';
            $headers.='<th>'.get_string('final_decision', 'qtype_confreview').'</th>';
        $headers.='</thead>';
        $res.=$headers;
        foreach($submissions as $sub){
            $res.="<tr>";
            foreach($chosen_fields as $field){
                foreach($answers as $answer){
//                   echo ($sub->attemptid==$ans->attemptid);
                    
                    
                    if (($sub->attemptid===$answer->attemptid) && ($sub->userid===$answer->userid) && ($answer->quiestionid===$field) ){
                        $res.="<td  class='att".$answer->attemptid."'>".$answer->answer."</td>";
                    }
                    
                }
            }
            
            $res.="<td  id='au_grades_s".$sub->userid."c".$course."ac".$activity."at".$sub->attemptid."'></td>";
            //$res.="<script>grades_for_editor(".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.','.$formid.");</script>";
            $res.="<td  id='au_approved_s".$sub->userid."c".$course."ac".$activity."at".$sub->attemptid."' class='at".$answer->attemptid."'></td>";
            $res.="<script>approved_for_author(".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.','.$userid.");</script>";
            $res.="</tr>";
            $res.="<script>grades_button_for_author(".$sub->userid.",".$course.",".$activity.",".$sub->attemptid.','.$formid.");</script>";
        }
        $res.="</table>";
        return $res;
    }
    
    function conftopic_get_topics(){
        global $DB;
        global $USER;
        $userid=$USER->id;
        
        $formid=$_GET['cmid'];
        $fields=$DB->get_records('conftopic_fields', ['form'=>$formid]);
        $field='';
        $activity='';
        $course='';
        foreach($fields as $value){
            $field=$value->fieldid;
            $course=$value->courseid;
            $activity=$value->activityid;
        }
        
            $submissions=$DB->get_records('conf_submission', ['courseid'=>$course, 'quizid'=>$activity]);
            $topics=[];
            foreach($submissions as $submission){
                if($submission->quiestionid==$field){
                    $topics[]=$submission->answer;
                }
            }
            return $topics;
        
    }
    
    function conftopic_output_chosen_topics(){
        global $DB;
        global $USER;
        $userid=$USER->id;
        
        $formid=$_GET['cmid'];
        $fields=$DB->get_records('conftopic_fields', ['form'=>$formid]);
        $activity='';
        $course='';
        foreach($fields as $value){
            $course=$value->courseid;
            $activity=$value->activityid;
        }
        $topics=$DB->get_records('conf_chosen_topics', ['activityid'=>$activity, 'courseid'=>$course, 'reviewer'=>$userid]);
        $res='<br>Выбранные темы!<br>';
        foreach($topics as $topic){
            $res.=$topic->topic.'<br>';
        }
        $res.='<br>';
        return $res;
    }

