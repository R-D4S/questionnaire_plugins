<?php
    require_once'../../../config.php';
    global $DB;
    $review=$_POST['review'];
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $reviewer=$_GET['reviewer'];
    $student=$_GET['student'];
    $attempt=$_GET['attempt'];
    
    $DB->delete_records('confreview_review', ['courseid'=>$course, 'activityid'=>$quiz, 'student'=>$student, 'attempt'=>$attempt, 'reviewer'=>$reviewer]);

    $DB->insert_record('confreview_review', ['courseid'=>$course, 'activityid'=>$quiz, 'student'=>$student, 'attempt'=>$attempt, 'reviewer'=>$reviewer, 'review'=>$review]);


