var options=[];
var words=[];
var reviews=[];
function set_options_editor(op, w){
    options=JSON.parse(op);
    words=JSON.parse(w);
    words['reviews_button']='<font style="font-size:small">'+words['reviews_button']+'</font>';
    words['show_review']='<font style="font-size:small">'+words['show_review']+'</font>';
}


function grades_button(student, course, activity, attempt, form){
    var res='';
    res+='<button class="btn btn-secondary" onclick="grades_for_editor('+student+','+course+','+activity+','+attempt+','+form+')"><font style="font-size:small">'+words['reviews_button']+'</font></button>';
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    document.getElementById('grades_'+tdid).innerHTML=res;
}
function close_rev_div(){
    document.getElementById('rev_wind').style.visibility='hidden';
}
function close_rev_div2(){
    document.getElementById('rev_wind2').style.visibility='hidden';
    document.getElementById('rev_wind').style.visibility='visible';
}

function show_review_to_editor(key){
    var review=reviews[key];
    var res='<h5 style="text-align:right; margin-right:4px; cursor:pointer" onclick="close_rev_div2()">'+words['close_rev_div']+'</h5>';
    res+='<h4>'+words['review_header']+'</h5>';
    if(review!=='null'){
        review=review.replace('&', '&amp;');
        review=review.replace('<', '&lt;');
        res+=review;
    }
    else
        res+=words['no_review'];
    document.getElementById('rev_wind2').innerHTML=res;
    document.getElementById('rev_wind2').style.visibility='visible';
    document.getElementById('rev_wind').style.visibility='hidden';
}
function grades_for_editor(student, course, activity, attempt, form){
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var res='';
    var grades=[];
    var xmlHttp3 = new XMLHttpRequest();
    var url='/question/type/confreview/get_reviews.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt;
    xmlHttp3.open( 'GET', url);         

    xmlHttp3.onload=function() {
        grades=JSON.parse(xmlHttp3.responseText);
//        console.log(grades);
        res+='<h5 style="text-align:right; margin-right:4px; cursor:pointer" onclick="close_rev_div()">'+words['close_rev_div']+'</h5>';
        res+='<h4>'+words['reviews_header']+'</h4>';
        res+='<div><table class="flexible  generalbox" style="font-size:small">';
        res+='<thead><th>'+words['reviewer']+'</th><th>'+words['review']
                +'</th><th>'+words['comment']+
                '</th><th>'+words['reviewer_confidence']+
                '</th><th>'+words['grade']+'</th>';
        var q=1;
        var span=0;
        for (var key in grades){
            span++;
            res+='<tr >';
            if(options['ed_rev_name']=='1'){
                res+='<td>'+grades[key]['lastname']+' '+grades[key]['firstname']+'</td>';
            }
            else{
                res+='<td>'+words['reviewer']+' '+q+'</td>';
                q++;
            }
                reviews[key]=grades[key]['review'];
            res+='<td><button class="btn btn-secondary" onclick="show_review_to_editor('+"'"+key+"'"+')">'+words['show_review']+'</button></td>';
            if(grades[key]['comment']!==null){
                res+='<td>'+grades[key]['comment']+'</td>';
            }
            else{
                res+='<td></td>';
            }
            if(grades[key]['confidence']!==null){
                res+='<td>'+grades[key]['confidence']+'</td>';
            }
            else{
                res+='<td>-</td>';
            }
            if(grades[key]['grade']!==null){
                res+='<td>'+grades[key]['grade']+'</td>';
            }
            else{
                res+='<td>-</td>';
            }
            res+='</tr>';
            
        }
        
//        var cells=document.getElementsByClassName('at'+attempt);
//        for (var i=0; i<cells.length; i++){
//            cells[i].rowSpan=span;
//        }
        res+="</table></div>";
        document.getElementById('rev_wind').innerHTML=res;
        document.getElementById('rev_wind').style.visibility='visible';
    };
    xmlHttp3.send(null);
    
    
}

function grades_avg_for_editor(student, course, activity, attempt){
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var res='';
    var grades=[];
    var xmlHttp3 = new XMLHttpRequest();
    var url='/question/type/confreview/get_reviews_avg.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt;
    xmlHttp3.open( 'GET', url);         

    xmlHttp3.onload=function() {
        res+=parseFloat(xmlHttp3.responseText).toFixed(2);
        var xmlHttp4 = new XMLHttpRequest();
        var url='/question/type/confreview/get_grading_lowestavg.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt;
        xmlHttp4.open( 'GET', url);         

        xmlHttp4.onload=function() {
            if(res!='NaN'){
            document.getElementById('grades_avg_'+tdid).innerHTML=res;
        }
            
            var lowestgrade=xmlHttp4.responseText;
            
            
            if(parseFloat(lowestgrade.replace('"', '').replace('"', ''))>parseFloat(res)){
                document.getElementById('grades_avg_'+tdid).style.backgroundColor='#FFABAB';
            }
        };
        xmlHttp4.send(null);
    };
    xmlHttp3.send(null);
    
    
}

function grades_lowest_for_editor(student, course, activity, attempt){
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var res='';
    var grades=[];
    var xmlHttp3 = new XMLHttpRequest();
    var url='/question/type/confreview/get_reviews_lowest.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt;
    xmlHttp3.open( 'GET', url);         

    xmlHttp3.onload=function() {
        res+=xmlHttp3.responseText;
        var xmlHttp4 = new XMLHttpRequest();
        var url='/question/type/confreview/get_grading_lowest.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt;
        xmlHttp4.open( 'GET', url);         

        xmlHttp4.onload=function() {
            document.getElementById('grades_lowest_'+tdid).innerHTML=res;
            var lowestgrade=xmlHttp4.responseText;
//            console.log(res);
//            console.log(parseFloat(lowestgrade.replace('"', '').replace('"', '')));
            if(parseFloat(lowestgrade.replace('"', '').replace('"', ''))>parseFloat(res)){
                document.getElementById('grades_lowest_'+tdid).style.backgroundColor='#FFABAB';
            }
        };
        xmlHttp4.send(null);
    };
    xmlHttp3.send(null);
    
    
}

function grades_null_for_editor(student, course, activity, attempt){
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var res='';
    var grades=[];
    var xmlHttp3 = new XMLHttpRequest();
    var url='/question/type/confreview/get_reviews_null.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt;
    xmlHttp3.open( 'GET', url);         

    xmlHttp3.onload=function() {
        res+=xmlHttp3.responseText;
        document.getElementById('grades_null_'+tdid).innerHTML=res;
        if(parseFloat(res)>0){
                document.getElementById('grades_null_'+tdid).style.backgroundColor='#FFABAB';
            }
        
        
    };
    xmlHttp3.send(null);
    
    
}

function approved(student, course, activity, attempt, editor){
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var res='';
    res+="<select id='ed_dis_selector"+tdid+"' onchange='save_ed_dis("+student+','+course+','+ activity+','+attempt+','+editor+")'>";
    res+="<option value='-1' style='background-color:#ffffff'></option>";
    res+="<option value='0' style='background-color:#BDFFAB'>"+words['accept']+"</option>";
    res+="<option value='1'style='background-color:#FFFFAB'>"+words['correction']+"</option>";
    res+="<option value='2' style='background-color:#FFABAB'>"+words['decline']+"</option>";
    res+="</select>";
    document.getElementById('approved_'+tdid).innerHTML=res;
    
    var xmlHttp3 = new XMLHttpRequest();
    var url='/question/type/confreview/get_ed_decision.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt+'&editor='+editor;
    xmlHttp3.open( 'GET', url);         

    xmlHttp3.onload=function() {
        var decision=xmlHttp3.responseText;
        document.getElementById('ed_dis_selector'+tdid).value=decision;
        if(decision=='0'){
            document.getElementById('ed_dis_selector'+tdid).style.backgroundColor='#BDFFAB';
        }
        if(decision=='1'){
            document.getElementById('ed_dis_selector'+tdid).style.backgroundColor='#FFFFAB';
        }
        if(decision=='2'){
            document.getElementById('ed_dis_selector'+tdid).style.backgroundColor='#FFABAB';
        }
        
       // console.log(decision);
    };
    xmlHttp3.send(null);
    
}

//res+="<select id='ed_dis_selector' onchange='save_ed_dis("+student+','+course+','+ activity+','+attempt+','+editor+")'>";
function save_ed_dis(student, course, activity, attempt, editor){
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var decision=document.getElementById('ed_dis_selector'+tdid).value;
    if(decision=='0'){
        document.getElementById('ed_dis_selector'+tdid).style.backgroundColor='#BDFFAB';
    }
    if(decision=='1'){
        document.getElementById('ed_dis_selector'+tdid).style.backgroundColor='#FFFFAB';
    }
    if(decision=='2'){
        document.getElementById('ed_dis_selector'+tdid).style.backgroundColor='#FFABAB';
    }
    if(decision=='-1'){
        document.getElementById('ed_dis_selector'+tdid).style.backgroundColor='#FFffff';
    }  
    var xmlHttp3 = new XMLHttpRequest();
     var url='/question/type/confreview/save_ed_decision.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt+'&editor='+editor+'&dis='+decision;
    xmlHttp3.open( 'GET', url);         

    xmlHttp3.onload=function() {
        //console.log(xmlHttp3.responseText);
       
    };
    xmlHttp3.send(null);
}

function display_editors(){
    //вниз когда открыто
           //вправо когда закрыто
    if(document.getElementById('ed_tab').style.display=='none'){
        document.getElementById('ed_tab').style.display='block';
        document.getElementById('ed_tri').innerHTML='&#9662;';
    }
    else{
    document.getElementById('ed_tab').style.display='none';
    document.getElementById('ed_tri').innerHTML='&#9656;';
}
}



