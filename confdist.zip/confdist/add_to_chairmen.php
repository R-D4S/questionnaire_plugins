<?php
    //редактирование таблицы со списком рецензентов
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    if (empty(has_capability('moodle/course:update', $context))){
        echo "Forbidden";
    }
    else{
        $course=$_GET['courseid'];
        $activity=$_GET['activityid'];
        $chairman=$_GET['chairman'];
        if(check_chairmen($course, $activity, $chairman)){
            delete_chairman($course, $activity, $chairman);
        }
        else{
            add_to_chairmen($course, $activity, $chairman);
        }
    }
    
    function add_to_chairmen($course, $activity, $chairman){
        global $DB;
        $newrecord=new stdClass();
        $newrecord->courseid=$course;
        $newrecord->activityid=$activity;
        $newrecord->chairman=$chairman;
        
        
        $DB->insert_record("confdist_chairmen_list", $newrecord);
    }
    
    function check_chairmen($course, $activity, $chairman){
        global $DB;
        if ($DB->get_record('confdist_chairmen_list', ['courseid'=>$course, 'activityid'=>$activity, 'chairman'=>$chairman])==false)
                return false;
        else
            return true;        
    }
    
    function delete_chairman($course, $activity, $chairman){
        global $DB;
        $DB->delete_records('confdist_chairmen_list', ['courseid'=>$course, 'activityid'=>$activity, 'chairman'=>$chairman]);
        $DB->delete_records('confdist_chairmen_dist', ['courseid'=>$course, 'activityid'=>$activity, 'chairman'=>$chairman]);
    }
?>