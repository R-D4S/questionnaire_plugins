<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    if (empty(has_capability('moodle/course:update', $context))){
        echo "Forbidden";
    }
    else{
        $student=$_GET['student'];
        $reviewer=$_GET['reviewer'];
        $attempt=$_GET['attempt'];
        $course=$_GET['courseid'];
        $activity=$_GET['activityid'];
        $DB->delete_records('confdist_distribution', ['courseid'=>$course, 'activityid'=>$activity, 'student'=>$student, 'attempt'=>$attempt, 'reviewer'=>$reviewer]);
        
    }


?>
