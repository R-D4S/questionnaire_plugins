<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
   
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $form=$_GET['form'];
    $fields = file_get_contents( "php://input" );
    $fields = json_decode( $fields);
    //check and update
    check_field($quiz, $course);
    foreach($fields as $field){
        $DB->insert_record('confreview_fields', ['fieldid'=>$field, 'courseid'=>$course, 'activityid'=>$quiz, 'form'=>$form]);
    }
    
    
    function check_field($quiz, $course){
        global $DB;
        if (!($DB->get_record('confreview_fields', ['courseid'=>$course, 'activityid'=>$quiz])==false))
                $DB->delete_records('confreview_fields', ['courseid'=>$course, 'activityid'=>$quiz]);
        
    }
?>