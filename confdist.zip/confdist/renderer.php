<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Short answer question renderer class.
 *
 * @package    qtype
 * @subpackage confdist
 * @copyright  2009 The Open University
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


defined('MOODLE_INTERNAL') || die();


/**
 * Generates the output for short answer questions.
 *
 * @copyright  2009 The Open University
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class qtype_confdist_renderer extends qtype_renderer {
    
    public function formulation_and_controls(question_attempt $qa,
            question_display_options $options) {
        require 'confdist_edit_settings.php';
        require 'edit_reviewer.php';
        $question = $qa->get_question();
//        $rid=$question->id;
//        $quiz_info=$question->profiledata;
//        $allow_change=$question->usecase;
////        global $USER;
////        
////        foreach($qa->get_question()->get_answers() as $value){
////                        $mask=$value->answer;
////                    }
////        
////        if($profile_data=="0"){
////            $currentanswer = $qa->get_last_qt_var('answer');
////        }
////        else{
////            switch ($profile_data){
////                case "1":
////                    $currentanswer=$USER->lastname;
////                    break;
////                case "2":
////                    $currentanswer=$USER->firstname;
////                    break;
////                case "3":
////                    $currentanswer=$USER->middlename;
////                    break;
////                case "4":
////                    $currentanswer=$USER->email;
////                    break;
////                case "5":
////                    $currentanswer=$USER->city;
////                    break;
////                case "6":
////                    $currentanswer=$USER->country;
////                    break;
////                case "7":
////                    $currentanswer=$USER->idnumber;
////                    break;
////                case "8":
////                    $currentanswer=$USER->institution;
////                    break;
////                case "9":
////                    $currentanswer=$USER->department;
////                    break;
////                case "10":
////                    $currentanswer=$USER->phone;
////                    break;
////                case "11":
////                    $currentanswer=$USER->phone2;
////                    break;
////                case "12":
////                    $currentanswer=$USER->address;
////                    break;
////            }
////            if($qa->get_last_qt_var('answer')!=$currentanswer and $qa->get_last_qt_var('answer')!=''){
////                $currentanswer=$qa->get_last_qt_var('answer');
////            }
////        }
//
//        $inputname = $qa->get_qt_field_name('answer');
//        
//        $inputattributes = array(
//            'type' => 'text',
//            'name' => $inputname,
//            'value' => $currentanswer,
//            'id' => $inputname,
//            'size' => 80,
//            'class' => 'form-control d-inline',
//        );
//
//        if ($options->readonly or $allow_change=="1") {
//            $inputattributes['readonly'] = 'readonly';
//        }
//
//        $feedbackimg = '';
//        
//        if ($options->correctness) {
//            $answer = $question->get_matching_answer(array('answer' => $currentanswer));
//            if ($answer) {
//                $fraction = $answer->fraction;
//            } else {
//                $fraction = 0;
//            }
//            $inputattributes['class'] .= ' ' . $this->feedback_class($fraction);
//            $feedbackimg = $this->feedback_image($fraction);
//        }
//
          $questiontext ='<h2>'.$question->format_questiontext($qa).'</h2>';
//        $placeholder = false;
//        if (preg_match('/_____+/', $questiontext, $matches)) {
//            $placeholder = $matches[0];
//            $inputattributes['size'] = round(strlen($placeholder) * 1.1);
//        }
////        if (!empty($_GET['wqid'])&&$_GET['wqid']==$rid){
////            $input = '<a name="'.$rid.'"></a>'.html_writer::empty_tag('input', $inputattributes) . $feedbackimg.'<br>'.get_string('wrong','qtype_confdist').$this->check_format($qa);
////        }
//        else{
//            if($allow_change=="0"){
//                $input = html_writer::empty_tag('input', $inputattributes) . $feedbackimg;
//            }
//            else
//            {
//                $input = html_writer::empty_tag('input', $inputattributes) . $feedbackimg;
//            }
//        }
//
//        if ($placeholder) {
//            $inputinplace = html_writer::tag('label', get_string('answer'),
//                    array('for' => $inputattributes['id'], 'class' => 'accesshide'));
//            $inputinplace .= $input;
//            $questiontext = substr_replace($questiontext, $inputinplace,
//                    strpos($questiontext, $placeholder), strlen($placeholder));
//        }
//
          $result = html_writer::tag('div', $questiontext, array('class' => 'qtext'));
//
//        if (!$placeholder) {
//            $result .= html_writer::start_tag('div', array('class' => 'ablock form-inline'));
//            $result .= html_writer::tag('label', get_string('answer', 'qtype_confdist',
//                    html_writer::tag('span', $input, array('class' => 'answer'))),
//                    array('for' => $inputattributes['id']));
//            $result .= html_writer::end_tag('div');
//        }
//
//        if ($qa->get_state() == question_state::$invalid) {
//            $result .= html_writer::nonempty_tag('div',
//                    $question->get_validation_error(array('answer' => $currentanswer)),
//                    array('class' => 'validationerror'));
//        }
        global $USER;
        global $COURSE;
        $context = context_module::instance($COURSE->id);
        if (empty(has_capability('moodle/course:update', $context))){
            return "Forbidden";
        }
        else{
            //при загрузке страницы взять все элементы формы и прицепить их к диву и удалить их с формы
            confdist_hide();
            $result.=output_search_field($qa);
            $result.=output_reviewers($qa);
            $result.="<br><h4>".get_string('revandeddist', 'qtype_confdist')."</h4>";
            //$result.=fields_search($fields, $course_id, $activity_id);
            $result.='<div id="fields_selector"></div>';
            $result.='<br><table class="flexible generaltable generalbox" id="reviewers_distribution_table">';
            $result.=confdist_distribution($qa->get_question()->profiledata, $COURSE->id);
            //$result.=confdist_distribution($qa->get_question()->profiledata);
            $result.='</table>';
//            $result1.=output_reviewers($qa);
//            $result1.=confdist_distribution($qa);
//            //как-то через скрипты те сделать через элемент
//            $res='<script>';
//            $res.='var el=document.querySelectorAll("'."[role='main']".':last-of-type")[0];';//кавычки
//            $res.="el.innerHTML='';";
//            $res.="el.innerHTML='";=confdi
//            $res.=$result;
//            $res.=$result1;
//            $res.="';";
//            $res.="</script>";
//            echo ($res);
            $result.='<script>var form=document.getElementById("responseform");';
            $result.='var div=document.getElementsByClassName("formulation clearfix")[0];';
            $result.='var div_clone=div.cloneNode(true);';
            $result.='var parent_div=form.parentNode;';
            //console.log(parent_div);
            $result.='parent_div.appendChild(div_clone);';
            $result.="var parent_div2=parent_div.parentNode;";
            $result.='form.style.display="none";';
            $result.='div.remove();';
            $result.='parent_div2.style.width="90%"</script>';
            return $result;
        }
    }

//    public function specific_feedback(question_attempt $qa) {
//        $question = $qa->get_question();
//
//        $answer = $question->get_matching_answer(array('answer' => $qa->get_last_qt_var('answer')));
//        if (!$answer || !$answer->feedback) {
//            return '';
//        }
//
//        return $question->format_text($answer->feedback, $answer->feedbackformat,
//                $qa, 'question', 'answerfeedback', $answer->id);
//    }
//
//    public function correct_response(question_attempt $qa) {
//        //no need for correct response
////        $question = $qa->get_question();
////        $answer = $question->get_matching_answer($question->get_correct_response());
////        if (!$answer) {
////            return '';            
////        }
//
//        //return get_string('correctansweris', 'qtype_confdist',
//                //s($question->clean_response($answer->answer)));
//        return '';
//    }
//    
//    public function check_format($qa){
//        $slot=$qa->get_slot();
//        foreach($qa->get_question()->get_answers() as $value){
//                        $mask=$value->answer;
//                    }
//        $mask='/'.$mask.'/';
//        $qa_id=$qa->get_usage_id();
//        $field_id="q".$qa_id.":".$slot."_answer";
//        $res="<script>";
//        $res.="var mask".$slot."=".$mask.";";
//        $res.="var f".$slot."=document.getElementById('".$field_id."');";
//        
//        $res.="f".$slot.".onkeyup=function(){";
//        $res.="var found=f".$slot.".value.match(mask".$slot.");";
//        $res.="if(found===null){";
//        $res.="f".$slot.".style.color='red';";
//        $res.="}";
//        $res.="else{";
//        $res.="f".$slot.".style.color='black';";
//        $res.="}";
//        $res.="};";
//        $res.="</script>";
//        //var_dump($qa);
//        return $res;
//    }
}
