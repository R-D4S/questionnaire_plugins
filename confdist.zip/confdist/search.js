words=[];

function set_options(w){
    words=JSON.parse(w);
}
function search(){
    var search_value=document.getElementById("searchfield").value.toLowerCase();
    var users_table=document.getElementById("users_list");
    for (var i=0; i<users_table.rows.length; i++){
        for (var j=0; j<users_table.rows[i].cells.length; j++){
            if (users_table.rows[i].cells[j].className=='lastname'){
                if (users_table.rows[i].cells[j].innerHTML.toLowerCase().indexOf(search_value)==-1){
                    users_table.rows[i].style.display='none';
                }
                else{
                    users_table.rows[i].style.display='';
                }
            }
        }
    }
}

function search_by_role(){
    search();
    var checkboxes=document.getElementsByClassName("role_checkbox");
    var checked_roles=[];
    for (var i=0; i<checkboxes.length; i++){
        if(checkboxes[i].checked==true){
            checked_roles.push(checkboxes[i].value);
        }
    }
    var users_table=document.getElementById("users_list");
    for (var i=0; i<users_table.rows.length; i++){
        for (var j=0; j<users_table.rows[i].cells.length; j++){
            if (users_table.rows[i].cells[j].className==='roles'){
                var roles=[];
                roles=users_table.rows[i].cells[j].innerHTML.split(', ');
                var flag=0;
                for (var k=0; k<roles.length; k++){
                    for (var m=0; m<checked_roles.length; m++){
                        if (roles[k]===checked_roles[m]){
                            
                            flag=1;
                        }
                    }
                }
                if(flag==0 && users_table.rows[i].style.display===''){
                    users_table.rows[i].style.display='none';
                }
            }
        }
    }
}

function add_to_revs(rev, courseid, activity, qa){
    if(document.getElementById("checkbox_rev"+rev).checked==false){
        if (confirm(words['sure_rev'])) {
            var xmlHttp = new XMLHttpRequest();
            var url='/question/type/confdist/add_to_revs.php?courseid='+courseid+'&activityid='+activity+'&reviewer='+rev;
            xmlHttp.open( 'GET', url, true ); // false for synchronous request
            xmlHttp.onreadystatechange=function() {
            console.log(xmlHttp.responseText);
            apply_changes(qa, courseid);
        };
        xmlHttp.send( null );
        
        }
        
    }
    else{
        var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confdist/add_to_revs.php?courseid='+courseid+'&activityid='+activity+'&reviewer='+rev;
        xmlHttp.open( 'GET', url, true ); // false for synchronous request
        xmlHttp.onreadystatechange=function() {
            console.log(xmlHttp.responseText);
            apply_changes(qa, courseid);
        };
        xmlHttp.send( null );
        
    }
}

function add_to_editors(editor, courseid, activity, qa){
    if(document.getElementById("checkbox_ed"+editor).checked==false){
        if (confirm(words['sure_ed'])) {
            var xmlHttp = new XMLHttpRequest();
            var url='/question/type/confdist/add_to_editors.php?courseid='+courseid+'&activityid='+activity+'&editor='+editor;
            xmlHttp.open( 'GET', url, true ); // false for synchronous request
            xmlHttp.onreadystatechange=function() {
                console.log(xmlHttp.responseText);
                apply_changes(qa, courseid);
            };
            xmlHttp.send( null );
            
        }
    }
    else{
        var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confdist/add_to_editors.php?courseid='+courseid+'&activityid='+activity+'&editor='+editor;
        xmlHttp.open( 'GET', url, true ); // false for synchronous request
        xmlHttp.onreadystatechange=function() {
            console.log(xmlHttp.responseText);
            apply_changes(qa, courseid);
        };
        xmlHttp.send( null );
        
    }
}

function add_to_chairmen(chairman, courseid, activity, qa){
    if(document.getElementById("checkbox_sup"+chairman).checked==false){
        if (confirm(words['sure_sup'])) {
            var xmlHttp = new XMLHttpRequest();
            var url='/question/type/confdist/add_to_chairmen.php?courseid='+courseid+'&activityid='+activity+'&chairman='+chairman;
            xmlHttp.open( 'GET', url, true ); // false for synchronous request
            xmlHttp.onreadystatechange=function() {
                console.log(xmlHttp.responseText);
                apply_changes(qa, courseid);
            };
            xmlHttp.send( null );
            
        }
    }
    else{
        var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confdist/add_to_chairmen.php?courseid='+courseid+'&activityid='+activity+'&chairman='+chairman;
        xmlHttp.open( 'GET', url, true ); // false for synchronous request
        xmlHttp.onreadystatechange=function() {
            console.log(xmlHttp.responseText);
            apply_changes(qa, courseid);
        };
        xmlHttp.send( null );
        
    }
}

function apply_changes(qa, course){
    var xmlhttp = new XMLHttpRequest();
    var url='/question/type/confdist/apply_change.php?qa='+qa+'&course='+course;
    xmlhttp.open( 'GET', url, true); 
    
    xmlhttp.onreadystatechange=function() {
        //console.log(xmlHttp.responseText==null);
         if (xmlhttp.readyState === 4) {
            document.getElementById("reviewers_distribution_table").innerHTML=xmlhttp.responseText;
        }
    };
    xmlhttp.send(null);
}

