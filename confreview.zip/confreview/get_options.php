<?php
    require_once'../../../config.php';
    global $DB;
   
    $course=$_GET['course'];
    $form=$_GET['form'];
    
    $options=$DB->get_record('confreview_view_options', ['courseid'=>$course, 'form'=>$form]);
    
    echo JSON_encode($options);
?>