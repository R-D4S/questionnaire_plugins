var open_review='';
var close_veview='';
var review_header='';
var save_review='';
var wrong_grade='';
function grade(reviewer, student, course, activity, attempt, grades, wr_grade){
    wrong_grade=wr_grade;
    grades=JSON.parse(grades);
    var tdid="r"+reviewer+"s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var xmlHttp = new XMLHttpRequest();
    var url='/question/type/confreview/get_grading.php?quiz='+activity+'&course='+course;
    xmlHttp.open( 'GET', url);         
    var res="";
    var grading;
    var max;
    var min;
    var scientific;
    xmlHttp.onload=function() {
        
        grading=xmlHttp.responseText;
        switch (grading){
            case '"1-5"':
                min=1;
                max=5;
                scientific=false;
                break;
            case '"1-10"':
                min=1;
                max=10;
                scientific=false;
                break;
            case '"1-100"':
                min=1;
                max=100;
                scientific=false;
                break;
            case '"-3-3"':
                min=-3;
                max=3;
                scientific=true;
                break;
            default:
                min=0;
                max=100;
                scientific=false;
        }
        if(!scientific){
        res+="<input type='number' id='"+tdid+"' min='"+min+"' max='"+max+"' onchange='save_grade("+reviewer+','+student+','+course+','+activity+','+attempt+','+min+','+max+','+tdid+")' >";
        res+="<div id='warning_"+tdid+"'></div>";
    }
    else{
        res+="<select id='"+tdid+"'  onchange='save_grade("+reviewer+','+student+','+course+','+activity+','+attempt+','+min+','+max+','+tdid+")' >";
        res+="<option value='n'></option>";
        res+="<option value='3'>"+grades["3"]+"</option>";
        res+="<option value='2'>"+grades["2"]+"</option>";
        res+="<option value='1'>"+grades["1"]+"</option>";
        res+="<option value='0'>"+grades["0"]+"</option>";
        res+="<option value='-1'>"+grades["-1"]+"</option>";
        res+="<option value='-2'>"+grades["-2"]+"</option>";
        res+="<option value='-3'>"+grades["-3"]+"</option>";
        res+="</select>";
        res+="<div id='warning_"+tdid+"'></div>";
    }
        document.getElementById('grade_'+tdid).innerHTML=res;
        var xmlHttp2 = new XMLHttpRequest();
    var url='/question/type/confreview/get_grade.php?quiz='+activity+'&course='+course+'&reviewer='+reviewer+'&student='+student+'&attempt='+attempt;
    xmlHttp2.open( 'GET', url);         
    
    xmlHttp2.onload=function() {
        window.addEventListener('load', (event) =>{
        document.getElementById(tdid).value=xmlHttp2.responseText;
    });
        
    };
    xmlHttp2.send(null);
    };
    xmlHttp.send(null);
    
    
}

function confidence(reviewer, student, course, activity, attempt, confidence){
    confidence=JSON.parse(confidence);
    var res='';
    var tdid="r"+reviewer+"s"+student+"c"+course+"ac"+activity+"at"+attempt;
    
        res+="<select id='conf"+tdid+"'  onchange='save_conf("+reviewer+','+student+','+course+','+activity+','+attempt+',conf'+tdid+")' >";
        res+="<option value='n'></option>";
        res+="<option value='5'>"+confidence["5"]+"</option>";
        res+="<option value='4'>"+confidence["4"]+"</option>";
        res+="<option value='3'>"+confidence["3"]+"</option>";
        res+="<option value='2'>"+confidence["2"]+"</option>";
        res+="<option value='1'>"+confidence["1"]+"</option>";
        res+="</select>";
    
        document.getElementById('conf_'+tdid).innerHTML=res;
        window.addEventListener('DOMContentLoaded', (event) =>{
        var xmlHttp8 = new XMLHttpRequest();
    var url='/question/type/confreview/get_confidence.php?quiz='+activity+'&course='+course+'&reviewer='+reviewer+'&student='+student+'&attempt='+attempt;
    xmlHttp8.open( 'GET', url); 
    xmlHttp8.onload=function() {
        
            
            document.getElementById('conf'+tdid).value=xmlHttp8.responseText;
          
        
        
    };
    xmlHttp8.send(null)})
}
function save_conf(reviewer,student,course,activity,attempt, tdid){
    //console.log(tdid);
    var confidence=tdid.value;
    tdid=tdid.id;
    
    var xmlHttp3 = new XMLHttpRequest();
    var url='/question/type/confreview/set_confidence.php?quiz='+activity+'&course='+course+'&reviewer='+reviewer+'&student='+student+'&attempt='+attempt+"&confidence="+confidence;
    xmlHttp3.open( 'GET', url);         

    xmlHttp3.onload=function() {


    };
    xmlHttp3.send(null);
    
}

function comment(reviewer, student, course, activity, attempt){
    var tdid="r"+reviewer+"s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var xmlHttp = new XMLHttpRequest();
    var url='/question/type/confreview/get_comment.php?quiz='+activity+'&course='+course+'&reviewer='+reviewer+'&student='+student+'&attempt='+attempt;
    xmlHttp.open( 'GET', url);         
    var res="";
    var comment='';
    
    res+="<textarea onkeyup='save_comment("+reviewer+','+student+','+course+','+activity+','+attempt+',com_area'+tdid+")' id='com_area"+tdid+"'></textarea>";
    xmlHttp.onload=function() {
        
        comment=xmlHttp.responseText;
        document.getElementById('comment_'+tdid).innerHTML=res;
        document.getElementById('com_area'+tdid).value=comment;
    };
    xmlHttp.send(null);
    
    
}

function review(reviewer, student, course, activity, attempt, button_name, close_button_name, rev_header, save_rev){
    open_review='<font style="font-size:small">'+button_name+'</font>';
    close_review='<font style="font-size:small">'+close_button_name+'</font>';
    review_header='<h4>'+rev_header+'</h4>';
    save_review=save_rev;
    var tdid="r"+reviewer+"s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var res='<button  id="button'+tdid+'" class="btn btn-secondary" onclick="show_review('+reviewer+','+student+','+course+','+activity+','+attempt+','+tdid+')"><font style="font-size:small">'+open_review+'</font></button>';
    document.getElementById('review_'+tdid).innerHTML=res;
//    var xmlHttp = new XMLHttpRequest();
//    var url='/question/type/confreview/get_review.php?quiz='+activity+'&course='+course+'&reviewer='+reviewer+'&student='+student+'&attempt='+attempt;
//    xmlHttp.open( 'GET', url);         
//    var res="";
//    var comment='';
//    
//    res+="<textarea onkeyup='save_comment("+reviewer+','+student+','+course+','+activity+','+attempt+',com_area'+tdid+")' id='com_area"+tdid+"'></textarea>";
//    xmlHttp.onload=function() {
//        
//        comment=xmlHttp.responseText;
//        document.getElementById('comment_'+tdid).innerHTML=res;
//        document.getElementById('com_area'+tdid).value=comment;
//    };
//    xmlHttp.send(null);
    
    
}

function show_review(reviewer, student, course, activity, attempt, tdid){
    tdid=tdid.id;
    if (document.getElementById('button'+tdid).innerHTML==close_review){
        document.getElementById('button'+tdid).innerHTML=open_review;
        document.getElementById('review_div').innerHTML='';
    }
    else{
        
        var buttons=document.getElementsByClassName('btn btn-secondary');
        for(var i=0; i<buttons.length; i++){
            if(buttons[i].id.includes('buttonr')){
                buttons[i].innerHTML=open_review;
            }
        }
        document.getElementById('button'+tdid).innerHTML=close_review;
        var res=review_header+"<textarea id='review_textarea' cols=70 rows=15 onkeydown='enable_save_button()'>";
        var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confreview/get_review.php?quiz='+activity+'&course='+course+'&reviewer='+reviewer+'&student='+student+'&attempt='+attempt;
        xmlHttp.open( 'GET', url); 
        xmlHttp.onload=function() {

            review=xmlHttp.responseText;
            //console.log(xmlHttp.responseText);
            res+=review;
            res+="</textarea>";
            res+="<br><button class='btn btn-secondary' id='save_btn' onclick='saveReview("+reviewer+','+student+','+course+','+activity+','+attempt+")' disabled>"+save_review+'</button>';
            document.getElementById('review_div').innerHTML=res;
        };
        xmlHttp.send(null);
    }
    
    
}

function enable_save_button(){
    document.getElementById("save_btn").disabled=false;
    
}

function saveReview(reviewer, student, course, activity, attempt){
    document.getElementById("save_btn").disabled=true;
    var review=document.getElementById('review_textarea').value;
    var formData=new FormData();
    formData.append('review', review);
    var xmlHttp = new XMLHttpRequest();
    var url='/question/type/confreview/save_review.php?quiz='+activity+'&course='+course+'&reviewer='+reviewer+'&student='+student+'&attempt='+attempt;
    xmlHttp.open( 'POST', url);         

    xmlHttp.send(formData);
    
}

function save_comment(reviewer,student,course,activity,attempt, tdid){
    
    var comment=tdid.value;
    tdid=tdid.id;
    var formData = new FormData();
    formData.append('comment', comment);
    var xmlHttp3 = new XMLHttpRequest();
    var url='/question/type/confreview/set_comment.php?quiz='+activity+'&course='+course+'&reviewer='+reviewer+'&student='+student+'&attempt='+attempt;
    xmlHttp3.open( 'POST', url);         

    xmlHttp3.onload=function() {

            //console.log(xmlHttp3.responseText);
    };
    xmlHttp3.send(formData);
    
}

function save_grade(reviewer,student,course,activity,attempt, min, max, tdid){
    var grade=tdid.value;
    tdid=tdid.id;
    if ((grade<min || grade>max)&& grade!='n'){
        document.getElementById('warning_'+tdid).innerHTML=wrong_grade;
        document.getElementById(tdid).value='';
    }
    else{
        document.getElementById('warning_'+tdid).innerHTML="";
                var xmlHttp3 = new XMLHttpRequest();
                var url='/question/type/confreview/set_grade.php?quiz='+activity+'&course='+course+'&reviewer='+reviewer+'&student='+student+'&attempt='+attempt+"&grade="+grade;
                xmlHttp3.open( 'GET', url);         

                xmlHttp3.onload=function() {
                    

                };
                xmlHttp3.send(null);
    }
}

function display_reviewers(){
    //вниз когда открыто
           //вправо когда закрыто
    if(document.getElementById('rev_tab').style.display=='none'){
        document.getElementById('rev_tab').style.display='block';
        document.getElementById('rev_tri').innerHTML='&#9662;';
    }
    else{
    document.getElementById('rev_tab').style.display='none';
    document.getElementById('rev_tri').innerHTML='&#9656;';
}
}

