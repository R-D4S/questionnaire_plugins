<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
   
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $form=$_GET['form'];
    $fields = $_POST['chosen_fields'];
    $fields = json_decode( $fields);
    //check and update
    check_field($quiz, $course);
    foreach($fields as $field){
        $DB->insert_record('confreview_au_fields', ['fieldid'=>$field, 'courseid'=>$course, 'activityid'=>$quiz, 'form'=>$form]);
    }
    $additional_fields=[];
    $additional_fields['auth_rev_name']=$_POST['auth_rev_name'];
    $additional_fields['auth_rev_grade']=$_POST['auth_rev_grade'];
    $additional_fields['auth_rev_conf']=$_POST['auth_rev_conf'];
    $additional_fields['auth_rev_review']=$_POST['auth_rev_review'];
    $additional_fields['auth_ed_name']=$_POST['auth_ed_name'];
    $additional_fields['auth_ed_dis']=$_POST['auth_ed_dis'];
    $additional_fields['auth_sup_name']=$_POST['auth_sup_name'];
    $additional_fields['auth_sup_dis']=$_POST['auth_sup_dis'];
    
    foreach($additional_fields as $key=>$value){
        if($additional_fields[$key]=='true'){
            $additional_fields[$key]='1';
        }
        else{
            $additional_fields[$key]='0';
        }
    }
    $additional_fields['courseid']=$course;
    $additional_fields['activityid']=$quiz;
    $additional_fields['form']=$form;
    if($DB->get_records('confreview_view_options', ['courseid'=>$course, 'activityid'=>$quiz, 'form'=>$form])==false){
        $DB->insert_record('confreview_view_options', $additional_fields);
    }
    else{
        $id=$DB->get_record('confreview_view_options', ['courseid'=>$course, 'activityid'=>$quiz, 'form'=>$form])->id;
        $additional_fields['id']=$id;
        $DB->update_record('confreview_view_options', (object)$additional_fields);
    }
    
    
    function check_field($quiz, $course){
        global $DB;
        if (!($DB->get_record('confreview_au_fields', ['courseid'=>$course, 'activityid'=>$quiz])==false))
                $DB->delete_records('confreview_au_fields', ['courseid'=>$course, 'activityid'=>$quiz]);
        
    }
?>