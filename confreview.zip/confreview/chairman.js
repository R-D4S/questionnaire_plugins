var options=[];
var words=[];
var reviews=[];
function set_options_chairman(op, w){
    options=JSON.parse(op);
    words=JSON.parse(w);
    words['r_and_d_btn']='<font style="font-size:small">'+words['r_and_d_btn']+'</font>';
    words['show_review']='<font style="font-size:small">'+words['show_review']+'</font>';
}


function grades_button_for_chairman(student, course, activity, attempt, form){
    var res='';
    res+='<button class="btn btn-secondary" onclick="grades_for_chairman('+student+','+course+','+activity+','+attempt+','+form+')">'+words['r_and_d_btn']+'</button>';
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    document.getElementById('sup_grades_'+tdid).innerHTML=res;
}
function close_sup_div(){
    document.getElementById('sup_wind').style.visibility='hidden';
}
function close_sup_div2(){
    document.getElementById('sup_wind2').style.visibility='hidden';
    document.getElementById('sup_wind').style.visibility='visible';
}

function show_review_to_chairman(key){
    var review=reviews[key];
    var res='<h5 style="text-align:right; margin-right:4px; cursor:pointer" onclick="close_sup_div2()">'+words['close_rev_div']+'</h5>';
    res+='<h4>'+words['review_header']+'</h5>';
    if(review!=='null'){
        review=review.replace('&', '&amp;');
        review=review.replace('<', '&lt;');
        res+=review;
    }
    else
        res+=words['no_review'];
    document.getElementById('sup_wind2').innerHTML=res;
    document.getElementById('sup_wind2').style.visibility='visible';
    document.getElementById('sup_wind').style.visibility='hidden';
}
function grades_for_chairman(student, course, activity, attempt, form){
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var res='';
    var grades=[];
    var xmlHttp3 = new XMLHttpRequest();
    var url='/question/type/confreview/get_reviews.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt;
    xmlHttp3.open( 'GET', url);         

    xmlHttp3.onload=function() {
        grades=JSON.parse(xmlHttp3.responseText);
//        console.log(grades);
        res+='<h5 style="text-align:right; margin-right:4px; cursor:pointer" onclick="close_sup_div()">'+words['close_rev_div']+'</h5>';
        res+='<h4>'+words['reviews_header']+'</h4>';
        res+='<div><table class="flexible  generalbox" style="font-size:small">';
        res+='<thead><th>'+words['reviewer']+'</th><th>'+words['review']
                +'</th><th>'+words['comment']+
                '</th><th>'+words['reviewer_confidence']+
                '</th><th>'+words['grade']+'</th></thead>';
        var q=1;
        var span=0;
        for (var key in grades){
            span++;
            res+='<tr >';
            if(options['sup_rev_name']=='1'){
                res+='<td>'+grades[key]['lastname']+' '+grades[key]['firstname']+'</td>';
            }
            else{
                res+='<td>'+words['reviewer']+' '+q+'</td>';
                q++;
            }
                reviews[key]=grades[key]['review'];
            res+='<td><button class="btn btn-secondary" onclick="show_review_to_chairman('+"'"+key+"'"+')">'+words['show_review']+'</button></td>';
            if(grades[key]['comment']!==null){
                res+='<td>'+grades[key]['comment']+'</td>';
            }
            else{
                res+='<td></td>';
            }
            if(grades[key]['confidence']!==null){
                res+='<td>'+grades[key]['confidence']+'</td>';
            }
            else{
                res+='<td>-</td>';
            }
            if(grades[key]['grade']!==null){
                res+='<td>'+grades[key]['grade']+'</td>';
            }
            else{
                res+='<td>-</td>';
            }
            res+='</tr>';
            
        }
        
//        var cells=document.getElementsByClassName('at'+attempt);
//        for (var i=0; i<cells.length; i++){
//            cells[i].rowSpan=span;
//        }
        res+="</table></div>";
        decisions_for_chairman(student, course, activity, attempt);
        document.getElementById('sup_wind').innerHTML=res;
        document.getElementById('sup_wind').style.visibility='visible';
    };
    xmlHttp3.send(null);
    
    
}

function decisions_for_chairman(student, course, activity, attempt){
        var xmlHttp3 = new XMLHttpRequest();
    var url='/question/type/confreview/get_decisions.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt;
    xmlHttp3.open( 'GET', url);         
    var res='';
    xmlHttp3.onload=function() {
        console.log(xmlHttp3.responseText);
        //null и минус один
        //превращать в слова
                //проверить чтобы можно было скрывать имена редакторов
        var grades=JSON.parse(xmlHttp3.responseText);
//        console.log(grades);
         res+='<h4>'+words['dis_header']+'</h4>';
        res+='<div><table class="flexible  generalbox" style="font-size:small">';
        res+='<thead><th>'+words['editor']+'</th><th>'+words['ed_dis']+'</th></thead>';
        var q=1;
        var span=0;
        for (var key in grades){
            span++;
            res+='<tr >';
            if(options['sup_ed_name']=='1'){
                res+='<td>'+grades[key]['lastname']+' '+grades[key]['firstname']+'</td>';
            }
            else{
                res+='<td>'+words['editor']+' '+q+'</td>';
                q++;
            }
            if(grades[key]['decision']==null || grades[key]['decision']=='-1'){
                res+='<td>-</td>';
            }
            if(grades[key]['decision']=='0'){
                res+='<td>'+words['accept']+'</td>';
            }
            if(grades[key]['decision']=='1'){
                res+='<td>'+words['correction']+'</td>';
            }
            if(grades[key]['decision']=='2'){
                res+='<td>'+words['decline']+'</td>';
            }
            res+='</tr>';
            
        }
        
//        var cells=document.getElementsByClassName('at'+attempt);
//        for (var i=0; i<cells.length; i++){
//            cells[i].rowSpan=span;
//        }
        res+="</table></div>";
        document.getElementById('sup_wind').innerHTML+=res;
    };
    xmlHttp3.send(null);
}

function grades_avg_for_chairman(student, course, activity, attempt){
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var res='';
    var grades=[];
    var xmlHttp3 = new XMLHttpRequest();
    var url='/question/type/confreview/get_reviews_avg.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt;
    xmlHttp3.open( 'GET', url);         

    xmlHttp3.onload=function() {
        res+=parseFloat(xmlHttp3.responseText).toFixed(2);
        var xmlHttp4 = new XMLHttpRequest();
        var url='/question/type/confreview/get_grading_lowestavg.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt;
        xmlHttp4.open( 'GET', url);         

        xmlHttp4.onload=function() {
            if(res!='NaN'){
            document.getElementById('sup_grades_avg_'+tdid).innerHTML=res;
        }
            
            var lowestgrade=xmlHttp4.responseText;
            
            
            if(parseFloat(lowestgrade.replace('"', '').replace('"', ''))>parseFloat(res)){
                document.getElementById('sup_grades_avg_'+tdid).style.backgroundColor='#FFABAB';
            }
        };
        xmlHttp4.send(null);
    };
    xmlHttp3.send(null);
    
    
}

function grades_lowest_for_chairman(student, course, activity, attempt){
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var res='';
    var grades=[];
    var xmlHttp3 = new XMLHttpRequest();
    var url='/question/type/confreview/get_reviews_lowest.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt;
    xmlHttp3.open( 'GET', url);         

    xmlHttp3.onload=function() {
        res+=xmlHttp3.responseText;
        var xmlHttp4 = new XMLHttpRequest();
        var url='/question/type/confreview/get_grading_lowest.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt;
        xmlHttp4.open( 'GET', url);         

        xmlHttp4.onload=function() {
            document.getElementById('sup_grades_lowest_'+tdid).innerHTML=res;
            var lowestgrade=xmlHttp4.responseText;
//            console.log(res);
//            console.log(parseFloat(lowestgrade.replace('"', '').replace('"', '')));
            if(parseFloat(lowestgrade.replace('"', '').replace('"', ''))>parseFloat(res)){
                document.getElementById('sup_grades_lowest_'+tdid).style.backgroundColor='#FFABAB';
            }
        };
        xmlHttp4.send(null);
    };
    xmlHttp3.send(null);
    
    
}

function grades_null_for_chairman(student, course, activity, attempt){
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var res='';
    var grades=[];
    var xmlHttp3 = new XMLHttpRequest();
    var url='/question/type/confreview/get_reviews_null.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt;
    xmlHttp3.open( 'GET', url);         

    xmlHttp3.onload=function() {
        res+=xmlHttp3.responseText;
        document.getElementById('sup_grades_null_'+tdid).innerHTML=res;
        if(parseFloat(res)>0){
                document.getElementById('sup_grades_null_'+tdid).style.backgroundColor='#FFABAB';
            }
        
        
    };
    xmlHttp3.send(null);
    
    
}

function approved_by_chairman(student, course, activity, attempt, chairman){
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var res='';
    res+="<select id='sup_dis_selector"+tdid+"' onchange='save_sup_dis("+student+','+course+','+ activity+','+attempt+','+chairman+")'>";
    res+="<option value='-1' style='background-color:#ffffff'></option>";
    res+="<option value='0' style='background-color:#BDFFAB'>"+words['accept']+"</option>";
    res+="<option value='1'style='background-color:#FFFFAB'>"+words['correction']+"</option>";
    res+="<option value='2' style='background-color:#FFABAB'>"+words['decline']+"</option>";
    res+="</select>";
    document.getElementById('sup_approved_'+tdid).innerHTML=res;
    
    var xmlHttp3 = new XMLHttpRequest();
    var url='/question/type/confreview/get_sup_decision.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt+'&chairman='+chairman;
    xmlHttp3.open( 'GET', url);         

    xmlHttp3.onload=function() {
        var decision=xmlHttp3.responseText;
        document.getElementById('sup_dis_selector'+tdid).value=decision;
        if(decision=='0'){
            document.getElementById('sup_dis_selector'+tdid).style.backgroundColor='#BDFFAB';
        }
        if(decision=='1'){
            document.getElementById('sup_dis_selector'+tdid).style.backgroundColor='#FFFFAB';
        }
        if(decision=='2'){
            document.getElementById('sup_dis_selector'+tdid).style.backgroundColor='#FFABAB';
        }
        
        //console.log(decision);
    };
    xmlHttp3.send(null);
    
}

//res+="<select id='ed_dis_selector' onchange='save_ed_dis("+student+','+course+','+ activity+','+attempt+','+editor+")'>";
function save_sup_dis(student, course, activity, attempt, chairman){
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var decision=document.getElementById('sup_dis_selector'+tdid).value;
    if(decision=='0'){
        document.getElementById('sup_dis_selector'+tdid).style.backgroundColor='#BDFFAB';
    }
    if(decision=='1'){
        document.getElementById('sup_dis_selector'+tdid).style.backgroundColor='#FFFFAB';
    }
    if(decision=='2'){
        document.getElementById('sup_dis_selector'+tdid).style.backgroundColor='#FFABAB';
    }
    if(decision=='-1'){
        document.getElementById('sup_dis_selector'+tdid).style.backgroundColor='#FFffff';
    }  
    var xmlHttp3 = new XMLHttpRequest();
     var url='/question/type/confreview/save_sup_decision.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt+'&chairman='+chairman+'&dis='+decision;
    xmlHttp3.open( 'GET', url);         

    xmlHttp3.onload=function() {
        //console.log(xmlHttp3.responseText);
       
    };
    xmlHttp3.send(null);
}

function display_chairmen(){
    //вниз когда открыто
           //вправо когда закрыто
    if(document.getElementById('sup_tab').style.display=='none'){
        document.getElementById('sup_tab').style.display='block';
        document.getElementById('sup_tri').innerHTML='&#9662;';
    }
    else{
    document.getElementById('sup_tab').style.display='none';
    document.getElementById('sup_tri').innerHTML='&#9656;';
}
}



