<?php
    require_once 'confdist_edit_settings.php';
    require_once'../../../config.php';
    echo confdist_distribution($_GET['qa'], $_GET['course']);

?>