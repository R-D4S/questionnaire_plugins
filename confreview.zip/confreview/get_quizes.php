<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    $course_id=$_GET['course'];
    $table='quiz';
    $quizes=$DB->get_records($table, ['course'=>$course_id]);
    $res=[];
    foreach($quizes as $value){
        array_push($res, ['id'=>$value->id, 'name'=>$value->name]);
    }
    $res=json_encode($res);
    echo $res;
    
    


