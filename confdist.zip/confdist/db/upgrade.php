<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Short-answer question type upgrade code.
 *
 * @package    qtype
 * @subpackage confdist
 * @copyright  2011 The Open University
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade code for the essay question type.
 * @param int $oldversion the version we are upgrading from.
 */
function xmldb_qtype_confdist_upgrade($oldversion) {
    global $CFG;

    // Automatically generated Moodle v3.3.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.4.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.5.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.6.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.7.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.8.0 release upgrade line.
    // Put any upgrade step following this.
    global $DB;
    $dbman = $DB->get_manager();

    /// Add a new column newcol to the mdl_myqtype_options
    if ($oldversion < 2019111809) {
         // Define field attempt to be added to confdist_distribution.
        $table = new xmldb_table('confdist_distribution');
        $field = new xmldb_field('attempt', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null, 'student');

        // Conditionally launch add field attempt.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }
        
        
        
        // Define table confdist_reviewers_list to be created.
        $table = new xmldb_table('confdist_reviewers_list');

        // Adding fields to table confdist_reviewers_list.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('reviewer', XMLDB_TYPE_INTEGER, '10', null, null, null, null);

        // Adding keys to table confdist_reviewers_list.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confdist_reviewers_list.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Confdist savepoint reached.
        upgrade_plugin_savepoint(true, 2019111809, 'qtype', 'confdist');
    }
    
    if ($oldversion < 2019111810) {

        // Define table confdist_reviewers_fields to be created.
        $table = new xmldb_table('confdist_reviewers_fields');

        // Adding fields to table confdist_reviewers_fields.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);

        // Adding keys to table confdist_reviewers_fields.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confdist_reviewers_fields.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Confdist savepoint reached.
        upgrade_plugin_savepoint(true, 2019111810, 'qtype', 'confdist');
    }
         if ($oldversion < 2019111812) {

        // Define field field to be added to confdist_reviewers_fields.
        $table = new xmldb_table('confdist_reviewers_fields');
        $field = new xmldb_field('field', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'activityid');

        // Conditionally launch add field field.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Confdist savepoint reached.
        upgrade_plugin_savepoint(true, 2019111812, 'qtype', 'confdist');
    }
    
     if ($oldversion < 2019111813) {

        // Define table confdist_editors_list to be created.
        $table = new xmldb_table('confdist_editors_list');

        // Adding fields to table confdist_editors_list.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('editor', XMLDB_TYPE_INTEGER, '10', null, null, null, null);

        // Adding keys to table confdist_editors_list.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confdist_editors_list.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Confdist savepoint reached.
        upgrade_plugin_savepoint(true, 2019111813, 'qtype', 'confdist');
    }
    
     if ($oldversion < 2019111813) {

        // Define table confdist_editors_dist to be created.
        $table = new xmldb_table('confdist_editors_dist');

        // Adding fields to table confdist_editors_dist.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('editor', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('student', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('attempt', XMLDB_TYPE_INTEGER, '10', null, null, null, null);

        // Adding keys to table confdist_editors_dist.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confdist_editors_dist.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Confdist savepoint reached.
        upgrade_plugin_savepoint(true, 2019111813, 'qtype', 'confdist');
    }
     if ($oldversion < 2019111815) {

        // Define table confdist_chairmen_list to be created.
        $table = new xmldb_table('confdist_chairmen_list');

        // Adding fields to table confdist_chairmen_list.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('chairman', XMLDB_TYPE_INTEGER, '10', null, null, null, null);

        // Adding keys to table confdist_chairmen_list.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for confdist_chairmen_list.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Confdist savepoint reached.
        upgrade_plugin_savepoint(true, 2019111815, 'qtype', 'confdist');
    }


    return true;
}
