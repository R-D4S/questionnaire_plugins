window.onload=function(){
    //document.getElementById('id_responseformat').value='noinline';
    document.getElementById('id_defaultmark').value='0';
    document.getElementById('fitem_id_defaultmark').style.display='none';
    document.getElementById('id_responsetemplateheader').style.display='none';
    document.getElementById('id_graderinfoheader').style.display='none';
    document.getElementById('id_responseoptions').style.display='none';
//    
//    document.getElementById('fitoem_id_responseformat').style.display='none';
//    document.getElementById('fitem_id_responserequired').style.display='none';
//    
//        
//    document.getElementById('id_responserequired').style.display='hidden';
}