var selection_quiz='';
var tops=[];
function selectQuiz(course, squiz){
    selection_quiz=squiz;
    window.addEventListener('DOMContentLoaded', (event) => {
        var xmlHttp = new XMLHttpRequest();
        var url='/question/type/filere/get_quizes.php?course='+course;
        xmlHttp.open( 'GET', url); 
        var quizes;
        var res;
        xmlHttp.onload=function() {
            quizes=JSON.parse(xmlHttp.responseText);
            res='Выберите форму подачи заявки<br> ';
            res+='<select id="quiz_selector_element" onchange="get_fields('+course+')">';
            res+='<option value="-1"></option>';
            for(var i=0; i<quizes.length; i++){
                res+='<option value="'+quizes[i]['id']+'">'+quizes[i]['name']+'</option>';
            }
            res+='</select>';
            document.getElementById("select_quiz").innerHTML=res;
        };
        xmlHttp.send(null);
    });
    
    
}

function get_fields(course){
    var quiz=document.getElementById('quiz_selector_element').value;
    var xmlHttp = new XMLHttpRequest();
        var url='/question/type/filere/get_fields.php?quiz='+quiz+'&course='+course;
        xmlHttp.open( 'GET', url);         
        var res;
        xmlHttp.onload=function() {
            fields=JSON.parse(xmlHttp.responseText);
            res="<br>Выберите поле с названием темы<br>";
            res+="<select id='fields_selector' onchange='save_field("+course+','+quiz+")'>";
            res+="<option value='-1'></option>";
            for(var i=0; i<fields.length; i++){
                res+='<option value="'+fields[i]['id']+'">'+fields[i]['text']+"</option>";
            }
            res+='</select>';
            document.getElementById("select_field").innerHTML+=res;
            
        };
        xmlHttp.send(null);
}

function save_field(course, quiz){
    var field=document.getElementById('fields_selector').value;
    var xmlHttp = new XMLHttpRequest();
        var url='/question/type/filere/save_fields.php?quiz='+quiz+'&course='+course+'&field='+field+'&form='+selection_quiz;
        xmlHttp.open( 'GET', url);      
        xmlHttp.onload=function() {
           console.log(xmlHttp.responseText);
            
        };
        xmlHttp.send(null);
}

function output(topics, question_name, cmid){
    tops=topics;
    var res='<select id="topic_picker" onchange="enable_button()">';
    res+='<option value="-1">Выберите работу</option>';
    for(key in topics){
        res+='<option value="'+topics[key]['attemptid']+'">'+topics[key]['answer']+'</option>';
    }
    
    res+='</select><br>';
    
    res+='<br><input  type="file" id="file_input" onchange="enable_button()"><br>';
    res+='<br><button class="btn btn-secondary" onclick="save_file('+"'"+question_name+"'"+','+cmid+')" disabled id="save_button">'+"Сохранить"+'</button>';
    
    window.onload=function(){
        document.getElementById('file_form').innerHTML=res;
    }
}

function enable_button(){
    if(document.getElementById("file_input").value && document.getElementById("topic_picker").value!=-1){
        document.getElementById("save_button").disabled=false;
    }
    else{
        document.getElementById("save_button").disabled=true;
    }
}

function save_file( question_name, cmid){
    var attemptid=document.getElementById("topic_picker").value;
    var quizid;
    var courseid;
    var userid;
    for(key in tops){
        if (tops[key]['attemptid']==attemptid){
            quizid=tops[key]['quizid'];
            courseid=tops[key]['courseid'];
            userid=tops[key]['userid'];
        }
    }
    var uploaded_file=document.getElementById('file_input').files[0];
    const formData = new FormData();
    formData.append('question_name', question_name);
    formData.append('cmid', cmid);
    formData.append('attemptid', attemptid);
    formData.append('quizid', quizid);
    formData.append('courseid', courseid);
    formData.append('userid', userid);
    formData.append('uploaded_file', uploaded_file);
    var xmlHttp = new XMLHttpRequest();
        var url='/question/type/filere/save_file.php';
        xmlHttp.open( 'POST', url); 
        
        xmlHttp.onload=function() {
            console.log(xmlHttp.responseText);
        };
        xmlHttp.send(formData);
    
}

//function select_topics(topics, activity, course, user){
//    
//    var res='Выберете интересующие вас темы!<br>';
//    for (var i=0; i<topics.length; i++){
//        res+='<input type="checkbox" class="topics_checkbox" value="'+topics[i]+'"> '+topics[i]+'<br>';
//    }
//    res+='<button class="btn btn-secondary" onclick="save_topics('+activity+','+course+','+user+')">сохранить!</button>';
//    document.getElementById('topic_selection_table').innerHTML=res;
//    
//}

//function save_topics(activity, course, user){
//    var selected_topics_checkboxes=document.getElementsByClassName('topics_checkbox');
//    var topics=[];
//    topics.push(activity);
//    topics.push(course);
//    topics.push(user);
//    for (var i=0; i<selected_topics_checkboxes.length; i++){
//        if(selected_topics_checkboxes[i].checked==true){
//            topics.push(selected_topics_checkboxes[i].value);
//        }
//    }
//    topics=JSON.stringify(topics);
//    var xmlHttp = new XMLHttpRequest();
//    
//    var url='/question/type/filere/save_topics.php';
//    xmlHttp.open( 'POST', url);
//    xmlHttp.setRequestHeader('Content-Type', 'application/json');      
//    xmlHttp.onload=function() {
//       console.log(xmlHttp.responseText);
//       window.location = window.location.href;
//    };
//    xmlHttp.send(topics);
//    
//}

