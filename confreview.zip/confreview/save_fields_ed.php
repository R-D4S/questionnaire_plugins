<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
   
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $form=$_GET['form'];
    $fields = file_get_contents( "php://input" );
    $fields = json_decode( $fields);
    $ed_rev_name=$_GET['ed_rev_name'];
    if($ed_rev_name=='true'){
        $ed_rev_name='1';
    }
    else{
        $ed_rev_name='0';
    }
    //check and update
    check_field($quiz, $course);
    foreach($fields as $field){
        $DB->insert_record('confreview_ed_fields', ['fieldid'=>$field, 'courseid'=>$course, 'activityid'=>$quiz, 'form'=>$form]);
    }
    
    if($DB->get_records('confreview_view_options', ['courseid'=>$course, 'activityid'=>$quiz, 'form'=>$form])==false){
        $DB->insert_record('confreview_view_options', ['ed_rev_name'=>$ed_rev_name]);
    }
    else{
        $id=$DB->get_record('confreview_view_options', ['courseid'=>$course, 'activityid'=>$quiz, 'form'=>$form])->id;
        $DB->update_record('confreview_view_options', (object)['id'=>$id, 'ed_rev_name'=>$ed_rev_name]);
    }
    
    function check_field($quiz, $course){
        global $DB;
        if (!($DB->get_record('confreview_ed_fields', ['courseid'=>$course, 'activityid'=>$quiz])==false))
                $DB->delete_records('confreview_ed_fields', ['courseid'=>$course, 'activityid'=>$quiz]);
        
    }
?>