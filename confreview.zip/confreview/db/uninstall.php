<?php
    defined('MOODLE_INTERNAL') || die();
    function xmldb_block_confreview_uninstall(){
        return true;
    }
?>

