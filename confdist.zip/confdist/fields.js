function change_fields(course, activity, qa){
    var fields=document.getElementsByClassName('field');
    var chosen_fields=[];
    for (var i=0; i<fields.length; i++){
        if(fields[i].checked==true){
            chosen_fields.push(fields[i].value);
        }
    }
    if(chosen_fields.length==0){
        chosen_fields.push(-1);
        console.log(chosen_fields);
    }
    var post='['+course+','+activity+','+chosen_fields.join(',')+']';
    var xmlHttp = new XMLHttpRequest();
    var url='/question/type/confdist/edit_fields.php';
    xmlHttp.open( 'POST', url); 
    xmlHttp.setRequestHeader( "Content-Type", "application/json" );
    
    xmlHttp.onload=function() {
        apply_changes(qa, course);
        console.log(xmlHttp.responseText);
    };
    xmlHttp.send(post);
    
     
    //document.getElementById("reviewers_distribution_table").innerHTML=xmlHttp.responseText;
}

function apply_changes(qa, course){
    var xmlhttp = new XMLHttpRequest();
    var url='/question/type/confdist/apply_change.php?qa='+qa+'&course='+course;
    xmlhttp.open( 'GET', url, true); 
    
    xmlhttp.onreadystatechange=function() {
        //console.log(xmlHttp.responseText==null);
         if (xmlhttp.readyState === 4) {
            document.getElementById("reviewers_distribution_table").innerHTML=xmlhttp.responseText;
        }
    };
    xmlhttp.send(null);
}

