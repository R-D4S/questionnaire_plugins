<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    
    $res='';
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $student=$_GET['student'];
    $attempt=$_GET['attempt'];
    $sql='select count(*)-count(grade) as avgg from mdl_confdist_distribution cd left outer join mdl_confreview_grades cg 
on (cg.activityid=cd.activityid and cg.student=cd.student and cg.attempt=cd.attempt 
and cg.courseid=cd.courseid and cd.reviewer=cg.reviewer) join mdl_user u on (cd.reviewer=u.id) where cd.activityid=? and cd.courseid=?
and cd.student=? and cd.attempt=? group by cd.attempt';
    $grades=$DB->get_records_sql($sql, [$quiz, $course, $student, $attempt]);
    foreach($grades as $grade){
        $res=$grade->avgg;
    }
    echo $res;
        
    