﻿<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Short answer question renderer class.
 *
 * @package    qtype
 * @subpackage conftopic
 * @copyright  2009 The Open University
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


defined('MOODLE_INTERNAL') || die();


/**
 * Generates the output for short answer questions.
 *
 * @copyright  2009 The Open University
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class qtype_conftopic_renderer extends qtype_renderer {
    
    public function formulation_and_controls(question_attempt $qa,
            question_display_options $options) {
        
        $question = $qa->get_question();

          $questiontext ='<h2>'. $question->format_questiontext($qa).'</h2>';

          $result = html_writer::tag('div', $questiontext, array('class' => 'qtext'));

        global $USER;
        global $COURSE;
        $context = context_module::instance($COURSE->id);
        
            require 'output.php';
//            //при загрузке страницы взять все элементы формы и прицепить их к диву и удалить их с формы
            conftopic_hide();
//            $result.=output_search_field($qa);
//            $result.=output_reviewers($qa);
//            $result.="<br><h4>Назначение рецензентов!</h4>";
//            //$result.=fields_search($fields, $course_id, $activity_id);
//            $result.='<div id="fields_selector"></div>';
            $result.='<div id="topic_selected">';
            $result.=conftopic_output_chosen_topics();
            $result.='</div>';
            $result.='<div id="topic_selection_table">';
            $result.=conftopic_output_topics();
//            $result.=conftopic_distribution($qa->get_question()->profiledata, $COURSE->id);
//            //$result.=conftopic_distribution($qa->get_question()->profiledata);
            $result.='</div>';
            
////            $result1.=output_reviewers($qa);
////            $result1.=conftopic_distribution($qa);
////            //как-то через скрипты те сделать через элемент
////            $res='<script>';
////            $res.='var el=document.querySelectorAll("'."[role='main']".':last-of-type")[0];';//кавычки
////            $res.="el.innerHTML='';";
////            $res.="el.innerHTML='";=confdi
////            $res.=$result;
////            $res.=$result1;
////            $res.="';";
////            $res.="</script>";
////            echo ($res);
            $result.='<script>var form=document.getElementById("responseform");';
            $result.='var div=document.getElementsByClassName("formulation clearfix")[0];';
            $result.='var div_clone=div.cloneNode(true);';
            $result.='var parent_div=form.parentNode;';
            //console.log(parent_div);
            $result.='parent_div.appendChild(div_clone);';
            $result.="var parent_div2=parent_div.parentNode;";
            $result.="form.style.display='none';";
            $result.='div.remove();';
            $result.='parent_div2.style.width="90%"</script>';
            return $result;
        
    }

//    public function specific_feedback(question_attempt $qa) {
//        $question = $qa->get_question();
//
//        $answer = $question->get_matching_answer(array('answer' => $qa->get_last_qt_var('answer')));
//        if (!$answer || !$answer->feedback) {
//            return '';
//        }
//
//        return $question->format_text($answer->feedback, $answer->feedbackformat,
//                $qa, 'question', 'answerfeedback', $answer->id);
//    }
//
//    public function correct_response(question_attempt $qa) {
//        //no need for correct response
////        $question = $qa->get_question();
////        $answer = $question->get_matching_answer($question->get_correct_response());
////        if (!$answer) {
////            return '';            
////        }
//
//        //return get_string('correctansweris', 'qtype_conftopic',
//                //s($question->clean_response($answer->answer)));
//        return '';
//    }
//    
//    public function check_format($qa){
//        $slot=$qa->get_slot();
//        foreach($qa->get_question()->get_answers() as $value){
//                        $mask=$value->answer;
//                    }
//        $mask='/'.$mask.'/';
//        $qa_id=$qa->get_usage_id();
//        $field_id="q".$qa_id.":".$slot."_answer";
//        $res="<script>";
//        $res.="var mask".$slot."=".$mask.";";
//        $res.="var f".$slot."=document.getElementById('".$field_id."');";
//        
//        $res.="f".$slot.".onkeyup=function(){";
//        $res.="var found=f".$slot.".value.match(mask".$slot.");";
//        $res.="if(found===null){";
//        $res.="f".$slot.".style.color='red';";
//        $res.="}";
//        $res.="else{";
//        $res.="f".$slot.".style.color='black';";
//        $res.="}";
//        $res.="};";
//        $res.="</script>";
//        //var_dump($qa);
//        return $res;
//    }
}
