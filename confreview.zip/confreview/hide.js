window.onload=function(){
//    document.getElementById('').style.display='none';
//    document.getElementById('').value='none';
    document.getElementById('id_defaultmark').value='0';
    document.getElementById('fitem_id_defaultmark').style.display='none';
    document.getElementById('fitem_id_generalfeedback').style.display='none';
    document.getElementById('fitem_id_usecase').style.display='none';
    document.getElementById('fitem_id_answersinstruct').style.display='none';
    document.getElementById('id_answer_0').value='*';
    document.getElementById('id_fraction_0').value="1.0";
    document.getElementById('id_answerhdr').style.display='none';
    document.getElementById('id_multitriesheader').style.display='none';
}


