<?php

    $fields = file_get_contents( "php://input" );
    $fields = json_decode( $fields);
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    if (empty(has_capability('moodle/course:update', $context))){
        echo "Forbidden";
    }
    else{
        $course=$fields[0];
        $activity=$fields[1];
        unset($fields[0]);
        unset($fields[1]);
        
        if($fields[2]==-1){
            $DB->delete_records('confdist_reviewers_fields', ['courseid'=>$course, 'activityid'=>$activity]);
        }
        
        
        $prechosen=[];
        $prechosen_obj=$DB->get_records('confdist_reviewers_fields', ['activityid'=>$activity, 'courseid'=>$course]);
        foreach($prechosen_obj as $field){
            $prechosen[]=(int)$field->field;
        }
        $insert=array_diff($fields, $prechosen);
        $delete=array_diff($prechosen, $fields);
        foreach($insert as $value){
            confdist_insert_field($course, $activity, $value);
        }
        foreach($delete as $value){
            confdist_delete_field($course, $activity, $value);
        }
    }
    
    function confdist_insert_field($course, $activity, $field){
        global $DB;
        $newrecord=new stdClass();
        $newrecord->courseid=$course;
        $newrecord->activityid=$activity;
        $newrecord->field=$field;
        $DB->insert_record('confdist_reviewers_fields', $newrecord);
        
    }
    
    function confdist_delete_field($course, $activity, $field){
        global $DB;
        $DB->delete_records('confdist_reviewers_fields', ['courseid'=>$course, 'activityid'=>$activity, 'field'=>$field]);
    }



?>