window.onload=function(){
    document.getElementById('id_usecase').onchange=forbidregex;
}

function forbidregex(){
    if(document.getElementById('id_usecase').value=='1'){
        document.getElementById('id_answer_0').disabled=true;
    }
    else{
        document.getElementById('id_answer_0').disabled=false;
    }
}
