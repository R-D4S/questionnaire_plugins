﻿<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'qtype_shortanswer', language 'ru', branch 'MOODLE_37_STABLE'
 *
 * @package   qtype_shortanswer
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addmoreanswerblanks'] = 'Добавить {no} варианта(ов) ответа(ов)';
$string['answer'] = 'Ответ: {$a}';
$string['answermustbegiven'] = 'Вы должны ввести для каждого варианта ответа оценку или отзыв.';
$string['answerno'] = 'Вариант ответа {$a}';
$string['caseno'] = 'Нет, пользователь не может менять данные';
$string['casesensitive'] = 'Чувствительность к регистру';
$string['caseyes'] = 'Да, пользователь может менять данные';
$string['correctansweris'] = 'Правильный ответ: {$a}';
$string['correctanswers'] = 'Регулярное выражение';
$string['filloutoneanswer'] = 'Вместо правильного ответа укажите регулярное выражение для проверки правильности формата введенных данных.';
$string['notenoughanswers'] = 'Этот тип вопроса требует не менее {$a} ответов.';
$string['pleaseenterananswer'] = 'Пожалуйста, введите ответ.';
$string['pluginname'] = 'Распределение рецензентов';
$string['pluginnameadding'] = 'Добавление вопроса «Короткий ответ с данными из профиля»';
$string['pluginnameediting'] = 'Редактирование вопроса «Короткий ответ с данными из профиля».';
$string['pluginname_help'] = 'В качестве ответа на вопрос (который может включать изображение) студент впечатывает одно слово или короткую фразу. Можно указать несколько возможных правильных вариантов ответа, причем каждый с разной оценкой. Если выбран параметр «Учитывать регистр», то студент получит разное количество баллов за ответы типа «Слово» и типа «слово».';
$string['pluginnamesummary'] = 'Позволяет вводить в качестве ответа одно или несколько слов. Задается формат ответа с помощью регулярного выражения.';
$string['privacy:metadata'] = 'Плагин «Тип вопроса Короткий ответ с регулярными выражениями» не хранит никаких персональных данных';
$string['warning']='Внимание! Вы не сможете завершить эту попытку, пока ваш ответ не будет соответствовать заданному формату.';
$string['add_regular_expression']='Регулярное выражение для проверки правильности формата данных';
$string['regular_expression']='Регулярное выражение';
$string['wrong']='<b>Ответ не соответствует заданному формату!</b>';
$string['profiledata']='Выберите форму подачи заявки';
$string['allow_change']='Разрешить пользователю редактировать данные';
$string['add_regex']='Вы также можете указать регулярное выражение для проверки формата введенных пользователем данных';
$string['student']='Студент';
$string['reviewer']='Рецензент';
$string['save']='Сохранить';
$string['changed']='Рецензент сохранен';
$string['lastname']='Фамилия';
$string['firstname']='Имя';
$string['roles']='Роли';
$string['reviewer']='Рецензент';
$string['editor']='Редактор';
$string['chairman']='Председатель';
$string['editing_roles']='Назначение ролей';
$string['search_by_lastname']='поиск по фамилии';
$string['sure_rev']='Вы уверены, что хотите удалить пользователя из списка рецензентов?';
$string['sure_ed']='Вы уверены, что хотите удалить пользователя из списка редакторов?';
$string['sure_sup']='Вы уверены, что хотите удалить пользователя из списка председателей?';
$string['add_rev']='Добавить рецензента';
$string['add_ed']='Добавить редактора';
$string['reviewers']='Рецензенты';
$string['del_rev']='Вы уверены, что хотите удалить этого рецензента?';
$string['editors']='Редакторы';
$string['del_ed']='Вы уверены, что хотите удалить этого редактора?';
$string['del_sub']='Вы уверены, что хотите удалить эту заявку?';
$string['revandeddist']='Распределение рецензентов и редакторов';
