<?php
    //редактирование таблицы со списком рецензентов
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    if (empty(has_capability('moodle/course:update', $context))){
        echo "Forbidden";
    }
    else{
        $course=$_GET['courseid'];
        $activity=$_GET['activityid'];
        $rev=$_GET['reviewer'];
        if(check_revs($course, $activity, $rev)){
            delete_rev($course, $activity, $rev);
        }
        else{
            add_to_revs($course, $activity, $rev);
        }
    }
    
    function add_to_revs($course, $activity, $rev){
        global $DB;
        $newrecord=new stdClass();
        $newrecord->courseid=$course;
        $newrecord->activityid=$activity;
        $newrecord->reviewer=$rev;
        
        
        $DB->insert_record("confdist_reviewers_list", $newrecord);
    }
    
    function check_revs($course, $activity, $reviewer){
        global $DB;
        if ($DB->get_record('confdist_reviewers_list', ['courseid'=>$course, 'activityid'=>$activity, 'reviewer'=>$reviewer])==false)
                return false;
        else
            return true;        
    }
    
    function delete_rev($course, $activity, $reviewer){
        global $DB;
        $DB->delete_records('confdist_reviewers_list', ['courseid'=>$course, 'activityid'=>$activity, 'reviewer'=>$reviewer]);
        $DB->delete_records('confdist_distribution', ['courseid'=>$course, 'activityid'=>$activity, 'reviewer'=>$reviewer]);
    }
?>