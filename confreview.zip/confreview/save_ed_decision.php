<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $student=$_GET['student'];
    $attempt=$_GET['attempt'];
    $editor=$_GET['editor'];
    $dis=$_GET['dis'];
    $DB->delete_records('confreview_ed_dis', ['activityid'=>$quiz, 'courseid'=>$course, 'student'=>$student, 'attempt'=>$attempt, 'editor'=>$editor]);
    $DB->insert_record('confreview_ed_dis', ['activityid'=>$quiz, 'courseid'=>$course, 'student'=>$student, 'attempt'=>$attempt, 'editor'=>$editor, 'decision'=>$dis]);
    echo $dis;
        
    