<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $student=$_GET['student'];
    $attempt=$_GET['attempt'];
    $chairman=$_GET['chairman'];
    $dis=$DB->get_record('confreview_sup_dis', ['activityid'=>$quiz, 'courseid'=>$course, 'student'=>$student, 'attempt'=>$attempt, 'superviser'=>$chairman])->decision;
    echo $dis;
        
    