var options=[];
var words=[];
var reviews=[];
function set_options_author(op, w){
    options=JSON.parse(op);
    awords=JSON.parse(w);
    awords['r_and_d_btn']='<font style="font-size:small">'+awords['r_and_d_btn']+'</font>';
    awords['show_review']='<font style="font-size:small">'+awords['show_review']+'</font>';
    //console.log(awords['hidden1']);
}


function grades_button_for_author(student, course, activity, attempt, form){
    var res='';
    res+='<button class="btn btn-secondary" onclick="grades_for_author('+student+','+course+','+activity+','+attempt+','+form+')">'+awords['r_and_d_btn']+'</button>';
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    document.getElementById('au_grades_'+tdid).innerHTML=res;
}
function close_au_div(){
    document.getElementById('au_wind').style.visibility='hidden';
}
function close_au_div2(){
    document.getElementById('au_wind2').style.visibility='hidden';
    document.getElementById('au_wind').style.visibility='visible';
}

function show_review_to_author(key){
    var review=reviews[key];
    var res='<h5 style="text-align:right; margin-right:4px; cursor:pointer" onclick="close_au_div2()">'+awords['close_rev_div']+'</h5>';
    res+='<h4>'+awords['review_header']+'</h5>';
    if(review!=='null'){
        review=review.replace('&', '&amp;');
        review=review.replace('<', '&lt;');
        res+=review;
    }
    else
        res+=awords['no_review'];
    document.getElementById('au_wind2').innerHTML=res;
    document.getElementById('au_wind2').style.visibility='visible';
    document.getElementById('au_wind').style.visibility='hidden';
}
function grades_for_author(student, course, activity, attempt, form){
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var res='';
    var grades=[];
    var xmlHttp3 = new XMLHttpRequest();
    var url='/question/type/confreview/get_reviews.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt;
    xmlHttp3.open( 'GET', url);         

    xmlHttp3.onload=function() {
        grades=JSON.parse(xmlHttp3.responseText);
//        console.log(grades);
        res+='<h5 style="text-align:right; margin-right:4px; cursor:pointer" onclick="close_au_div()">'+awords['close_rev_div']+'</h5>';
        res+='<h4>'+awords['reviews_header']+'</h4>';
        res+='<div><table class="flexible  generalbox" style="font-size:small">';
        res+='<thead><th>'+awords['reviewer']+'</th><th>'+awords['review']
                +'</th><th>'+awords['reviewer_confidence']+
                '</th><th>'+awords['grade']+'</th></thead>';
        var q=1;
        var span=0;
        for (var key in grades){
            span++;
            res+='<tr >';
            if(options['auth_rev_name']=='1'){
                res+='<td>'+grades[key]['lastname']+' '+grades[key]['firstname']+'</td>';
            }
            else{
                res+='<td>'+awords['reviewer']+' '+q+'</td>';
                q++;
            }
            if(options['auth_rev_review']=='1'){
                reviews[key]=grades[key]['review'];
                res+='<td><button class="btn btn-secondary" onclick="show_review_to_author('+"'"+key+"'"+')">'+awords['show_review']+'</button></td>';
            }
            else{
                res+='<td>'+awords['hidden']+'</td>';
            }
            if(options['auth_rev_conf']=='1'){
                if(grades[key]['confidence']!==null){
                    res+='<td>'+grades[key]['confidence']+'</td>';
                }
                else{
                    res+='<td>-</td>';
                }
            }
            else{
                res+='<td>'+awords['hidden']+'</td>';
            }
            if(options['auth_rev_grade']=='1'){
                if(grades[key]['grade']!==null){
                    res+='<td>'+grades[key]['grade']+'</td>';
                }
                else{
                    res+='<td>-</td>';
                }
            }
            else{
                res+='<td>'+awords['hidden']+'</td>';
            }
            res+='</tr>';
            
        }
        
//        var cells=document.getElementsByClassName('at'+attempt);
//        for (var i=0; i<cells.length; i++){
//            cells[i].rowSpan=span;
//        }
        res+="</table></div>";
        decisions_for_author(student, course, activity, attempt);
        document.getElementById('au_wind').innerHTML=res;
        document.getElementById('au_wind').style.visibility='visible';
    };
    xmlHttp3.send(null);
    
    
}

function decisions_for_author(student, course, activity, attempt){
        var xmlHttp3 = new XMLHttpRequest();
    var url='/question/type/confreview/get_decisions.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt;
    xmlHttp3.open( 'GET', url);         
    var res='';
    xmlHttp3.onload=function() {
        //console.log(xmlHttp3.responseText);
        //null и минус один
        //превращать в слова
                //проверить чтобы можно было скрывать имена редакторов
        var grades=JSON.parse(xmlHttp3.responseText);
//        console.log(grades);
         res+='<h4>'+awords['dis_header']+'</h4>';
        res+='<div><table class="flexible  generalbox" style="font-size:small">';
        res+='<thead><th>'+awords['editor']+'</th><th>'+awords['ed_dis']+'</th></thead>';
        var q=1;
        var span=0;
        for (var key in grades){
            span++;
            res+='<tr >';
            if(options['auth_ed_name']=='1'){
                res+='<td>'+grades[key]['lastname']+' '+grades[key]['firstname']+'</td>';
            }
            else{
                res+='<td>'+awords['editor']+' '+q+'</td>';
                q++;
            }
            if(options['auth_ed_dis']=='1'){
                if(grades[key]['decision']==null || grades[key]['decision']=='-1'){
                    res+='<td>-</td>';
                }
                if(grades[key]['decision']=='0'){
                    res+='<td>'+awords['accept']+'</td>';
                }
                if(grades[key]['decision']=='1'){
                    res+='<td>'+awords['correction']+'</td>';
                }
                if(grades[key]['decision']=='2'){
                    res+='<td>'+awords['decline']+'</td>';
                }
            }
            else{
                res+='<td>'+awords['hidden']+'</td>';
                
            }
            res+='</tr>';
            
            
        }
        
//        var cells=document.getElementsByClassName('at'+attempt);
//        for (var i=0; i<cells.length; i++){
//            cells[i].rowSpan=span;
//        }
        res+="</table></div>";
        document.getElementById('au_wind').innerHTML+=res;
    };
    xmlHttp3.send(null);
}



function approved_for_author(student, course, activity, attempt, chairman){
    var tdid="s"+student+"c"+course+"ac"+activity+"at"+attempt;
    var res='';
    res+="<div id='au_dis_selector"+tdid+"'></div>";
    document.getElementById('au_approved_'+tdid).innerHTML=res;
    
    var xmlHttp3 = new XMLHttpRequest();
    var url='/question/type/confreview/get_sup_decision.php?quiz='+activity+'&course='+course+'&student='+student+'&attempt='+attempt+'&chairman='+chairman;
    xmlHttp3.open( 'GET', url);         

    xmlHttp3.onload=function() {
        var decision=xmlHttp3.responseText;
        if(options['auth_sup_dis']=='1'){
            if(decision=='0'){
                decision=awords['accept'];
                document.getElementById('au_dis_selector'+tdid).style.backgroundColor='#BDFFAB';
            }
            if(decision=='1'){
                decision=awords['correction'];
                document.getElementById('au_dis_selector'+tdid).style.backgroundColor='#FFFFAB';
            }
            if(decision=='2'){
                decision=awords['decline'];
                document.getElementById('au_dis_selector'+tdid).style.backgroundColor='#FFABAB';
            }
            document.getElementById('au_dis_selector'+tdid).innerHTML=decision;
        }
        else{
            document.getElementById('au_dis_selector'+tdid).innerHTML=awords['hidden'];
        }
        //console.log(decision);
    };
    xmlHttp3.send(null);
    
}



function display_authors(){
    //вниз когда открыто
           //вправо когда закрыто
    if(document.getElementById('au_tab').style.display=='none'){
        document.getElementById('au_tab').style.display='block';
        document.getElementById('au_tri').innerHTML='&#9662;';
    }
    else{
    document.getElementById('au_tab').style.display='none';
    document.getElementById('au_tri').innerHTML='&#9656;';
}
}



