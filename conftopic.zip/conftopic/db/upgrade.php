<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Short-answer question type upgrade code.
 *
 * @package    qtype
 * @subpackage conftopic
 * @copyright  2011 The Open University
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade code for the essay question type.
 * @param int $oldversion the version we are upgrading from.
 */
function xmldb_qtype_conftopic_upgrade($oldversion) {
    global $CFG;

    // Automatically generated Moodle v3.3.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.4.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.5.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.6.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.7.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.8.0 release upgrade line.
    // Put any upgrade step following this.
    global $DB;
    $dbman = $DB->get_manager();

    /// Add a new column newcol to the mdl_myqtype_options
        if ($oldversion < 2019111815) {

        // Define field usecase to be added to qtype_conftopic_options.
        $table = new xmldb_table('qtype_conftopic_options');
        $field = new xmldb_field('usecase', XMLDB_TYPE_INTEGER, '2', null, null, null, null, 'questionid');

        // Conditionally launch add field usecase.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Conftopic savepoint reached.
        upgrade_plugin_savepoint(true, 2019111815, 'qtype', 'conftopic');
    }
        if ($oldversion < 2019111815) {

        // Define field profiledata to be added to qtype_conftopic_options.
        $table = new xmldb_table('qtype_conftopic_options');
        $field = new xmldb_field('profiledata', XMLDB_TYPE_CHAR, '20', null, null, null, null, 'usecase');

        // Conditionally launch add field profiledata.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Conftopic savepoint reached.
        upgrade_plugin_savepoint(true, 2019111815, 'qtype', 'conftopic');
    }
     if ($oldversion < 2019111816) {

        // Define table conftopic_fields to be created.
        $table = new xmldb_table('conftopic_fields');

        // Adding fields to table conftopic_fields.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('fieldid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);

        // Adding keys to table conftopic_fields.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for conftopic_fields.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Conftopic savepoint reached.
        upgrade_plugin_savepoint(true, 2019111816, 'qtype', 'conftopic');
    }
     if ($oldversion < 2019111817) {

        // Define field form to be added to conftopic_fields.
        $table = new xmldb_table('conftopic_fields');
        $field = new xmldb_field('form', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'activityid');

        // Conditionally launch add field form.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Conftopic savepoint reached.
        upgrade_plugin_savepoint(true, 2019111817, 'qtype', 'conftopic');
    }
        if ($oldversion < 2019111818) {

        // Define table conf_chosen_topics to be created.
        $table = new xmldb_table('conf_chosen_topics');

        // Adding fields to table conf_chosen_topics.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('activityid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('reviewer', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('topic', XMLDB_TYPE_CHAR, '255', null, null, null, null);

        // Adding keys to table conf_chosen_topics.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for conf_chosen_topics.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Conftopic savepoint reached.
        upgrade_plugin_savepoint(true, 2019111818, 'qtype', 'conftopic');
    }


    return true;
}
