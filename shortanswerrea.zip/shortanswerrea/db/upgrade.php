<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Short-answer question type upgrade code.
 *
 * @package    qtype
 * @subpackage shortanswerrea
 * @copyright  2011 The Open University
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade code for the essay question type.
 * @param int $oldversion the version we are upgrading from.
 */
function xmldb_qtype_shortanswerrea_upgrade($oldversion) {
    global $CFG;
    global $DB;
    $dbman = $DB->get_manager();
    // Automatically generated Moodle v3.3.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.4.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.5.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.6.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.7.0 release upgrade line.
    // Put any upgrade step following this.

    // Automatically generated Moodle v3.8.0 release upgrade line.
    // Put any upgrade step following this.
    if ($oldversion < 2019111803) {

        // Define table conf_submission to be created.
        $table = new xmldb_table('conf_submission');

        // Adding fields to table conf_submission.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('quizid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('attemptid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('quiestionid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('questiontext', XMLDB_TYPE_CHAR, '255', null, null, null, null);
        $table->add_field('answer', XMLDB_TYPE_CHAR, '255', null, null, null, null);

        // Adding keys to table conf_submission.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);

        // Conditionally launch create table for conf_submission.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Shortanswerrea savepoint reached.
        upgrade_plugin_savepoint(true, 2019111803, 'qtype', 'shortanswerrea');
    }
        if ($oldversion < 2019111804) {

        // Define field tip to be added to qtype_shortanswerrea_options.
        $table = new xmldb_table('qtype_shortanswerrea_options');
        $field = new xmldb_field('tip', XMLDB_TYPE_CHAR, '255', null, null, null, null, 'profiledata');

        // Conditionally launch add field tip.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Shortanswerrea savepoint reached.
        upgrade_plugin_savepoint(true, 2019111804, 'qtype', 'shortanswerrea');
    }
    
        if ($oldversion < 2019111806) {

        // Changing precision of field answer on table conf_submission to (1333).
        $table = new xmldb_table('conf_submission');
        $field = new xmldb_field('answer', XMLDB_TYPE_CHAR, '1333', null, null, null, null, 'questiontext');

        // Launch change of precision for field answer.
        $dbman->change_field_precision($table, $field);

        // Shortanswerrea savepoint reached.
        upgrade_plugin_savepoint(true, 2019111806, 'qtype', 'shortanswerrea');
    }
    return true;
}
