<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'qtype_confreview', language 'en', branch 'MOODLE_20_STABLE'
 *
 * @package    qtype
 * @subpackage confreview
 * @copyright  1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['addmoreanswerblanks'] = 'Blanks for {no} More Answers';
$string['answer'] = 'Answer: {$a}';
$string['answermustbegiven'] = 'You must enter an answer if there is a grade or feedback.';
$string['answerno'] = 'Answer {$a}';
$string['caseno'] = 'No, case is unimportant';
$string['casesensitive'] = 'Case sensitivity';
$string['caseyes'] = 'Yes, case must match';
$string['correctansweris'] = 'The correct answer is: {$a}';
$string['correctanswers'] = 'Correct answers';
$string['filloutoneanswer'] = 'You must provide at least one possible answer. Answers left blank will not be used. \'*\' can be used as a wildcard to match any characters. The first matching answer will be used to determine the score and feedback.';
$string['notenoughanswers'] = 'This type of question requires at least {$a} answers';
$string['pleaseenterananswer'] = 'Please enter an answer.';
$string['pluginname'] = 'Reviewing form';
$string['pluginname_help'] = 'In response to a question (that may include an image) the respondent types a word or short phrase. There may be several possible correct answers, each with a different grade. If the "Case sensitive" option is selected, then you can have different scores for "Word" or "word".';
$string['pluginname_link'] = 'question/type/confreview';
$string['pluginnameadding'] = 'Adding a reviewing form';
$string['pluginnameediting'] = 'Editing a reviewing form';
$string['pluginnamesummary'] = 'Allows a response of one or a few words that is graded by comparing against various model answers, which may contain wildcards.';
$string['privacy:metadata'] = 'The Short answer question type plugin does not store any personal data.';
$string['wrong_grade']='Invalid value';
$string['choose_quiz']='Select submission form';
$string['choose_fields_auth']='Choose which fields to show authors';
$string['choose_fields_rev']='Choose which fields to show reviewers';
$string['choose_fields_ed']='Choose which fields to show editors';
$string['choose_fields_sup']='Choose which fields to show chairman';
$string['ed_rev_name']='Names of reviewers';
$string['sup_rev_name']='Names of reviewers';
$string['sup_ed_name']='Names of editors';
$string['auth_rev_name']='Names of reviewers';
$string['auth_rev_grade']='Grades';
$string['auth_rev_conf']="Reviewers' confidence";
$string['auth_rev_review']='Reviews';
$string['auth_ed_name']='Names of editors';
$string['auth_ed_dis']="Editors' decisions";
$string['auth_sup_name']='Name of the chairman';
$string['auth_sup_dis']='Decision of the chairman';
$string['grades_range']='Grades range';
$string['1to5']='from 1 to 5';
$string['1to10']='from 1 to 10';
$string['1to100']='from 1 to 100';
$string['-3to3']='from -3 to 3';
$string['passing_grade']='Passing grade';
$string['passing_avg']='Passing average grade';
$string['ed_rev']='Reviewer';
$string['hidden']='Hidden';
$string['close_rev_div']='Close';
$string['show_review']='Show review';
$string['review_header']='Review';
$string['reviews_header']='Reviews';
$string['no_review']='There is no review to show';
$string['reviewer']='Reviewer';
$string['review']='Review';
$string['reviewer_confidence']="Reviewer's confidence";
$string['comment']='Comment for editors';
$string['accept']='Accept submission';
$string['decline']='Reject submission';
$string['correction']='Corrections needed';
$string['final_decision']='Final decision';
$string['r_and_d']="Reviews and editors' decisions";
$string['r_and_d_btn']="Show reviews and editors' decisions";
$string['dis_header']="Editors's decisions";
$string['editor']='Editor';
$string['ed_dis']='Decision';
$string['author_field']='View submissions for authors';
$string['3grade']='3: strong accept';
$string['2grade']='2: accept';
$string['1grade']='1: weak accept';
$string['0grade']='0: borderline paper';
$string['-1grade']='-1: weak reject';
$string['-2grade']='-2: reject';
$string['-3grade']='-3: strong reject';
$string['5conf']='5: expert';
$string['4conf']='4: high';
$string['3conf']='3: medium';
$string['2conf']='2: low';
$string['1conf']='1: none';
$string['comment_for_ed']='Comment for editor';
$string['rev_confidence']="Reviewer's confidence";
$string['reviewers_field']='View submissions for reviewers';
$string['view_review']='Show review';
$string['close_review']='Hide review';
$string['save_review']='Save review';
$string['reviews_button']='Show reviews';
$string['close_rev_div']='Close';
$string['editors_field']='View submissions for editors';
$string['reviews']='Reviews';
$string['avg_grade']='Average grade';
$string['min_grade']='The lowest grade';
$string['missing_reviews']='Awaiting reviews';
$string['decision']='Decision';
$string['chairmen_field']='View submissions for chairman';
$string['grade']="Grade";
$string['close_rev_div']="Close";




