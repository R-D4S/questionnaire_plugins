<?php
    
    function confdist_get_quizes(){
        global $DB;
        global $COURSE;
        $course_id=$COURSE->id;
        $table='quiz';
        $quizes=$DB->get_records($table, ['course'=>$course_id]);
        $res=[];
        foreach($quizes as $value){
            array_push($res, $value->id.' '.$value->name);
        }
        return $res;
    }
    //onchange сделать отдельный сервис, который выполняет вот эту вот функцию и возвращает таблицу
    //qa передаем как json
    
    
    
    function confdist_distribution($qa, $cid){
        $res='<script type="text/javascript" src="../../question/type/confdist/sorttable.js"></script>';
        $res.="<script>document.getElementById('reviewers_distribution_table').style.fontSize='90%'</script>";
        //confdist_hide();
        global $DB;
        global $COURSE;
        $course_id=$cid;
        $activity_id=get_activity_id($qa, $course_id);
        $topic_field=get_topic_field($course_id, $activity_id);
        $query='select s.id, s.userid, s.attemptid, s.questiontext, s.answer, u.lastname, u.firstname from mdl_conf_submission s join mdl_user u on u.id=userid where quizid=? and courseid=? ;';
        $students=$DB->get_records_sql($query, [$activity_id, $course_id]);
        
        $fields=[];
        $students2=[];
        foreach($students as $student){
            $student2=['userid'=>$student->userid,'lastname'=>$student->lastname, 'firstname'=>$student->firstname, 'attemptid'=>$student->attemptid];
            
            if(!in_array($student2, $students2)){
//                $answers=[];
//                $student2['answers']=$answers;
                array_push($students2, $student2);
            }
            if(!in_array($student->questiontext, $fields)){
                array_push($fields, $student->questiontext);
            }
        }
        
    
        //
        foreach($students as $student){
            foreach($students2 as $key=>$value){
                if($student->userid===$students2[$key]['userid'] and $student->attemptid===$students2[$key]['attemptid']){
                    
                    $students2[$key]['answers'][$student->questiontext]=[$student->answer];
                    
                }
            }
        }
        
        $file_headers=[];
        $students3=$DB->get_records('conf_files', ['quizid'=>$activity_id, 'courseid'=>$course_id]);
        foreach($students3 as $student){
            if(!in_array($student->questionname, $file_headers)){
                        $file_headers[]=$student->questionname;
                    }
        }
        foreach ($students2 as $key=>$value){
            foreach($file_headers as $fh){
                $students2[$key]['answers'][$fh]='';
            }
        }
        
        foreach($students3 as $student){
            foreach($students2 as $key=>$value){
                if($student->userid===$students2[$key]['userid'] and $student->attemptid===$students2[$key]['attemptid']){
                    if($student->filename!==''){
                        $students2[$key]['answers'][$student->questionname]=[
                            '<a href="../../question/type/confdist/save_file.php?file='.$student->filename.'">'.$student->filename.'</a>'];
                            //' <img src="../../question/type/confdist/pix/save.png" width="20" style="cursor:pointer" onclick="save_file('."'".$student->filename."'".')">'];
                    }
                    
                }
            }
        }
        $field_nmb=count(end($students2)['answers']);
        $chosen_fields=$DB->get_records('confdist_reviewers_fields', ['courseid'=>$course_id, 'activityid'=>$activity_id]);
        $chosen_fields_arr=[];
        foreach($chosen_fields as $field){
            $chosen_fields_arr[]=(int)$field->field;
        }
        foreach($file_headers as $v){
            $chosen_fields_arr[]=$field_nmb-1;
            $field_nmb-=1;
        }
        $counter=0;
        $headers='<thead>';
        foreach($fields as $key=>$value){
            
            $fields[$key]=str_replace('</p>', '', str_replace('<p>', '', $value));
            if(in_array($counter, $chosen_fields_arr)){
                $headers.='<th style="cursor:pointer">'.$fields[$key].'</th>';
            }
            $counter+=1;
            
        }
        foreach($file_headers as $key=>$value){
            
            $file_headers[$key]=str_replace('</p>', '', str_replace('<p>', '', $value));
            
            $headers.='<th style="cursor:pointer">'.$file_headers[$key].'</th>';
            
            
        }
        
        
        
        //$res.="<br><h4>Назначение рецензентов!</h4>";
        $res.=fields_search($fields, $course_id, $activity_id, $qa);
        //$res.='<table class="flexible generaltable generalbox" id="reviewers_distribution_table">';
        $res.=str_replace('</p>', '', str_replace('<p>', '', $headers)).'<th>'.get_string('reviewers', 'qtype_confdist').
                '</th>'.'<th>'.get_string('add_rev', 'qtype_confdist').'</th><th>'.
                get_string('editors', 'qtype_confdist').'</th><th>'.get_string('add_ed', 'qtype_confdist').'</th><th></th></tr></thead>';
        $res.='<tbody>';
        foreach($students2 as $student){
            $counter=0;
            $res.="<tr>";
//            $res.="<td>".$student['lastname'].' '.$student['firstname']."</td>";
            foreach($student['answers'] as $answer){
                if(in_array($counter, $chosen_fields_arr)){
                    $res.="<td>".$answer[0]."</td>";
                }
                $counter+=1;
            }
            $res.="<td>".get_assigned_reviewers($course_id, $activity_id, $student['userid'], $student['attemptid'], $qa);
            $res.="<td>".get_reviewers($course_id, $student['userid'], $qa, $student['attemptid'], $student['answers'])."</td>";
            $res.="<td>".get_assigned_editors($course_id, $activity_id, $student['userid'], $student['attemptid'], $qa);
            $res.="<td>".get_editors($course_id, $student['userid'], $qa, $student['attemptid'])."</td>";
            $res.='<td style="color:blue; display:inline; cursor:pointer" onclick='."'delete_submission(".$student['userid'].','.$student['attemptid'].','.$course_id.','.$activity_id.','.$qa.")'>[x]</td>";
            $res.="</tr>";
        }
        $res.="</tbody>";
        $res.='<script type="text/javascript" src="../../question/type/confdist/edit_distribution.js"></script>';
        $words=['del_rev'=>get_string('del_rev', 'qtype_confdist'),
            'del_ed'=>get_string('del_rev', 'qtype_confdist'),
            'del_sub'=>get_string('del_sub', 'qtype_confdist')];
        $res.="<script>set_options2('".JSON_encode($words)."')</script>";
        return $res;
    }
    
    
    
    function get_reviewers($course_id, $id, $qa, $attempt, $answers){
        global $DB;
        $activity_id=get_activity_id($qa, $course_id);
        $revs=[];
        $query='SELECT u.id, u.lastname, u.firstname FROM mdl_user u JOIN mdl_confdist_reviewers_list rl ON rl.reviewer=u.id WHERE courseid=? AND activityid=?;';
        $reviewers=$DB->get_records_sql($query, [$course_id, $activity_id]);
        foreach($reviewers as $value){
            
            array_push($revs, ['id'=>$value->id, 'firstname'=>$value->firstname, 'lastname'=>$value->lastname]);
        }
        $res='';
        //$res.='<select id="reviewer'.$id.'" onchange="change_rev('.$course_id.','.$id.','."document.getElementById('reviewer".$id."').value".",document.getElementById('confdisturl').value".')">';
        $res.='<select id="reviewer'.$id."+".$attempt.'" onchange="change_rev('.$course_id.','.$activity_id.','.$id.','."document.getElementById('reviewer".$id."+".$attempt."').value,".$attempt.",".$qa.')"'.">";
        $res.="<option value='-1'></option>";
        foreach ($revs as $value){
            
            if (check_reviewer($course_id, $activity_id, $value['id'], $answers)){
                $res.="<option style='background-color:lightgreen' value='".$value['id']."'>".$value['firstname'].' '.$value['lastname'].'</option>';
            }
            else{                
                $res.="<option value='".$value['id']."'>".$value['lastname'].' '.$value['firstname'].'</option>';
            }
        }
        
        $res.='</select>';
        $res.='<script type="text/javascript" src="../../question/type/confdist/edit_distribution.js"></script>';
        
        
        
        
        return $res;
    }
    
    function check_reviewer($course, $activity, $rev, $answers){
        global $DB;
        $chosen_topics=$DB->get_records('conf_chosen_topics', ['reviewer'=>$rev, 'activityid'=>$activity, 'courseid'=>$course]);
        $topics=[];
        $flag=false;
        foreach($chosen_topics as $topic){
            foreach($answers as $answer){
                foreach($answer as $ans){
                    if($ans==$topic->topic){
                        $flag=true;
                    }
                }
            }
        }
        return $flag;
        
    }
    
    function get_editors($course_id, $id, $qa, $attempt){
        global $DB;
        $activity_id=get_activity_id($qa, $course_id);
        $eds=[];
        $query='SELECT u.id, u.lastname, u.firstname FROM mdl_user u JOIN mdl_confdist_editors_list rl ON rl.editor=u.id WHERE courseid=? AND activityid=?;';
        $editors=$DB->get_records_sql($query, [$course_id, $activity_id]);
        foreach($editors as $value){
            array_push($eds, ['id'=>$value->id, 'firstname'=>$value->firstname, 'lastname'=>$value->lastname]);
        }
        $res='';
        //$res.='<select id="reviewer'.$id.'" onchange="change_rev('.$course_id.','.$id.','."document.getElementById('reviewer".$id."').value".",document.getElementById('confdisturl').value".')">';
        $res.='<select id="editor'.$id."+".$attempt.'" onchange="change_ed('.$course_id.','.$activity_id.','.$id.','."document.getElementById('editor".$id."+".$attempt."').value,".$attempt.",".$qa.')"'.">";
        $res.="<option value='-1'></option>";
        foreach ($eds as $value){
            
//            if (check_reviewer($course_id, $activity_id, $id, $value['id'], $attempt)){
//                $res.="<option selected value='".$value['id']."'>".$value['firstname'].' '.$value['lastname'].'</option>';
//            }
//            else{                
                $res.="<option value='".$value['id']."'>".$value['lastname'].' '.$value['firstname'].'</option>';
//            }
        }
        
        $res.='</select>';
        $res.='<script type="text/javascript" src="../../question/type/confdist/edit_distribution.js"></script>';
        
        
        
        
        return $res;
    }
    
    function get_assigned_reviewers($course, $activity, $student, $attempt, $qa){
        $res='<script type="text/javascript" src="../../question/type/confdist/edit_distribution.js"></script>';
        $res.='<table>';
        global $DB;
        $reviewers=$DB->get_records("confdist_distribution", ['courseid'=>$course, 'activityid'=>$activity, 'student'=>$student, 'attempt'=>$attempt]);
        $reviewer_names=[];
        foreach($reviewers as $rev){
            $current_reviewer=$DB->get_records('user', ['id'=>$rev->reviewer]);
            foreach($current_reviewer as $value){
                $reviewer_names[]=['name'=>$value->lastname.' '.$value->firstname, 'id'=>$rev->reviewer];
            }
        }
        foreach($reviewer_names as $value){
            $res.=$value['name'].' '.'<div style="color:blue; display:inline; cursor:pointer" onclick="delete_rev('.$course.','.$activity.','.$student.','.$attempt.','.$value['id'].','.$qa.')">[x]</div><br>';
        }
        $res.="</table>";
        return $res;
    }
    
    function get_assigned_editors($course, $activity, $student, $attempt, $qa){
        $res='<script type="text/javascript" src="../../question/type/confdist/edit_distribution.js"></script>';
        $res.='<table>';
        global $DB;
        $editors=$DB->get_records("confdist_editors_dist", ['courseid'=>$course, 'activityid'=>$activity, 'student'=>$student, 'attempt'=>$attempt]);
        $editor_names=[];
        foreach($editors as $ed){
            $current_editor=$DB->get_records('user', ['id'=>$ed->editor]);
            foreach($current_editor as $value){
                $editor_names[]=['name'=>$value->lastname.' '.$value->firstname, 'id'=>$ed->editor];
            }
        }
        foreach($editor_names as $value){
            $res.=$value['name'].' '.'<div style="color:blue; display:inline; cursor:pointer" onclick="delete_ed('.$course.','.$activity.','.$student.','.$attempt.','.$value['id'].','.$qa.')">[x]</div><br>';
        }
        $res.="</table>";
        return $res;
    }
    
    function confdist_hide(){
        
        $res="<script>";
        $res.='document.addEventListener("DOMContentLoaded", function(e) {';
      
    
        $res.="var elements=document.getElementsByClassName('info');";
        $res.="for (var i=0; i<elements.length; i++){";
        
        $res.="elements[i].style.display='none'";
        $res.="}";
        $res.="var elements=document.getElementsByClassName('mod_quiz-next-nav btn btn-primary');";
        $res.="for (var i=0; i<elements.length; i++){";
        $res.="if(i==0)";
        $res.="elements[i].style.display='none'";
        $res.="}";
        
        $res.="document.getElementById('mod_quiz_navblock').style.display='none';";
        
        
        $res.='var el=document.querySelectorAll("'."[role='main']".':last-of-type")[0];';//кавычки
        //$res.="el.innerHTML.replace(/<form.*>/gm, '<div>');";        
        //$res.="el.innerHTML.replace(/<\/form>/gm, '</div>');"; 
        //$res.="console.log(el)";
        $res.=' });';
        
        $res.="</script>";
        
        echo $res;
    }
    
    function get_activity_id($numb, $course){
        global $DB;
        $course_id=$course;
        $table='quiz';
        $quizes=$DB->get_records($table, ['course'=>$course_id]);
        $i=0;
        $res=0;
        foreach($quizes as $value){
            if($i==$numb)
                $res=$value->id;
            $i+=1;
        }
        return $res;
    }
    
    
   
    //вывод чекбоксов для выбора полей для отображения в таблице распределения рецензентов
    function fields_search($fields, $course, $activity, $qa){
        global $DB;
        global $chosen_fields_arr;
        $fields_arr=[];
        $i=0;
        foreach($fields as $field){
            $fields_arr[]=['id'=>$i, 'name'=>$field];
            $i+=1;
        }
        //if there are no records
        if(count($DB->get_records('confdist_reviewers_fields', ['activityid'=>$activity, 'courseid'=>$course]))==0){
            foreach($fields_arr as $field){
                $newrecord=new stdClass();
                $newrecord->activityid=$activity;
                $newrecord->courseid=$course;
                $newrecord->field=$field['id'];
                $DB->insert_record('confdist_reviewers_fields', $newrecord);
            }
        }
        
        $chosen_fields=$DB->get_records('confdist_reviewers_fields', ['courseid'=>$course, 'activityid'=>$activity]);
        $chosen_fields_arr=[];
        foreach($chosen_fields as $field){
            $chosen_fields_arr[]=$field->field;
        }
        $res='<script type="text/javascript" src="../../question/type/confdist/fields.js"></script>';
        $res.="<script>document.getElementById('fields_selector').innerHTML='';";
        foreach($fields_arr as $key=>$field){
            if(in_array($field['id'], $chosen_fields_arr)){
                $res.="document.getElementById('fields_selector').innerHTML+=`"."<input type='checkbox' onchange='change_fields(".$course.",".$activity.",".$qa.",".$course.")' checked class='field' value='".$field['id']."'> ".$field['name']."<br>"."`;";
            }
            else{
                $res.="document.getElementById('fields_selector').innerHTML+=`"."<input type='checkbox' onchange='change_fields(".$course.",".$activity.",".$qa.",".$course.")' class='field' value='".$field['id']."'> ".$field['name']."<br>"."`;";
            }
        }
        $res.="</script>";
        //$res.='<button onclick="window.location = window.location.href;" class="btn btn-secondary">Применить изменения!</button>';
        //для штуки с выбором полей сделать новый див и не возвращать рез а делать его иннерхтмл
        return $res;
    }
    
    function get_topic_field($course, $activity){
        global $DB;
        $fieldid='';
        $fields=$DB->get_records('conftopic_fields', ['activityid'=>$activity, 'courseid'=>$course]);
        foreach($fields as $value){
            $fieldid=$value->fieldid;
        }
        return $fieldid;
    }
?>