function change_rev(course_id, activity_id, student, reviewer, attempt, qa){
    var xmlHttp = new XMLHttpRequest();
    var url='/question/type/confdist/add_to_dist.php?courseid='+course_id+'&activityid='+activity_id+'&student='+student+'&reviewer='+reviewer+'&attempt='+attempt;
    xmlHttp.open( 'GET', url, true ); // false for synchronous request
    xmlHttp.onreadystatechange=function() {
        apply_changes(qa, course_id);
    };
    xmlHttp.send( null );
    console.log( xmlHttp.responseText);
}
function apply_changes(qa, course){
    var xmlhttp = new XMLHttpRequest();
    var url='/question/type/confdist/apply_change.php?qa='+qa+'&course='+course;
    xmlhttp.open( 'GET', url, true); 
    
    xmlhttp.onreadystatechange=function() {
        //console.log(xmlHttp.responseText==null);
         if (xmlhttp.readyState === 4) {
            document.getElementById("reviewers_distribution_table").innerHTML=xmlhttp.responseText;
        }
    };
    xmlhttp.send(null);
}
words2=[];
function set_options2(w){
    words2=JSON.parse(w);
}
//тут удаляется назначение
function delete_rev(course, activity, student, attempt, reviewer, qa){
    if (confirm(words2['del_rev'])) {
        var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confdist/delete_dist.php?courseid='+course+'&activityid='+activity+'&student='+student+'&reviewer='+reviewer+'&attempt='+attempt;
        xmlHttp.open( 'GET', url, true ); // false for synchronous request
        xmlHttp.onreadystatechange=function() {
            apply_changes(qa, course);
        };
        xmlHttp.send( null );
        console.log( xmlHttp.responseText);
    }
    
}

function change_ed(course_id, activity_id, student, editor, attempt, qa){
    var xmlHttp = new XMLHttpRequest();
    var url='/question/type/confdist/add_to_editors_dist.php?courseid='+course_id+'&activityid='+activity_id+'&student='+student+'&editor='+editor+'&attempt='+attempt;
    xmlHttp.open( 'GET', url, true ); // false for synchronous request
    xmlHttp.onreadystatechange=function() {
        apply_changes(qa, course_id);
    };
    xmlHttp.send( null );
    console.log( xmlHttp.responseText);
}

function delete_ed(course, activity, student, attempt, editor, qa){
    if (confirm(words2['del_ed'])) {
        var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confdist/delete_editor_dist.php?courseid='+course+'&activityid='+activity+'&student='+student+'&editor='+editor+'&attempt='+attempt;
        xmlHttp.open( 'GET', url, true ); // false for synchronous request
        xmlHttp.onreadystatechange=function() {
            apply_changes(qa, course);
        };
        xmlHttp.send( null );
        console.log( xmlHttp.responseText);
    }
    
}

function delete_submission(student, attempt, course, activity, qa){
    if (confirm(words2['del_sub'])) {
        var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confdist/delete_submission.php?courseid='+course+'&activityid='+activity+'&student='+student+'&attempt='+attempt;
        xmlHttp.open( 'GET', url, true ); // false for synchronous request
        xmlHttp.onreadystatechange=function() {
            apply_changes(qa, course);
        };
        xmlHttp.send( null );
        console.log( xmlHttp.responseText);
    }
}

function save_file(file_name){
   var xmlHttp = new XMLHttpRequest();
        var url='/question/type/confdist/save_file.php?file='+file_name;
        xmlHttp.open( 'GET', url, true ); // false for synchronous request
        xmlHttp.onreadystatechange=function() {
            console.log( xmlHttp.responseText);
        };
        xmlHttp.send( null );
        
}