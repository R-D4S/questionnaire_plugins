<?php

function conftopic_hide(){
        
        $res="<script>";
        $res.='document.addEventListener("DOMContentLoaded", function(e) {';
      
    
        $res.="var elements=document.getElementsByClassName('info');";
        $res.="for (var i=0; i<elements.length; i++){";
        
        $res.="elements[i].style.display='none'";
        $res.="}";
        $res.="var elements=document.getElementsByClassName('mod_quiz-next-nav btn btn-primary');";
        $res.="for (var i=0; i<elements.length; i++){";
        $res.="if(i==0)";
        $res.="elements[i].style.display='none'";
        $res.="}";
        
        $res.="document.getElementById('mod_quiz_navblock').style.display='none';";
        
        
        $res.='var el=document.querySelectorAll("'."[role='main']".':last-of-type")[0];';//кавычки
        //$res.="el.innerHTML.replace(/<form.*>/gm, '<div>');";        
        //$res.="el.innerHTML.replace(/<\/form>/gm, '</div>');"; 
        //$res.="console.log(el)";
        $res.=' });';
        
        $res.="</script>";
        
        echo $res;
    }
    
    function conftopic_output_topics(){
        global $DB;
        global $USER;
        $userid=$USER->id;
        $formid=$_GET['cmid'];
        $fields=$DB->get_records('conftopic_fields', ['form'=>$formid]);
        $activity='';
        $course='';
        foreach($fields as $value){
            $course=$value->courseid;
            $activity=$value->activityid;
        }
        var_dump($activity);
        if(count($DB->get_records('confdist_reviewers_list', ['reviewer'=>$userid, 'courseid'=>$course, 'activityid'=>$activity]))==0){
            return '';
        }
        else{
            $topics=JSON_encode(conftopic_get_topics());
            $res='<script type="text/javascript" src="../../question/type/conftopic/controls.js"></script>'; 
            $res.='<script>select_topics('.$topics.','.$activity.','.$course.','.$userid.');</script>';
            return $res;
        }
    }
    
    function conftopic_get_topics(){
        global $DB;
        global $USER;
        $userid=$USER->id;
        
        $formid=$_GET['cmid'];
        $fields=$DB->get_records('conftopic_fields', ['form'=>$formid]);
        $field='';
        $activity='';
        $course='';
        foreach($fields as $value){
            $field=$value->fieldid;
            $course=$value->courseid;
            $activity=$value->activityid;
        }
        
            $submissions=$DB->get_records('conf_submission', ['courseid'=>$course, 'quizid'=>$activity]);
            $topics=[];
            foreach($submissions as $submission){
                if($submission->quiestionid==$field){
                    $topics[]=$submission->answer;
                }
            }
            return $topics;
        
    }
    
    function conftopic_output_chosen_topics(){
        global $DB;
        global $USER;
        $userid=$USER->id;
        
        $formid=$_GET['cmid'];
        $fields=$DB->get_records('conftopic_fields', ['form'=>$formid]);
        $activity='';
        $course='';
        foreach($fields as $value){
            $course=$value->courseid;
            $activity=$value->activityid;
        }
        $topics=$DB->get_records('conf_chosen_topics', ['activityid'=>$activity, 'courseid'=>$course, 'reviewer'=>$userid]);
        $res='<br><h4>'.'Выбранные темы:'.'</h4><br>';
        foreach($topics as $topic){
            $res.=$topic->topic.'<br>';
        }
        $res.='<br>';
        return $res;
    }

