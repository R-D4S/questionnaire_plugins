<?php
//список пользователей для добавления в список рецензентов
    function output_reviewers($qa){
        $res='<script type="text/javascript" src="../../question/type/confdist/search.js"></script>';
        $words=['sure_rev'=>get_string('sure_rev', 'qtype_condist'),
            'sure_ed'=>get_string('sure_ed', 'qtype_confdist'),
            'sure_sup'=>get_string('sure_sup', 'qtype_confdist')];
        $res.="<script>set_options('".JSON_encode($words)."')</script>";
        require_once 'confdist_edit_settings.php';
        global $DB;
        global $USER;
        global $COURSE;
        $activity_id=get_activity_id($qa->get_question()->profiledata, $COURSE->id);
        $context = context_module::instance($COURSE->id);
        if (empty(has_capability('moodle/course:update', $context))){
            $res.= "Forbidden";
        }
        else{
            $users=get_enrolled_users($context);
            $res.="<br><table id='users_list' class='flexible generaltable generalbox'>".'<thead><tr><th  style="cursor:pointer">'.
                    get_string('lastname', 'qtype_confdist').'</th><th style="cursor:pointer">'.
                    get_string('firstname', 'qtype_confdist').'</th><th style="cursor:pointer">'.get_string('roles', 'qtype_confdist').
                    '</th><th>'.get_string('reviewer', 'qtype_confdist').'</th><th>'.get_string('editor', 'qtype_confdist').'</th><th>'.get_string('chairman', 'qtype_confdist')
                    .'</th></tr></thead>';
            $res.="<tbody>";
            foreach($users as $user){
                $roles=get_user_roles($context, $user->id);
                $roles_str='';
                foreach($roles as $role){
                    $role_name=get_role_name($role->shortname);
                    if(!in_array($role_name, $roles_arr)){
                        array_push($roles_arr, $role_name);
                    }
                    $roles_str.=$role_name.', ';
                }
                $roles_str=substr($roles_str, 0, -2);
                $res.="<tr id='user".$user->id."'>";
                $res.="<td class='lastname'>".$user->lastname."</td>";
                $res.="<td>".$user->firstname."</td>";
                $res.="<td class='roles'>".$roles_str."</td>";
                if (check_rev_record($user->id, $COURSE->id, $activity_id)){
                    $res.="<td><input type='checkbox' class='reviewer_checkbox' checked id='checkbox_rev".$user->id."' onchange='add_to_revs(".$user->id.",".$COURSE->id.",".$activity_id.','.$qa->get_question()->profiledata.")'></td>";
                }
                else{
                   $res.="<td><input type='checkbox' class='reviewer_checkbox' id='checkbox_rev".$user->id."' onchange='add_to_revs(".$user->id.",".$COURSE->id.",".$activity_id. ','.$qa->get_question()->profiledata.")'></td>";
                }
                if (check_editor_record($user->id, $COURSE->id, $activity_id)){
                    $res.="<td><input type='checkbox' class='editor_checkbox' checked id='checkbox_ed".$user->id."' onchange='add_to_editors(".$user->id.",".$COURSE->id.",".$activity_id.','.$qa->get_question()->profiledata. ")'></td>";
                }
                else{
                   $res.="<td><input type='checkbox' class='editor_checkbox' id='checkbox_ed".$user->id."' onchange='add_to_editors(".$user->id.",".$COURSE->id.",".$activity_id.','.$qa->get_question()->profiledata. ")'></td>";
                }
                if (check_chairman_record($user->id, $COURSE->id, $activity_id)){
                    $res.="<td><input type='checkbox' class='chairman_checkbox' checked id='checkbox_sup".$user->id."' onchange='add_to_chairmen(".$user->id.",".$COURSE->id.",".$activity_id.','.$qa->get_question()->profiledata. ")'></td>";
                }
                else{
                   $res.="<td><input type='checkbox' class='chairman_checkbox' id='checkbox_sup".$user->id."' onchange='add_to_chairmen(".$user->id.",".$COURSE->id.",".$activity_id.','.$qa->get_question()->profiledata. ")'></td>";
                }
                $res.="</tr>";
            }
            $res.="</tbody></table>";
        }
        return $res;
    }
    
    function get_role_name($shortname){
        if($shortname==='manager'){
            return mb_strtolower(get_string('manager', 'role'));
        }
        else{
            $res=get_string('legacy:'.$shortname, 'role');
            $res=explode(':', $res)[1];
            $res=str_replace('редктирования', 'редактирования', $res);
            $res=mb_strtolower($res);
            $res=ltrim($res, ' ');
            return $res;
        }
    }
    
    function output_search_field($qa){
        global $COURSE;
        $roles_arr=[];
        $res='<script type="text/javascript" src="../../question/type/confdist/search.js"></script>';
        $res.='<h4>'.get_string('editing_roles', 'qtype_confdist').'</h4>';
        $res.='<input id="searchfield" type="text" placeholder="'.get_string('search_by_lastname', 'qtype_confdist').'" onkeyup="search();"><br><br>';
        
        $context = context_module::instance($COURSE->id);
        $users=get_enrolled_users($context);
        foreach($users as $user){
            $roles=get_user_roles($context, $user->id);
            foreach($roles as $role){
                $role_name=get_role_name($role->shortname);
                if(!in_array($role_name, $roles_arr)){
                    array_push($roles_arr, $role_name);
                }
            }
        }
        sort($roles_arr);
        foreach($roles_arr as $role){
            $res.='<input type="checkbox" value="'.$role.'" onchange="search_by_role()" class="role_checkbox" checked> '.$role."<br>";
        }
        
        return $res;
//            $res.='var el=document.querySelectorAll("'."[role='main']".':last-of-type")[0];';//кавычки
//            $res.="el.innerHTML='';";
//            $res.="el.innerHTML='";
//            $res.=$result;
//            $res.=$result1;
//            $res.="';";
//            $res.="</script>";
    }

    function check_rev_record($reviewer, $course, $activity_id){
        global $DB;
        if ($DB->get_record('confdist_reviewers_list', ['courseid'=>$course, 'activityid'=>$activity_id, 'reviewer'=>$reviewer])==false)
                return false;
        else
            return true;  
    }
    
    function check_editor_record($editor, $course, $activity_id){
        global $DB;
        if ($DB->get_record('confdist_editors_list', ['courseid'=>$course, 'activityid'=>$activity_id, 'editor'=>$editor])==false)
                return false;
        else
            return true;  
    }
    
    function check_chairman_record($chairman, $course, $activity_id){
        global $DB;
        if ($DB->get_record('confdist_chairmen_list', ['courseid'=>$course, 'activityid'=>$activity_id, 'chairman'=>$chairman])==false)
                return false;
        else
            return true;  
    }
    
    


?>