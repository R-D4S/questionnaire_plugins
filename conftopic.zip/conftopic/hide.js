function editPage(){
    document.addEventListener("DOMContentLoaded", hideElementsFromEditPage);
}
function hideElementsFromEditPage(){
    document.getElementById("fitem_id_generalfeedback").style.display='none';
    document.getElementById("fitem_id_answersinstruct").style.display='none';
    document.getElementById("id_answerhdr").style.display='none';
}



