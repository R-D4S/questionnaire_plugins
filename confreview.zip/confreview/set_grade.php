<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $reviewer=$_GET['reviewer'];
    $student=$_GET['student'];
    $attempt=$_GET['attempt'];
    $grade=$_GET['grade'];
    $DB->delete_records('confreview_grades', ['courseid'=>$course, 'activityid'=>$quiz, 'student'=>$student, 'attempt'=>$attempt, 'reviewer'=>$reviewer]);
    if($grade!=='n'){
        $DB->insert_record('confreview_grades', ['courseid'=>$course, 'activityid'=>$quiz, 'student'=>$student, 'attempt'=>$attempt, 'reviewer'=>$reviewer, 'grade'=>$grade]);
    }

