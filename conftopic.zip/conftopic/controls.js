var selection_quiz='';
function selectQuiz(course, squiz){
    selection_quiz=squiz;
    window.addEventListener('DOMContentLoaded', (event) => {
        var xmlHttp = new XMLHttpRequest();
        var url='/question/type/conftopic/get_quizes.php?course='+course;
        xmlHttp.open( 'GET', url); 
        var quizes;
        var res;
        xmlHttp.onload=function() {
            quizes=JSON.parse(xmlHttp.responseText);
            res='Выберите форму подачи заявки<br> ';
            res+='<select id="quiz_selector_element" onchange="get_fields('+course+')">';
            res+='<option value="-1"></option>';
            for(var i=0; i<quizes.length; i++){
                res+='<option value="'+quizes[i]['id']+'">'+quizes[i]['name']+'</option>';
            }
            res+='</select>';
            document.getElementById("select_quiz").innerHTML=res;
        };
        xmlHttp.send(null);
    });
    
    
}

function get_fields(course){
    var quiz=document.getElementById('quiz_selector_element').value;
    var xmlHttp = new XMLHttpRequest();
        var url='/question/type/conftopic/get_fields.php?quiz='+quiz+'&course='+course;
        xmlHttp.open( 'GET', url);         
        var res;
        xmlHttp.onload=function() {
            fields=JSON.parse(xmlHttp.responseText);
            res="<br>Выберите поле с названием темы<br>";
            res+="<select id='fields_selector' onchange='save_field("+course+','+quiz+")'>";
            res+="<option value='-1'></option>";
            for(var i=0; i<fields.length; i++){
                res+='<option value="'+fields[i]['id']+'">'+fields[i]['text']+"</option>";
            }
            res+='</select>';
            document.getElementById("select_field").innerHTML+=res;
            
        };
        xmlHttp.send(null);
}

function save_field(course, quiz){
    var field=document.getElementById('fields_selector').value;
    var xmlHttp = new XMLHttpRequest();
        var url='/question/type/conftopic/save_fields.php?quiz='+quiz+'&course='+course+'&field='+field+'&form='+selection_quiz;
        xmlHttp.open( 'GET', url);      
        xmlHttp.onload=function() {
           console.log(xmlHttp.responseText);
            
        };
        xmlHttp.send(null);
}

function select_topics(topics, activity, course, user){
    
    var res='<h4>Выберите интересующие вас темы<br></h4>';
    for (var i=0; i<topics.length; i++){
        res+='<input type="checkbox" class="topics_checkbox" value="'+topics[i]+'"> '+topics[i]+'<br>';
    }
    res+='<br><button class="btn btn-secondary" onclick="save_topics('+activity+','+course+','+user+')">сохранить</button>';
    document.getElementById('topic_selection_table').innerHTML=res;
    
}

function save_topics(activity, course, user){
    var selected_topics_checkboxes=document.getElementsByClassName('topics_checkbox');
    var topics=[];
    topics.push(activity);
    topics.push(course);
    topics.push(user);
    for (var i=0; i<selected_topics_checkboxes.length; i++){
        if(selected_topics_checkboxes[i].checked==true){
            topics.push(selected_topics_checkboxes[i].value);
        }
    }
    topics=JSON.stringify(topics);
    var xmlHttp = new XMLHttpRequest();
    
    var url='/question/type/conftopic/save_topics.php';
    xmlHttp.open( 'POST', url);
    xmlHttp.setRequestHeader('Content-Type', 'application/json');      
    xmlHttp.onload=function() {
       console.log(xmlHttp.responseText);
       window.location = window.location.href;
    };
    xmlHttp.send(topics);
    
}

