<?php
    defined('MOODLE_INTERNAL') || die();
    function xmldb_block_conftopic_uninstall(){
        return true;
    }
?>

