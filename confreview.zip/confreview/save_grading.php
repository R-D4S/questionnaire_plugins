<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $grading=$_GET['grading'];
    $lowest=$_GET['lowest'];
    $lowestavg=$_GET['lowestavg'];
    $form=$_GET['form'];
    //check and update
    check_record($quiz, $course);
    $DB->insert_record('confreview_grading', ['courseid'=>$course, 'activityid'=>$quiz, 'grading'=>$grading, 'lowestgrade'=>$lowest, 'lowestavg'=>$lowestavg, 'form'=>$form]);


    
    function check_record($quiz, $course){
        global $DB;
        if (!($DB->get_record('confreview_grading', ['courseid'=>$course, 'activityid'=>$quiz])==false))
                $DB->delete_records('confreview_grading', ['courseid'=>$course, 'activityid'=>$quiz]);
        
    }
?>