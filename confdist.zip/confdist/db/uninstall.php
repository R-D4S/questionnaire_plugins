<?php
    defined('MOODLE_INTERNAL') || die();
    function xmldb_block_confdist_uninstall(){
        return true;
    }
?>

