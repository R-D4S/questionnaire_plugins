<?php
    require_once'../../../config.php';
    global $DB;
    global $USER;
    global $COURSE;
    $context = context_module::instance($COURSE->id);
    $quiz=$_GET['quiz'];
    $course=$_GET['course'];
    $field=$_GET['field'];
    $form=$_GET['form'];
    //check and update
    check_field($quiz, $course);
    $DB->insert_record('conftopic_fields', ['fieldid'=>$field, 'courseid'=>$course, 'activityid'=>$quiz, 'form'=>$form]);



    function check_field($quiz, $course){
        global $DB;
        if (!($DB->get_record('conftopic_fields', ['courseid'=>$course, 'activityid'=>$quiz])==false))
                $DB->delete_records('conftopic_fields', ['courseid'=>$course, 'activityid'=>$quiz]);
        
    }
?>